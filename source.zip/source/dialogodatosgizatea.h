/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGO_DATOS_GIZATEA_H
#define DIALOGO_DATOS_GIZATEA_H

#include "dialogodatos.h"
#include "ui_dialogodatosgizatea.h"

class DialogoDatosGizatea : public DialogoDatos, public Ui::DialogoDatosGizatea
{
  Q_OBJECT

public:
    DialogoDatosGizatea(QWidget *parent=0);
    void actualizarForm();

private:
  void triggerOutWidget(QLineEdit *e);
  QString toHtml();

private slots:
  void on_dni_1_editingFinished() {DialogoDatos::validarWidget (dni_1);};
  void on_dni_2_editingFinished() {DialogoDatos::validarWidget (dni_2);};
  void on_email_1_editingFinished() {DialogoDatos::validarWidget (email_1);};
  void on_email_2_editingFinished() {DialogoDatos::validarWidget (email_2);};
  void on_telefono_1_editingFinished() {DialogoDatos::validarWidget (telefono_1);};
  void on_telefono_2_editingFinished() {DialogoDatos::validarWidget (telefono_2);};
  void on_cuota_entidad_editingFinished() {DialogoDatos::validarWidget (cuota_entidad);};
  void on_cuota_oficina_editingFinished() {DialogoDatos::validarWidget (cuota_oficina);};
  void on_cuota_dc_editingFinished() {DialogoDatos::validarWidget (cuota_dc);};
  void on_cuota_cuenta_editingFinished() {DialogoDatos::validarWidget (cuota_cuenta);};

};


#endif // DIALOGO_DATOS_GIZATEA_H
