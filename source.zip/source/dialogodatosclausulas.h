/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGO_DATOS_CLAUSULAS_H
#define DIALOGO_DATOS_CLAUSULAS_H

#include "dialogodatos.h"
#include "ui_dialogodatosclausulas.h"


class DialogoDatosClausulas : public DialogoDatos, public Ui::DialogoDatosClausulas
{
  Q_OBJECT

public:
    DialogoDatosClausulas(QWidget *parent=0);
    void actualizarForm();

private:
    void showWidgets();
    QString toHtml();

public slots:
  bool validarForm(bool flagShowOk);

private slots:
  void on_contratos_1_editingFinished() {DialogoDatos::validarWidget(contratos_1);};
};


#endif // DIALOGO_DATOS_CLAUSULAS_H
