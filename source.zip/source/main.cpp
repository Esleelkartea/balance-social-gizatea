/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QApplication>
#include "mainwindow.h"
#include <QSplashScreen>
#include <QTranslator>
#include <QLibraryInfo>
#include <qthread.h>
#include <QObject>

#include "constantes.h"
#include "mensajes.h"

class I : public QThread
{
public:
    static void sleep(unsigned long secs) {QThread::sleep(secs);}
};

int main  (int argc, char * argv[])
{
    QApplication app (argc, argv);

    QPixmap pixmap(SPLASH);
    QSplashScreen splash(pixmap);
    splash.show();
    splash.showMessage(QObject::tr(MSG_CARGANDO));

    app.processEvents();

    app.addLibraryPath(LIB_PATH);

    MainWindow mainwindow;

    I::sleep(1);
    mainwindow.show();
    splash.finish(&mainwindow);

    return app.exec();
}
