/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGO_DATOS_ECON_H
#define DIALOGO_DATOS_ECON_H

#include "arbol_delegado.h"
#include "dialogodatos.h"
#include "ui_dialogodatosecon.h"
#include "mensajes.h"

class DialogoDatosEcon : public DialogoDatos, public Ui::DialogoDatosEcon
{
  Q_OBJECT

public:
    DialogoDatosEcon(QWidget *parent=0);
    void leeRama(QTreeWidget *arbol, QTreeWidgetItem *tn, QDomElement raiz);
    void actualizarForm();

private:
    bool coop;

    QIcon groupIcon;
    QIcon keyIcon;

    QDomDocument dom1;
    QDomDocument dom2;
    QDomDocument dom3;

  void creaArboles();
  void creaArbol(QTreeWidget *arbol, QString str, QDomElement e);


  void plegar(QTreeWidget *arbol);
  void desplegar(QTreeWidget *arbol);
  void validarClientes(QLineEdit *e);
  void triggerOutWidget(QLineEdit *e);
  void triggerOutWidget(QComboBox *c, int *cambia);
  QString toHtml();
  QString arbolToHtml(QTreeWidget *p);
  QString nodoToHtml(QTreeWidgetItem *p);

private slots:
  void on_desplegarButton_1_clicked() {arbol_pyg->expandAll();}
  void on_plegarButton_1_clicked() {arbol_pyg->collapseAll();}
  void on_desplegarButton_2_clicked() {arbol_activo->expandAll();}
  void on_plegarButton_2_clicked() {arbol_activo->collapseAll();}
  void on_desplegarButton_3_clicked() {arbol_pasivo->expandAll();}
  void on_plegarButton_3_clicked() {arbol_pasivo->collapseAll();}
  void on_clientes_1_editingFinished() {validarClientes(clientes_1);};
  void on_clientes_2_editingFinished() {validarClientes(clientes_2);};



public slots:
  void actualizaArbol (QString str);
  void arbolCoop (QString text);
  bool validarForm(bool flagShowOk);

};


#endif // DIALOGO_DATOS_ECON_H
