/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGO_ACERCA_DE_H
#define DIALOGO_ACERCA_DE_H

#include "ui_dialogoacercade.h"
#include "version.h"
#include "constantes.h"

class DialogoAcercaDe : public QDialog, public Ui::DialogoAcercaDe
{
  Q_OBJECT
public:
    DialogoAcercaDe(QWidget *parent=0):QDialog (parent)
    {
        setupUi (this);
        QWidget *l=findChild<QLabel *>("imagen");
        QPixmap p (SPLASH_TXIKI);
        ((QLabel *)l)->setPixmap(p);
    }

    void changeEvent(QEvent *event)
    {
        if (event->type() == QEvent::LanguageChange)
            retranslateUi((QDialog*)this);

        version->setText(tr("Balance Social")+" "+VERSION);
        QDialog::changeEvent(event);
    }
};

#endif // DIALOGO_ACERCA_DE_H
