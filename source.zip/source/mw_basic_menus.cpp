/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QtGui>
#include "mainwindow.h"

#include "mensajes.h"
#include "constantes.h"


void MainWindow::newMenu()
{
    if (!saved) {
        int ret = QMessageBox::warning(this, QObject::tr(MSG_APP),QObject::tr(MSG_WARN_SAVE_NEW),
                                       QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
        if (ret==QMessageBox::Yes) {
            if (fichero!="") saveMenu();
            else saveAsMenu();
        }
    }

    createDialogosDatos();

    saved = true;
    fichero="";
    setWindowTitle(tr("Balance Social"));
    actionGuardar->setEnabled(false);
}

void MainWindow::salirMenu()
{
    if (!saved) {
        int ret = QMessageBox::warning(this, QObject::tr(MSG_APP),QObject::tr(MSG_WARN_SAVE_END),
                                       QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel,
                                       QMessageBox::Save);
        if (ret==QMessageBox::Save) {
            saveMenu();
            close();
        } else if (ret==QMessageBox::Discard)
            close();
        else
            if (ret==QMessageBox::Cancel) {
            ;
            }
    }
    else
        close();
}


void MainWindow::setIdioma(QAction *action)
{
    QString str = action->text();
    if (str=="Euskera") {
        //qtTranslator.load("qt_eu_ES", QLibraryInfo::location(QLibraryInfo::TranslationsPath));
        qtTranslator.load(QT_EU);
        qApp->installTranslator(&qtTranslator);

        appTranslator.load(APP_EU);
        qApp->installTranslator(&appTranslator);
    } else {
        qApp->removeTranslator(&qtTranslator);
        qtTranslator.load("qt_es_ES", QLibraryInfo::location(QLibraryInfo::TranslationsPath));
        qApp->installTranslator(&qtTranslator);

        qApp->removeTranslator(&appTranslator);
    }
    retranslateUi(this);
}

void MainWindow::setMenuRed(QString str)
{
    if (str=="Gizatea" && !botonInfoGizatea->isVisible()) {
        menuDatos->addAction(actionInfoGizatea);
        botonInfoGizatea->setVisible(true);
    }
    else if (str!="Gizatea" && botonInfoGizatea->isVisible()) {
        menuDatos->removeAction(actionInfoGizatea);
        botonInfoGizatea->setVisible(false);
    }
}





