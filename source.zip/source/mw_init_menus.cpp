/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QtGui>
#include "mainwindow.h"

#include "ui_mainwindow.h"

#include "dialogodatosgeneral.h"
#include "dialogodatossocial.h"
#include "dialogodatosinsercion.h"
#include "dialogodatosecon.h"
#include "dialogodatosretorno.h"
#include "dialogodatosclausulas.h"
#include "dialogodatosgestion.h"
#include "dialogodatosgizatea.h"
#include "dialogoacercade.h"
#include "dialogoayuda.h"


void MainWindow::menus()
{
    menuDatos->removeAction(actionInfoGizatea);
    botonInfoGizatea->setVisible(false);

    connect(actionNuevo,  SIGNAL (triggered()), this, SLOT(newMenu()));
    connect(actionAbrir,  SIGNAL (triggered()), this, SLOT(openMenu()));
    connect(actionGuardar,  SIGNAL (triggered()), this, SLOT(saveMenu()));
    connect(actionGuardarComo,  SIGNAL (triggered()), this, SLOT(saveAsMenu()));
    connect(actionExportPdf,  SIGNAL (triggered()), this, SLOT(exportPdfMenu()));
    connect(actionExportHtml,  SIGNAL (triggered()), this, SLOT(exportHtmlMenu()));
    connect(actionEnviar,  SIGNAL (triggered()), this, SLOT(sendMenu()));
    connect(actionConsolidar,  SIGNAL (triggered()), this, SLOT(consolidarMenu()));
    connect(actionSalir,  SIGNAL (triggered()), this, SLOT(salirMenu()));

    connect(actionInfoGeneral, SIGNAL (triggered()), this, SLOT(datosGeneralMenu()));
    connect(actionInfoSocial, SIGNAL (triggered()), this, SLOT(datosSocialMenu()));
    connect(actionInfoInsercion, SIGNAL (triggered()), this, SLOT(datosInsercionMenu()));
    connect(actionInfoEcon, SIGNAL (triggered()), this, SLOT(datosEconMenu()));
    connect(actionInfoRetorno, SIGNAL (triggered()), this, SLOT(datosRetornoMenu()));
    connect(actionInfoClausulas, SIGNAL (triggered()), this, SLOT(datosClausulasMenu()));
    connect(actionInfoGestion, SIGNAL (triggered()), this, SLOT(datosGestionMenu()));
    connect(actionInfoGizatea, SIGNAL (triggered()), this, SLOT(datosGizateaMenu()));

    connect(actionAyuda,  SIGNAL (triggered()), this, SLOT(ayudaMenu()));
    connect(actionAbout,  SIGNAL (triggered()), this, SLOT(aboutMenu()));


    QActionGroup *idiomas = new QActionGroup(this);
    idiomas->addAction(actionCastellano);
    idiomas->addAction(actionEuskera);
    connect(idiomas, SIGNAL(triggered(QAction *)),this, SLOT(setIdioma(QAction *)));

    QToolBar *tb = new QToolBar(this);
    //tb->setWindowTitle(tr("Balance social"));
    addToolBar(tb);

    QIcon newIcon = QIcon(NEW_ICON);
    actionNuevo->setIcon(newIcon);
    tb->addAction(actionNuevo);
    QIcon openIcon = QIcon(OPEN_ICON);
    actionAbrir->setIcon(openIcon);
    tb->addAction(actionAbrir);
    QIcon saveIcon = QIcon(SAVE_ICON);
    actionGuardar->setIcon(saveIcon);
    tb->addAction(actionGuardar);
    QIcon saveAsIcon = QIcon(SAVEAS_ICON);
    actionGuardarComo->setIcon(saveAsIcon);
    tb->addAction(actionGuardarComo);
    QIcon exportPdfIcon = QIcon(EXPORTPDF_ICON);
    actionExportPdf->setIcon(exportPdfIcon);
    tb->addAction(actionExportPdf);
    QIcon exportHtmlIcon = QIcon(EXPORTHTML_ICON);
    actionExportHtml->setIcon(exportHtmlIcon);
    tb->addAction(actionExportHtml);
    QIcon closeIcon = QIcon(SALIR_ICON);
    actionSalir->setIcon(closeIcon);
    tb->addAction(actionSalir);

    tb->addSeparator();

    QIcon enviarIcon = QIcon(ENVIAR_ICON);
    actionEnviar->setIcon(enviarIcon);
    tb->addAction(actionEnviar);
    QIcon consolidarIcon = QIcon(CONSOLIDAR_ICON);
    actionConsolidar->setIcon(consolidarIcon);
    tb->addAction(actionConsolidar);

    tb->addSeparator();
    QIcon ayudaIcon = QIcon(AYUDA_ICON);
    actionAyuda->setIcon(ayudaIcon);
    tb->addAction(actionAyuda);
    QIcon aboutIcon = QIcon(ABOUT_ICON);
    actionAbout->setIcon(aboutIcon);
    tb->addAction(actionAbout);

    tb->setIconSize(QSize(32,32));
}


void MainWindow::datosGeneralMenu()     {dialogoDatosGeneral -> exec();}
void MainWindow::datosSocialMenu()      {dialogoDatosSocial -> exec();}
void MainWindow::datosInsercionMenu()   {dialogoDatosInsercion -> exec();}
void MainWindow::datosEconMenu()        {
    dialogoDatosEcon->findChild<QLabel *>("nota")->setText(QObject::tr(MSG_D_ECON_NOTA));
    dialogoDatosEcon -> exec();
}
void MainWindow::datosRetornoMenu()     {dialogoDatosRetorno -> exec();}
void MainWindow::datosClausulasMenu()    {dialogoDatosClausulas -> exec();}
void MainWindow::datosGestionMenu()     {dialogoDatosGestion -> exec();}
void MainWindow::datosGizateaMenu()     {dialogoDatosGizatea -> exec();}
void MainWindow::aboutMenu()            {dialogoAcercaDe->exec();}
void MainWindow::ayudaMenu()            {dialogoAyuda->resize (570,500); dialogoAyuda->muestra("");}

