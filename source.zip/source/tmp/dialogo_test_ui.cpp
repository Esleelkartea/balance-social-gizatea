/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogo_test.h"
#include <QtGui>

void DialogoTest::setupUi () {
    setObjectName(QString::fromUtf8("DialogoTest"));
    resize(450, 250);

    tab = new QTabWidget(this);
    //tab->setGeometry(QRect(20, 20, 400, 350));

    tab_1 = new QWidget();
    tab->addTab(tab_1, QString());
    tab_2 = new QWidget();
    tab->addTab(tab_2, QString());
    tab->setCurrentIndex(0);

    QWidget *tab_3 = new QWidget();
    tab->addTab(tab_3, QString());

    QGridLayout *hg1 = new QGridLayout(this);

    QLabel *l01 = new QLabel(tr("Hombres\nInserción"),this);

    QLabel *l1 = new QLabel(tr("Dirección/Gerencia"),this);
    QLabel *l2 = new QLabel(tr("Acompañamiento"),this);
    QLabel *l3 = new QLabel(tr("Producción o Comercial"),this);

    QLineEdit *h1 = new QLineEdit(tab_3);
    QLineEdit *h2 = new QLineEdit(tab_3);
    QLineEdit *h3 = new QLineEdit(tab_3);
    QLineEdit *m1 = new QLineEdit(tab_3);
    hg1->addWidget (l01,0,1);
    hg1->addWidget (l1,1,0);
    hg1->addWidget (l2,2,0);
    hg1->addWidget (l3,3,0);
    hg1->addWidget (h1,1,1);
    hg1->addWidget (h2,2,1);
    hg1->addWidget (h3,3,1);
    hg1->addWidget (m1,1,2);

    tab_3->setLayout(hg1);


    fiscalidad = new QTableWidget(tab_1);
    fiscalidad->setObjectName(QString::fromUtf8("fiscalidad"));
    fiscalidad->setGeometry(QRect(0, 0, 300, 170));
    fiscalidad->setRowCount(4);
    fiscalidad->setColumnCount(1);

    /*
    QTableWidgetItem *fiscalidad_iva = new QTableWidgetItem();
    fiscalidad->setVerticalHeaderItem(0, fiscalidad_iva);
    QTableWidgetItem *fiscalidad_sociedades = new QTableWidgetItem();
    fiscalidad->setVerticalHeaderItem(1, fiscalidad_sociedades);
    QTableWidgetItem *fiscalidad_otros = new QTableWidgetItem();
    fiscalidad->setVerticalHeaderItem(2, fiscalidad_otros);
    QTableWidgetItem *fiscalidad_irpf = new QTableWidgetItem();
    fiscalidad->setVerticalHeaderItem(3, fiscalidad_irpf);
    */
    label_1 = new QLabel(tab_2);
    label_1->setGeometry(QRect(10, 10, 210, 15));

    gastos_personal = new QTableWidget(tab_2);
    gastos_personal->setObjectName(QString::fromUtf8("gastos_personal"));
    gastos_personal->setGeometry(QRect(10, 30, 530, 140));
    gastos_personal->setRowCount(3);
    gastos_personal->setColumnCount(4);

    QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
    gastos_personal->setHorizontalHeaderItem(0, __qtablewidgetitem4);
    QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
    gastos_personal->setHorizontalHeaderItem(1, __qtablewidgetitem5);
    QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
    gastos_personal->setHorizontalHeaderItem(2, __qtablewidgetitem6);
    QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
    gastos_personal->setHorizontalHeaderItem(3, __qtablewidgetitem7);

    QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
    gastos_personal->setVerticalHeaderItem(0, __qtablewidgetitem8);
    QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
    gastos_personal->setVerticalHeaderItem(1, __qtablewidgetitem9);
    QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
    gastos_personal->setVerticalHeaderItem(2, __qtablewidgetitem10);
    gastos_personal->verticalHeader()->setVisible(false);
    gastos_personal->verticalHeader()->setHighlightSections(true);



    validarButton = new QPushButton("validarButton");
    salirButton = new QPushButton();

    QHBoxLayout *hl1 = new QHBoxLayout;
    //hl1->addStretch();
    hl1->addWidget(tab);
    //hb1->addStretch();

    //horizontalLayoutWidget = new QWidget(this);
    //horizontalLayoutWidget->setGeometry(QRect(160, 230, 250, 30));
    QHBoxLayout *hl2 = new QHBoxLayout;
    //horizontalLayout->setContentsMargins(0, 0, 0, 0);
    hl2->addStretch();
    hl2->addWidget(validarButton);
    hl2->addWidget(salirButton);
    hl2->addStretch();

    QVBoxLayout *v = new QVBoxLayout;
    v->addLayout(hl1);
    v->addLayout(hl2);
    setLayout(v);


    retranslateUi();

    QObject::connect(salirButton,SIGNAL(clicked()),this,SLOT(close()));
    //QMetaObject::connectSlotsByName(this);
}

void DialogoTest::retranslateUi()
{
    QStringList ql;

    setWindowTitle(QApplication::translate("DialogoTest", "Retorno social", 0, QApplication::UnicodeUTF8));

    tab->setTabText(tab->indexOf(tab_1), QApplication::translate("DialogoTest", "Fiscalidad", 0, QApplication::UnicodeUTF8));

    ql.clear();
    ql << "";
    fiscalidad->setHorizontalHeaderLabels(ql);
    ql.clear();
    ql << QApplication::translate("DialogoTest", "IVA o situaciones especiales (IGIC)", 0, QApplication::UnicodeUTF8);
    ql += QApplication::translate("DialogoTest", "Impuesto sobre Sociedades", 0, QApplication::UnicodeUTF8);
    ql += QApplication::translate("DialogoTest", "Otros tributos ", 0, QApplication::UnicodeUTF8);
    ql += QApplication::translate("DialogoTest", "IRPF ", 0, QApplication::UnicodeUTF8);
    fiscalidad->setVerticalHeaderLabels(ql);

  /*
  QTableWidgetItem *___qtablewidgetitem0 = fiscalidad->verticalHeaderItem(0);
  ___qtablewidgetitem0->setText(QApplication::translate("DialogoTest", "IVA o situaciones especiales (IGIC)", 0, QApplication::UnicodeUTF8));
  QTableWidgetItem *___qtablewidgetitem1 = fiscalidad->verticalHeaderItem(1);
  ___qtablewidgetitem1->setText(QApplication::translate("DialogoTest", "Impuesto sobre Sociedades", 0, QApplication::UnicodeUTF8));
  QTableWidgetItem *___qtablewidgetitem2 = fiscalidad->verticalHeaderItem(2);
  ___qtablewidgetitem2->setText(QApplication::translate("DialogoTest", "Otros tributos ", 0, QApplication::UnicodeUTF8));
  QTableWidgetItem *___qtablewidgetitem3 = fiscalidad->verticalHeaderItem(3);
  ___qtablewidgetitem3->setText(QApplication::translate("DialogoTest", "IRPF ", 0, QApplication::UnicodeUTF8));
*/
    tab->setTabText(tab->indexOf(tab_2), QApplication::translate("DialogoTest", "Gastos personal", 0, QApplication::UnicodeUTF8));
    QTableWidgetItem *___qtablewidgetitem4 = gastos_personal->horizontalHeaderItem(0);
    ___qtablewidgetitem4->setText(QApplication::translate("DialogoTest", "Neto", 0, QApplication::UnicodeUTF8));
    QTableWidgetItem *___qtablewidgetitem5 = gastos_personal->horizontalHeaderItem(1);
    ___qtablewidgetitem5->setText(QApplication::translate("DialogoTest", "IRPF\n"
                                                          "empleada", 0, QApplication::UnicodeUTF8));
    QTableWidgetItem *___qtablewidgetitem6 = gastos_personal->horizontalHeaderItem(2);
    ___qtablewidgetitem6->setText(QApplication::translate("DialogoTest", "Seg. social\n"
                                                          "empleada", 0, QApplication::UnicodeUTF8));
    QTableWidgetItem *___qtablewidgetitem7 = gastos_personal->horizontalHeaderItem(3);
    ___qtablewidgetitem7->setText(QApplication::translate("DialogoTest", "Seg. social\n"
                                                          "empresa", 0, QApplication::UnicodeUTF8));
    QTableWidgetItem *___qtablewidgetitem8 = gastos_personal->verticalHeaderItem(0);
    ___qtablewidgetitem8->setText(QApplication::translate("DialogoTest", "T. inserci\303\263n", 0, QApplication::UnicodeUTF8));
    QTableWidgetItem *___qtablewidgetitem9 = gastos_personal->verticalHeaderItem(1);
    ___qtablewidgetitem9->setText(QApplication::translate("DialogoTest", "T. acompa\303\261amiento", 0, QApplication::UnicodeUTF8));
    QTableWidgetItem *___qtablewidgetitem10 = gastos_personal->verticalHeaderItem(2);
    ___qtablewidgetitem10->setText(QApplication::translate("DialogoTest", "T. producci\303\263n", 0, QApplication::UnicodeUTF8));

    label_1->setText(QApplication::translate("DialogoTest", "Proceso de inserci\303\263n durante el a\303\261o", 0, QApplication::UnicodeUTF8));
    validarButton->setText(QApplication::translate("DialogoTest", "Validar", 0, QApplication::UnicodeUTF8));
    salirButton->setText(QApplication::translate("DialogoTest", "Salir", 0, QApplication::UnicodeUTF8));
}

