/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatos.h"
#include <QtGui>


void DialogoDatos::setGrid(QGridLayout *g, QValidator *v)
{
    QLayoutItem *item;
    QWidget *w;

    for (int i=0;i<g->rowCount();i++)
        for (int j=1;j<g->columnCount();j++) { // desde la columna 2
            item=g->itemAtPosition(i,j);
            if (item==0) continue;
            w=item->widget();
            if (w==0) continue;
            g->setAlignment(w, Qt::AlignHCenter);
            QString str=w->metaObject()->className();
            if (str=="QLineEdit")
                ((QLineEdit *)w)->setValidator(v);
        }
}

void DialogoDatos::sumaGrid(QGridLayout *g,int fil, int col, int x) {
    // Si no se quieren hacer sumas de la fila (resultado en última columna), indicar fil = 0
    // Si no se quieren hacer sumas de la columnas (resultado en última fila) indicar col = 0; Si
    // hay otra fila de labels a actualizar distinta de la última, indicarla con x
    int col_final;

    if (fil!=0)
        sumaFilaGrid(g, fil);
    if (col!=0)
        sumaColumnaGrid (g, col, x, false);
    if (fil!=0 && col!=0) {
        col_final=g->columnCount()-1;
        sumaColumnaGrid (g, col_final, 0, true);
    }
}


void DialogoDatos::sumaColumnaGrid(QGridLayout *g,int col, int x, bool ultima)
// Si col es 0, se considera que hay que sumar la última columna
{
    QString str;
    double n;
    QLayoutItem *qli;
    QWidget *w;
    int pos_total;

    n=0;
    // Sumar las filas de la columna hacia abajo
    for (int i=0; i< g->rowCount()-1;i++) { // Al ppio está el título y al final el total
        qli=g->itemAtPosition(i,col);
        if (qli==0) continue;
        w=qli->widget();
        if (w==0) continue;
        str=w->metaObject()->className();
        if (str=="QLineEdit")
            n+=((QLineEdit *)w)->text().toDouble();
        else if (ultima && str=="QLabel") // Sólo suma etiquetas si es en la última columna
            n+=((QLabel *)w)->text().replace(".","").toDouble();
    }
    if (x!=0)
        pos_total=x;
    else
        pos_total=g->rowCount()-1;
    w=g->itemAtPosition(pos_total, col)->widget();
    QLabel *l=(QLabel *)w;
    if (l->text().contains(","))
        l->setText(QLocale().toString(n,'f',2));
    else
        l->setText(QLocale().toString(n));
}


void DialogoDatos::sumaFilaGrid(QGridLayout *g,int fil)
{
    QString str;
    double n;
    QLayoutItem *qli;
    QWidget *w;
    int pos_total;

    n=0;
    // Sumar las columnas de la fila hacia la derecha
    for (int j=1; j< g->columnCount()-1;j++) { // Al ppio está el título y al final el total
        qli=g->itemAtPosition(fil,j);
        if (qli==0) continue;
        w=qli->widget();
        if (w==0) continue;
        str=w->metaObject()->className();
        if (str=="QLineEdit")
            n+=((QLineEdit *)w)->text().toDouble();
    }
    pos_total=g->columnCount()-1;
    w=g->itemAtPosition(fil,pos_total)->widget();
    QLabel *l=(QLabel *)w;
    if (l->text().contains(","))
        l->setText(QLocale().toString(n,'f',2));
    else
        l->setText(QLocale().toString(n));
}
