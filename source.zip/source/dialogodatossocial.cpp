/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatossocial.h"
#include <QtGui>
#include "mainwindow.h"
#include "mensajes.h"

DialogoDatosSocial::DialogoDatosSocial (QWidget *parent)
  :DialogoDatos (parent)
{
    setupUi (this);
    initUi();

    notasTab [1]=QObject::tr(MSG_D_SOCIAL_NOTA_EI);
    notasTab [2]=QObject::tr(MSG_D_SOCIAL_NOTA_EP);
    notasTab [4]=QObject::tr(MSG_D_SOCIAL_NOTA_CONTRATOS);


    DialogoDatos::setGrid((QGridLayout *)(g_personas_1->layout()), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)(g_personas_2->layout()), intPositivoVal);
    DialogoDatos::setGrid(grid_ei, doublePositivoVal);
    DialogoDatos::setGrid(grid_ep, doublePositivoVal);
    DialogoDatos::setGrid(grid_jornadas, intPositivoVal);

    DialogoDatos::setGrid((QGridLayout *)(g_i_1->layout()), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)(g_i_2->layout()), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)(g_i_3->layout()), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)(g_ni_1->layout()), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)(g_ni_2->layout()), intPositivoVal);


    showWidgets();
}

void DialogoDatosSocial::showWidgets()
{
    int n=o_5->text().toInt();
    if (n!=0 && (label_otros->isVisible())==false) {
        label_otros->show();
        texto_otros->show();
    } else if (n==0 && label_otros->isVisible()) {
        label_otros->hide();
        texto_otros->hide();
    }
}



bool DialogoDatosSocial::validarForm(bool flagShowOk)
{
    QList <QWidget *> l;

    // Personas a 31 dic  ≤  total personal a lo largo del año
    if ( ! cmpValidar1(total_personas_ins_31dic->text(),
                       total_personas_ins_anno->text(),
                      QObject::tr(MSG_D_SOCIAL_ERR_PERSONAS_INS_31DIC) ))
        return false;
    if ( ! cmpValidar1(total_personas_no_ins_31dic->text(), total_personas_no_ins_anno->text(),
                      QObject::tr(MSG_D_SOCIAL_ERR_PERSONAS_NO_INS_31DIC) ))
        return false;

    // RMI ≤ total personal inserción a lo largo del año
    if ( ! cmpValidar1(pers_rmi->text(), total_personas_ins_anno->text(),
                    QObject::tr(MSG_D_SOCIAL_ERR_RMI) ))
        return false;

    // Jornadas >= total de las personas de INSERCIÓN q han pasado x la EI ese año
    if ( ! cmpValidar2(jornadas_total->text(), total_personas_ins_anno->text(),
                    QObject::tr(MSG_D_SOCIAL_ERR_JORNADAS) ))
        return false;

    // Contratos >= total de las personas de INSERCIÓN q han pasado x la EI ese año
    if ( ! cmpValidar2(contratos_total->text(), total_personas_ins_anno->text(),
                    QObject::tr(MSG_D_SOCIAL_ERR_CONTRATOS) ))
        return false;

    // Validaciones con formulario de Inserción
    if ( ! ((MainWindow*)(this->parentWidget()))->checkPersonasI() )
        return false;

    // Datos obligatorios
    if ( o_5->text().toInt()==0 && !l.contains(texto_otros) )
        l << texto_otros;

    return DialogoDatos::validarForm(&l, flagShowOk);
}


bool DialogoDatosSocial::cmpValidar1(QString a, QString b, QString s)
{
    // Validar  a<=b
    if ( a.toDouble()>b.toDouble() )  {
        QMessageBox::warning(0, QObject::tr(MSG_VALIDACION), s.arg(a).arg(b));
         return false;
    }

    return true;
}

bool DialogoDatosSocial::cmpValidar2(QString a, QString b, QString s)
{
    // Validar a>=b
    if ( a.toDouble()<b.toDouble() )  {
        QMessageBox::warning(0, QObject::tr(MSG_VALIDACION), s.arg(a).arg(b));
         return false;
    }

    return true;
}

void DialogoDatosSocial::actualizarForm()
{
    int i, j;

    for (i=1;i<=2;i++)
        for (j=1; j<=2; j++) {
            sumaGrid((QGridLayout*)g_personas_1->layout(),i,j);
            sumaGrid((QGridLayout*)g_personas_2->layout(),i,j);
            sumaGrid(grid_jornadas,i,j);
        }

    for (i=1;i<=5;i++)
        for (j=1; j<=4; j++)
            sumaGrid(grid_ei,i,j);

    for (i=1;i<=5;i++)
        for (j=1; j<=2; j++)
            sumaGrid(grid_ep,i,j);

    sumaContratos();
    showWidgets();
}


