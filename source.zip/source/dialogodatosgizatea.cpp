/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosgizatea.h"
#include <QtGui>



DialogoDatosGizatea::DialogoDatosGizatea (QWidget *parent)
    :DialogoDatos (parent)
{
    QRegExpValidator *q;

    setupUi (this);
    QList <QWidget *> opcionales;
    opcionales << telefono_2 << tel2_2;
    initUi(&opcionales);

    dni_1->setValidator(dniVal);
    dni_2->setValidator(dniVal);
    telefono_1->setValidator(telefonoVal);
    telefono_2->setValidator(telefonoVal);
    tel2_1->setValidator(telefonoVal);
    tel2_2->setValidator(telefonoVal);
    email_1->setValidator(emailVal);
    email_2->setValidator(emailVal);

    QRegExp int4Exp ("[0-9]{4}");
    q = new QRegExpValidator(int4Exp, this);
    cuota_entidad->setValidator(q);
    cuota_oficina->setValidator(q);
    QRegExp int2Exp ("[0-9]{2}");
    q = new QRegExpValidator(int2Exp, this);
    cuota_dc->setValidator(q);
    QRegExp int10Exp ("[0-9]{10}");
    q = new QRegExpValidator(int10Exp, this);
    cuota_cuenta->setValidator(q);

    DialogoDatos::setGrid(grid_voluntariado, intPositivoVal);
}


void DialogoDatosGizatea::triggerOutWidget (QLineEdit *e)
{
    if (e==voluntarios || e==voluntarias)
        sumaGrid(grid_voluntariado,0,1);
}

void DialogoDatosGizatea::actualizarForm()
{
    sumaGrid(grid_voluntariado,0,1);
}
