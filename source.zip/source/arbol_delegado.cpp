/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QtGui>

#include "arbol_delegado.h"


void ArbolDelegado::paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const
{
    QItemDelegate::paint(painter, option, index);
}

QWidget * ArbolDelegado::createEditor(QWidget *parent, const QStyleOptionViewItem &, const QModelIndex &index) const
{
    if (index.column() != 2)
        return 0;

    QLineEdit *lineEdit = new QLineEdit(parent);
    lineEdit->setFrame(false);

    QRegExp eurosExp = QRegExp ("-?[0-9]+((\\,|\\.)[0-9][0-9]?)?");
    QRegExpValidator *eurosVal = new QRegExpValidator(eurosExp,parent);
    lineEdit -> setValidator (eurosVal);

    return lineEdit;
}

void ArbolDelegado::setEditorData(QWidget *editor, const QModelIndex &index) const
{
    QVariant value = index.model()->data(index, Qt::UserRole);
    if (QLineEdit *lineEdit = qobject_cast<QLineEdit *>(editor))
        lineEdit->setText(QLocale().toString(value.toDouble()));
}

void ArbolDelegado::setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const
{
  int pos;

  QLineEdit *lineEdit = qobject_cast<QLineEdit *>(editor);
  if (!lineEdit->isModified())
    return;

  QString text = lineEdit->text();
  const QValidator *validator = lineEdit->validator();
  if (validator)
    if (validator->validate(text, pos) == QValidator::Invalid)
      return;

  double d;
  d=text.toDouble();
  model->setData(index, d, Qt::UserRole);
  model->setData(index, QLocale().toString(d,'f',2), Qt::DisplayRole);

  recorre(model, index);

  //hack para que no dé error por emitir señal desde función constante
  ArbolDelegado *ptr=(ArbolDelegado *)this;
  emit ptr->actualizaArbol(nombreArbol);

}

void ArbolDelegado::recorre(QAbstractItemModel *model, const QModelIndex &index) const
// Actualiza los totales de los nodos padres
{
    QModelIndex mi, parent;
    double suma;
    QString str;
    int fil;

    /* Hace siempre la suma de los hermanos y lo asigna al padre */
    parent=index.parent();
    while (parent.isValid()) {
        suma=0;
        fil=0;
        mi = parent.child(fil,2);
        while (mi.isValid())
        {
            suma+=(model->data(mi, Qt::UserRole)).toDouble();
            fil++;
            mi = mi.sibling(fil,2);
        }
        parent=parent.sibling(parent.row(),2);

        model->setData(parent,suma, Qt::UserRole);
        model->setData(parent, QLocale().toString(suma,'f',2), Qt::DisplayRole);

        parent = parent.parent(); //recurrente a todos los padres
    }

   //hack para que no dé error por emitir señal desde función constante
   ArbolDelegado *ptr=(ArbolDelegado *)this;
   emit ptr->actualizaArbol(nombreArbol);
}
