/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatosinsercion.h"
#include "html.h"

QString DialogoDatosInsercion::toHtml()
{
    QString str="";

    str+=claseHtml("h2","salto",tr("Inserción laboral"));

    str+=tagHtml("h3",tr("Permanencia"));
    str+="<ul>";
    str+=campoUnidTagHtml(tr("Menos de 6 meses"),"li",p_1->text(),"personas");
    str+=campoUnidTagHtml(tr("De 6 a 12 meses"),"li",p_2->text(),"personas");
    str+=campoUnidTagHtml(tr("De 1 a 2 años"),"li",p_3->text(),"personas");
    str+=campoUnidTagHtml(tr("De 2 a 3 años"),"li",p_4->text(),"personas");
    str+="<b>"+campoUnidTagHtml(tr("Total"),"li",p_total->text(),"personas")+"</b>";
    str+="</ul>";

    str+=tagHtml("h3",tr("Proceso"));
    str+=tagHtml("p",tr("Nº personas en inserción que durante el año:"));
    str+="<p>&nbsp;</p><table>";
    str+="<tr><th align=\"left\">"+tr("Continuaron el proceso de inserción")+"</th>"+tdRightHtml(proceso_a3->text())+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Abandonaron el proceso de inserción")+"</th>"+tdRightHtml(proceso_a2->text())+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Finalizaron su contrato")+"</th>"+tdRightHtml(proceso_a4->text())+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Finalizaron el proceso de inserción")+"</th>"+tdRightHtml(proceso_a1->text())+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Total")+"</th>"+thRightHtml(proceso_a0->text())+"</tr>";
    str+="</table>";

    str+=tagHtml("p",tr("Nº personas que han finalizado el proceso durante el año y:"));
    str+="<p>&nbsp;</p><table>";
    str+="<tr><th align=\"left\">"+tr("Han encontrado empleo en el mercado ordinario")+"</th>"+tdRightHtml(proceso_b1->text())+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Han encontrado empleo en la empresa de inserción")+"</th>"+tdRightHtml(proceso_b2->text())+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Están en desempleo")+"</th>"+tdRightHtml(proceso_b3->text())+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Total")+"</th>"+thRightHtml(proceso_b0->text())+"</tr>";
    str+="</table>";

    str+=tagHtml("h3",tr("Ocupación"));
    str+="<br><table width=100%><tr>";

    str+="<td>";
    str+=tagHtml("p",tr("Ocupaciones de los hombres insertados:"));
    if (ocupa_a0->text()!="0") {
        str+="<p>&nbsp;</p><table class=\"sinborde\">";
        str+=campoTrHtml(okupa_a1->text(),ocupa_a1->text());
        str+=campoTrHtml(okupa_a2->text(),ocupa_a2->text());
        str+=campoTrHtml(okupa_a3->text(),ocupa_a3->text());
        str+=campoTrHtml(okupa_a4->text(),ocupa_a4->text());
        str+=campoTrHtml(okupa_a5->text(),ocupa_a4->text());
        str+="<tr><th>"+tr("Total")+"</th>"+thRightHtml(ocupa_a0->text())+"</tr>";
        str+="</table>";
    }
    str+="</td>";

    str+="<td>";
    str+=tagHtml("p",tr("Ocupaciones de las mujeres insertadas:"));
    if (ocupa_b0->text()!="0") {
        str+="<p>&nbsp;</p><table class=\"sinborde\">";
        str+=campoTrHtml(okupa_b1->text(),ocupa_b1->text());
        str+=campoTrHtml(okupa_b2->text(),ocupa_b2->text());
        str+=campoTrHtml(okupa_b3->text(),ocupa_b3->text());
        str+=campoTrHtml(okupa_b4->text(),ocupa_b4->text());
        str+=campoTrHtml(okupa_b5->text(),ocupa_b4->text());
        str+="<tr><th>"+tr("Total")+"</th>"+thRightHtml(ocupa_b0->text())+"</tr>";
        str+="</table>";
    }
    str+="</td></tr></table>";
    return str;
}
