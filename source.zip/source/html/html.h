/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef HTML_H
#define HTML_H

#include <QtGui>
#include <QList>
#include <QLineEdit>

extern "C" QString tagHtml(QString tag,QString valor);
extern "C" QString campoHtml (QString etiqueta, QString valor);
extern "C" QString campoUnidHtml (QString etiqueta, QString valor, QString unid);
extern "C" QString euroHtml (QString valor);
extern "C" QString campoTrHtml (QString etiqueta, QString valor);
extern "C" QString campoTagHtml (QString etiqueta, QString tag, QString valor);
extern "C" QString campoUnidTagHtml (QString etiqueta, QString tag, QString valor, QString unid);
extern "C" QString campoCeroTagHtml (QString etiqueta, QString tag, QString valor);
extern "C" QString claseHtml (QString tag, QString clase, QString valor);
extern "C" QString tdRightHtml (QString valor);
extern "C" QString thRightHtml (QString valor);
extern "C" QString qRadioButtonToHtml(QString etiqueta, QRadioButton *b1, QRadioButton *b2, QRadioButton *b3,
                                     QString s1, QString s2, QString s3);
extern "C" QString qListWidgetToHtml(QString etiqueta, QListWidget *l);

#endif // HTML_H
