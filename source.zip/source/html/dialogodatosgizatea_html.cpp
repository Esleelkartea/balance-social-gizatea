/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatosgizatea.h"
#include "html.h"

QString DialogoDatosGizatea::toHtml()
{
    QString str="";

    str+=claseHtml("h2","salto",tr("Gizatea"));

    str+=tagHtml("h3",tr("Representante"));
    str+=campoHtml(tr("Nombre y apellidos"),nom_1->text());
    str+=campoHtml(tr("DNI"),dni_1->text());
    str+=campoHtml(tr("Teléfono 1"),telefono_1->text());
    str+=campoHtml(tr("Teléfono 2"),telefono_2->text());
    str+=campoHtml(tr("Email"),email_1->text());

    str+=tagHtml("h3",tr("Suplente"));
    str+=campoHtml(tr("Nombre y apellidos"),nom_2->text());
    str+=campoHtml(tr("DNI"),dni_2->text());
    str+=campoHtml(tr("Teléfono 1"),tel2_1->text());
    str+=campoHtml(tr("Teléfono 2"),tel2_2->text());
    str+=campoHtml(tr("Email"),email_2->text());


    str+=tagHtml("h3",tr("Voluntariado"));
    str+=campoHtml(tr("Hombres"), voluntarios->text());
    str+=campoHtml(tr("Mujeres"), voluntarias->text());
    str+=campoHtml(tr("Total"), vol_total->text());

    str+=tagHtml("h3",tr("Cuota"));
    str+=qRadioButtonToHtml(tr("Cuota"),c_1,c_2,c_3,tr("300 €"), tr("600 €"), tr("1000 €"));
    str+=campoHtml(tr("Nº cuenta corriente"),
                   cuota_entidad->text()+" "+cuota_oficina->text()+" "+cuota_dc->text()+" "+cuota_cuenta->text());

    return str;
}

