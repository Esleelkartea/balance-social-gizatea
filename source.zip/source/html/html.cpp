/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "html.h"


QString campoHtml (QString etiqueta, QString valor) //inline
{
    if (valor!="")
        return "<p><span class=\"c1\">" + etiqueta+":</span> "+valor+"</p>\n";
    else
        return "";
}

QString campoUnidHtml (QString etiqueta, QString valor, QString unid)
{
    if (valor!="")
        return "<p><span class=\"c1\">" + etiqueta+":</span> "+valor+" "+unid+"</p>\n";
    else
        return "";
}


QString campoTrHtml (QString etiqueta, QString valor) //inline
{
    if (valor!="")
        return "<tr><th align=\"left\">"+etiqueta+"</th><td align=\"right\">"+valor+"</td></tr>\n";
    else
        return "";
}

QString campoTagHtml (QString etiqueta, QString tag, QString valor) //inline
{
    if (valor!="")
        return "<"+tag+">" + etiqueta+": "+valor+"</"+tag+">\n";
    else
        return "";
}

QString campoUnidTagHtml (QString etiqueta, QString tag, QString valor, QString unid) //inline
{
    if (valor!="")
        return "<"+tag+">" + etiqueta+": "+valor+" "+unid+"</"+tag+">\n";
    else
        return "";
}

QString euroHtml (QString valor)
{
    if (valor=="")
        return "";
    else {
        double d=valor.toDouble();
        return QLocale().toString(d,'f',2)+" &euro;";
    }
}


QString campoCeroTagHtml (QString etiqueta, QString tag, QString valor) //inline
{
    if (valor!="" && valor!="0")
        return "<"+tag+">" + etiqueta+": "+valor+"</"+tag+">\n";
    else
        return "";
}

QString claseHtml (QString tag, QString clase, QString valor) //inline
{
    if (valor!="")
        return "<"+tag+" class=\""+clase+"\">"+valor+"</"+tag+">\n";
    else
        return "";
}

QString allHtml(QString tag, QString tagclase, QString clase, QString valor)
{
    if (valor!="")
        return "<"+tag+" "+tagclase+"=\""+clase+"\">"+valor+"</"+tag+">\n";
    else
        return "";
}

QString tdRightHtml (QString valor) //inline
{
    return "<td align=\"right\">"+valor+"</td>\n";
}

QString thRightHtml (QString valor) //inline
{
    return "<th align=\"right\">"+valor+"</th>\n";
}


QString tagHtml(QString tag,QString valor)
{
    if (valor!="")
        return "<"+tag+">"+valor+"</"+tag+">";
    else
        return "";
}

QString qRadioButtonToHtml(QString etiqueta, QRadioButton *b1, QRadioButton *b2, QRadioButton *b3,
                          QString s1, QString s2, QString s3)
{
    if (b1->isChecked())
        return campoHtml(etiqueta,s1);
    else if (b2->isChecked())
        return campoHtml(etiqueta,s2);
    else if (b3!=0 && b3->isChecked())
        return campoHtml(etiqueta,s3);
    else
        return "";
}

QString qListWidgetToHtml(QString etiqueta, QListWidget *l)
{
    QString str;
    for (int i=0; i < l->count(); i++)
        if (l->item(i)->isSelected())
            str+="<li>"+l->item(i)->text()+"</li>\n";

    if (str!="")
        return "<p><span class=\"c1\">"+ etiqueta+":</span></p><ul>" +str+"</ul>\n";
    else
        return "";
}


