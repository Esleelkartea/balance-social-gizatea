/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatosgeneral.h"
#include "html.h"


QString DialogoDatosGeneral::toHtml()
{
    QString str="";

    str+=tagHtml("h2",tr("Información general"));

    str+=tagHtml("h3",tr("Identificación"));
    str+=campoHtml(tr("Razón social"), razon_social->text());
    str+=campoHtml(tr("CIF"), cif->text());
    str+=campoHtml(tr("Forma jurídica"), forma_juridica->currentText());
    str+=campoHtml(tr("Año de inicio"), anno_inicio->text());
    str+=campoHtml(tr("Agrupación"), agrupacion->currentText());
    str+=campoHtml(tr("Redes en las que participa"), redes->toPlainText());

    str+=tagHtml("h3",tr("Promotoras"));
    str+="<ul>";
    str+=campoUnidTagHtml(ep_1->text(),"li",p_1->text(),"%");
    str+=campoUnidTagHtml(ep_2->text(),"li",p_2->text(),"%");
    str+=campoUnidTagHtml(ep_3->text(),"li",p_3->text(),"%");
    str+=campoUnidTagHtml(ep_4->text(),"li",p_4->text(),"%");
    str+=campoUnidTagHtml(ep_5->text(),"li",p_5->text(),"%");
    str+=campoUnidTagHtml(ep_6->text(),"li",p_6->text(),"%");
    str+="</ul>";

    str+=tagHtml("h3",tr("Contacto"));
    str+=tagHtml("p",domicilio_social->text());
    str+=tagHtml("p",codigo_postal->text()+" "+poblacion->text()
              +" - "+provincia->currentText()+ " - "
              + comunidad_autonoma->currentText());
    str+=campoHtml(tr("Horario de atención"),horario->text());
    str+=campoHtml(tr("Persona de contacto"),
                   nombre->text() + " - "
                   + telefono_1->text() + " " + telefono_2->text() +" "
                   + email->text());

    str+=claseHtml("h3","salto",tr("Registro"));
    str+=campoHtml(tr("Fecha de registro"), fecha_registro->text());
    str+=campoHtml(tr("EEII"), registro_eeii->text());
    str+=campoHtml(tr("Sociedades Mercantiles"), registro_mercantil->text());
    str+=campoHtml(tr("Sociedades Economía social"), registro_econ_social->text());

    str+=tagHtml("h3",tr("Actividad"));
    str+=campoHtml(tr("Sector"), sector->currentText());
    str+=campoHtml(tr("Actividad 1"), actividad1->currentText());
    str+=campoHtml(tr("Actividad 2"), actividad2->currentText());
    str+=campoHtml(tr("Ámbito"), ambito->currentText());
    str+=campoHtml(tr("Servicios"), servicios->toPlainText());
    return str;
}

