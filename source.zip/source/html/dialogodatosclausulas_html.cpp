/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatosclausulas.h"
#include "html.h"

QString DialogoDatosClausulas::toHtml()
{
    QString str="";
    str+=claseHtml("h2","salto",tr("Cláusulas sociales"));

    str+=tagHtml("h3",tr("General"));

    str+=qRadioButtonToHtml(tr("¿Existen cláusulas sociales en su territorio?"),
                              clausulas_territ_si, clausulas_territ_no, 0,
                              tr("Sí"),tr("No"),"");
    str+=qRadioButtonToHtml(tr("En el año, la EI ¿ha realizado alguna propuesta concreta de incorporación"
                              "de cláusulas sociales a algún ayuntamiento u otra AAPP?"),
                              prop_clausulas_si, prop_clausulas_no, 0, tr("Sí"),tr("No"),"");
    str+=qListWidgetToHtml(tr("¿Cómo lo han hecho?"), lista_prop);
    str+=campoHtml(tr("¿Cuáles han sido los resultados?"), texto_resultados->toPlainText());


    str+=tagHtml("h3",tr("Contratos"));
    str+=campoUnidHtml(tr("Porcentaje que representan las cláusulas sobre el total"
                     "de facturación a la Administración pública"), contratos_1->text(),"%");
    str+=qRadioButtonToHtml(tr("En el año, la EI ¿ha accedido a algún contrato reservado a empresas de inserción?"),
                           contrato_ins_si,contrato_ins_no,0, tr("Sí"),tr("No"),"");
    str+=qListWidgetToHtml(tr("Procedimientos"), lista_procs);
    str+=campoHtml (tr("Importe de los contratos"),euroHtml(texto_contratos->text()));
    str+=campoHtml (tr("Administraciones públicas y obras/servicios"),texto_aapp->toPlainText());


    str+=tagHtml("h3",tr("Licitaciones"));
    str+=qRadioButtonToHtml(tr("En el año, la EI ¿ha ganado alguna licitación que incluyese cláusulas sociales?"),
                           licita_soc_si,licita_soc_no,0, tr("Sí"),tr("No"),"");
    str+=qListWidgetToHtml(tr("Fase del procedimiento en que se incluyeron las cláusulas sociales"),lista_fase);
    str+=qListWidgetToHtml(tr("Cláusulas sociales consideradas"),lista_clausulas);

    return str;
}
