/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatosgestion.h"
#include "html.h"


QString DialogoDatosGestion::toHtml()
{
    QString str="";

    str+=claseHtml("h2","salto",tr("Información de gestión"));

    str+=tagHtml("h3",tr("Personas"));
    str+=qRadioButtonToHtml(tr("¿Cuál es el convenio de la EI?"),
                            pers_sector,pers_empresa,0,
                            tr("Del sector"),tr("De empresa"),"");
    str+=campoHtml(tr("Observaciones"), observaciones_1->toPlainText());


    str+=tagHtml("h3",tr("Calidad"));
    str+=qRadioButtonToHtml(tr("¿La EI tiene implantado algún sistema de calidad?"),
                            calidad_1_si, calidad_1_no, calidad_1_ep,
                            tr ("Sí"), tr("No"),tr("En proceso"));
    str+=campoHtml(tr("¿Cuál?"),calidad_texto1->toPlainText());
    str+=qRadioButtonToHtml(tr("¿La EI tiene alguna certificación de calidad?"),
                            calidad_2_si, calidad_2_no, calidad_2_ep,
                            tr ("Sí"), tr("No"),tr("En proceso"));
    str+=campoHtml(tr("Observaciones"), observaciones_2->toPlainText());


    str+=tagHtml("h3",tr("Igualdad"));
    str+=qRadioButtonToHtml(tr("¿La EI cuenta con medidas de igualdad de oportunidades para hombres y mujeres?"),
                            igualdad_1_si, igualdad_1_no, 0, tr ("Sí"), tr("No"),"");
    str+=campoHtml(tr("¿Cuáles?"),igualdad_texto1->toPlainText());
    str+=qRadioButtonToHtml(tr("¿La EI cuenta con medidas de discriminación positiva?"),
                            igualdad_2_si, igualdad_2_no, 0,
                            tr ("Sí"), tr("No"),"");
    str+=campoHtml(tr("¿Cuáles?"),igualdad_texto2->toPlainText());
    str+=campoHtml(tr("Observaciones"), observaciones_3->toPlainText());


    str+=tagHtml("h3",tr("Conciliación"));
    str+=qRadioButtonToHtml(tr("¿La EI cuenta con medidas de conciliación de vida familiar y laboral?"),
                            conciliacion_si, conciliacion_no, 0, tr ("Sí"), tr("No"),"");
    str+=campoHtml(tr("¿Cuáles?"),conciliacion_texto->toPlainText());
    str+=campoHtml(tr("Observaciones"), observaciones_4->toPlainText());

    str+=claseHtml("h3","salto",tr("Medio ambiente"));
    str+=qRadioButtonToHtml(tr("¿La EI cuenta con medidas de consumo responsable?"),
                            ma_1_si,ma_1_no, 0, tr ("Sí"), tr("No"),"");
    str+=campoHtml(tr("¿Cuáles?"),ma_texto->toPlainText());
    str+=qRadioButtonToHtml(tr("¿La EI cuenta con medidas de ahorro energético?"),
                            ma_2_si,ma_2_no, 0, tr ("Sí"), tr("No"),"");
    str+=qRadioButtonToHtml(tr("¿La EI cuenta con medidas para el reciclaje?"),
                            ma_3_si,ma_3_no, 0, tr ("Sí"), tr("No"),"");
    str+=campoHtml(tr("Observaciones"), observaciones_5->toPlainText());

    str+=tagHtml("h3",tr("Políticas"));
    str+=qRadioButtonToHtml(tr("¿La EI tiene código de ética o similar?"),
                            politicas_si, politicas_no, 0, tr ("Sí"), tr("No"),"");
    str+=campoHtml(tr("Observaciones"), observaciones_6->toPlainText());

    str+=tagHtml("h3",tr("RSE"));
    str+=qRadioButtonToHtml(tr("¿Existe en la empresa alguna otra medida en pro de la RSE?"),
                            politicas_si, politicas_no, 0, tr ("Sí"), tr("No"),"");
    str+=campoHtml(tr("¿Cuáles?"),rse_texto->toPlainText());
    str+=campoHtml(tr("Observaciones"), observaciones_7->toPlainText());

    str+=tagHtml("h3",tr("Otras"));
    str+=campoHtml(tr("Explicar otros posibles planes: Gestión de la diversidad,"\
                      "Compromiso con el diseño para todas las personas,etc."), observaciones_8->toPlainText());

    return str;
}

