/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatossocial.h"
#include "html.h"

QString DialogoDatosSocial::toHtml()
{
    QString str="";

    str+=claseHtml("h2","salto",tr("Información social"));

    str+=personasToHtml();
    str+=puestosEIToHtml();
    str+=puestosEPToHtml();
    str+=jornadasToHtml();
    str+=contratosToHtml();

    return str;
}
QString DialogoDatosSocial::personasToHtml()
{
    QString str="";

    str+=tagHtml("h3",tr("Personas"));
    str+="<br><table width=100%><tr>";

    str+="<th width=50%>"+tr("Personas a lo largo del año")+"</th>";

    str+="<table>";
    str+="<tr>";
    str+="<td width=25%></td><th width=25%>"+tr("Personal inserción")+"</th>"+"<th width=25%>"+tr("Personal no inserción")+"</th><th width=25%>Total</th>";
    str+="</tr>";
    str+="<tr>";
    str+="<th align=\"left\">"+tr("Mujeres")+"</th>";
    str+=tdRightHtml(pers_a_1_1->text()) + tdRightHtml(pers_a_1_2->text()) + thRightHtml(pers_a_1_0->text());
    str+="</tr>";
    str+="<tr>";
    str+="<th align=\"left\">"+tr("Hombres")+"</th>";
    str+=tdRightHtml(pers_a_2_1->text()) + tdRightHtml(pers_a_2_2->text()) + thRightHtml(pers_a_2_0->text());
    str+="</tr>";
    str+="<tr>";
    str+="<th align=\"left\">"+tr("Total")+"</th>";
    str+=thRightHtml(total_personas_ins_anno->text()) + thRightHtml(total_personas_no_ins_anno->text()) + thRightHtml(total_personas_anno->text());
    str+="</tr>";
    str+="</table>";

    str+="<th width=50%>"+tr("Personas a 31-dic")+"</th>";
    str+="<table>";
    str+="<tr>";
    str+="<td width=25%></td><th width=25%>"+tr("Personal inserción")+"</th>"+"<th width=25%>"+tr("Personal no inserción")+"</th><th width=25%>Total</th>";
    str+="</tr>";
    str+="<tr>";
    str+="<th align=\"left\">"+tr("Mujeres")+"</th>";
    str+=tdRightHtml(pers_b_1_1->text())+tdRightHtml(pers_b_1_2->text())+thRightHtml(pers_b_1_0->text());
    str+="</tr>";
    str+="<tr>";
    str+="<th align=\"left\">"+tr("Hombres")+"</th>";
    str+=tdRightHtml(pers_b_2_1->text())+tdRightHtml(pers_b_2_2->text())+thRightHtml(pers_b_2_0->text());
    str+="</tr>";
    str+="<tr>";
    str+="<th align=\"left\">"+tr("Total")+"</th>";
    str+=thRightHtml(total_personas_ins_31dic->text())+thRightHtml(total_personas_no_ins_31dic->text())+thRightHtml(total_personas_31dic->text());
    str+="</tr>";
    str+="</table>";

    str+="</tr></table>";

    return str;
}

QString DialogoDatosSocial::puestosEIToHtml()
{
    QString str="";
    str+=tagHtml("h3",tr("Puestos EI"));
    str+="<br><table>";
    str+="<tr><th width=16%></th>";
    str+="<th width=16%>"+tr("Hombres inserción")+"</th>";
    str+="<th width=16%>"+tr("Mujeres inserción")+"</th>";
    str+="<th width=16%>"+tr("Hombres no inserción")+"</th>";
    str+="<th width=16%>"+tr("Mujeres no inserción")+"</th>";
    str+="<th width=16%>"+tr("Total")+"</th>";
    str+="</tr>";
    str+="<tr><th align=\"left\">"+tr("Dirección / Gerencia")+"</th>";
    str+=tdRightHtml(coma(ei_1_1->text()))
            +tdRightHtml(coma(ei_1_2->text()))
            +tdRightHtml(coma(ei_1_3->text()))
            +tdRightHtml(coma(ei_1_4->text()))
            +thRightHtml(coma(ei_1_0->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Acompañamiento")+"</th>";
    str+=tdRightHtml(coma(ei_2_1->text()))
            +tdRightHtml(coma(ei_2_2->text()))
            +tdRightHtml(coma(ei_2_3->text()))
            +tdRightHtml(coma(ei_2_4->text()))
            +thRightHtml(coma(ei_2_0->text()));
    str+="<tr><th align=\"left\">"+tr("Producción / Comercial")+"</th>";
    str+=tdRightHtml(coma(ei_3_1->text()))
            +tdRightHtml(coma(ei_3_2->text()))+
            tdRightHtml(coma(ei_3_3->text()))+
            tdRightHtml(coma(ei_3_4->text()))
            +thRightHtml(coma(ei_3_0->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Administración")+"</th>";
    str+=tdRightHtml(coma(ei_4_1->text()))
            +tdRightHtml(coma(ei_4_2->text()))
            +tdRightHtml(coma(ei_4_3->text()))
            +tdRightHtml(coma(ei_4_4->text()))
            +thRightHtml(coma(ei_4_0->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Otras funciones")+"</th>";
    str+=tdRightHtml(coma(ei_5_1->text()))
            +tdRightHtml(coma(ei_5_2->text()))
            +tdRightHtml(coma(ei_5_3->text()))
            +tdRightHtml(coma(ei_5_4->text()))
            +thRightHtml(coma(ei_5_0->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Total")+"</th>";
    str+=thRightHtml(coma(ei_0_1->text()))+thRightHtml(coma(ei_0_2->text()))
            +thRightHtml(coma(ei_0_3->text()))+thRightHtml(coma(ei_0_4->text()))
            +thRightHtml(coma(ei_0_0->text()));
    str+="</tr>\n</table>";
    return str;
}

QString DialogoDatosSocial::puestosEPToHtml()
{
    QString str="";
    str+=tagHtml("h3",tr("Puestos EP"));
    str+="<br><table>";
    str+="<tr><th width=25%></th>";
    str+="<th width=25%>"+tr("Hombres inserción")+"</th>";
    str+="<th width=25%>"+tr("Mujeres inserción")+"</th>";
    str+="<th width=25%>"+tr("Total")+"</th>";
    str+="</tr>";
    str+="<tr><th align=\"left\">"+tr("Dirección / Gerencia")+"</th>";
    str+=tdRightHtml(coma(ep_1_1->text()))+tdRightHtml(coma(ep_1_2->text()))+thRightHtml(coma(ep_01->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Acompañamiento")+"</th>";
    str+=tdRightHtml(coma(ep_2_1->text()))+tdRightHtml(coma(ep_2_2->text()))+thRightHtml(coma(ep_02->text()));
    str+="<tr><th align=\"left\">"+tr("Producción / Comercial")+"</th>";
    str+=tdRightHtml(coma(ep_3_1->text()))+tdRightHtml(coma(ep_3_2->text()))+thRightHtml(coma(ep_03->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Administración")+"</th>";
    str+=tdRightHtml(coma(ep_4_1->text()))+tdRightHtml(coma(ep_4_2->text()))+thRightHtml(coma(ep_04->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Otras funciones")+"</th>";
    str+=tdRightHtml(coma(ep_5_1->text()))+tdRightHtml(coma(ep_5_2->text()))+thRightHtml(coma(ep_05->text()));
    str+="</tr>\n<tr><th align=\"left\">"+tr("Total")+"</th>";
    str+=thRightHtml(coma(ep_1->text()))+thRightHtml(coma(ep_2->text()))+thRightHtml(coma(ep_06->text()));
    str+="</tr>\n</table>";
    return str;
}

QString DialogoDatosSocial::jornadasToHtml()
{
    QString str="";
    str+=claseHtml("h3","salto",tr("Jornadas"));
    str+="<br><table>";
    str+="<tr><th width=25%></th>";
    str+="<th width=25%>"+tr("Hombres inserción")+"</th>";
    str+="<th width=25%>"+tr("Mujeres inserción")+"</th>";
    str+="<th width=25%>"+tr("Total")+"</th>";
    str+="</tr>";
    str+="<tr><th align=\"left\">"+tr("Jornada completa")+"</th>";
    str+=tdRightHtml(jornadas_1_1->text())+tdRightHtml(jornadas_1_2->text())+thRightHtml(jornadas_1_0->text());
    str+="</tr>\n<tr><th align=\"left\">"+tr("Jornada parcial")+"</th>";
    str+=tdRightHtml(jornadas_2_1->text())+tdRightHtml(jornadas_2_2->text())+thRightHtml(jornadas_2_0->text());
    str+="</tr>\n<tr><th align=\"left\">"+tr("Total")+"</th>";
    str+=thRightHtml(jornadas_0_1->text())+thRightHtml(jornadas_0_2->text())+thRightHtml(jornadas_total->text());
    str+="</tr>\n</table>";
    return str;
}

QString DialogoDatosSocial::contratosToHtml()
{
    QString str="";

    str+=tagHtml("h3",tr("Contratos"));
    str+=campoHtml(tr("Total"),contratos_total->text());
    str+="<br><table><tr>";

    str+="<td>";
    str+=campoHtml(tr("Contratos inserción (Ley 44/2007)"),contratos_ins->text());
    str+=campoHtml("Indefinidos"," ");
    str+="<ul>\n";
    str+=campoCeroTagHtml (tr("Tiempo completo (150)"), "li", c_1_1->text());
    str+=campoCeroTagHtml (tr("Tiempo parcial (250)"), "li", c_1_2->text());
    str+=campoCeroTagHtml (tr("Fijo discontinuo (350)"), "li", c_1_3->text());
    str+="</ul>\n";
    str+=campoHtml(tr("Temporales de duración determinada")," ");
    str+="<ul>\n";
    str+=campoCeroTagHtml (tr("Tiempo completo (450)"), "li", c_2_1->text());
    str+=campoCeroTagHtml (tr("Tiempo parcial (550)"), "li", c_2_2->text());
    str+="</ul>\n";
    str+=campoHtml(tr("Temporales de fomento del empleo")," ");
    str+="<ul>\n";
    str+=campoCeroTagHtml (tr("Tiempo completo (452)"), "li", c_3_1->text());
    str+=campoCeroTagHtml (tr("Tiempo parcial (552)"), "li", c_3_2->text());
    str+="</ul>\n";
    str+="</td>";

    str+="<td>";
    str+=campoHtml(tr("Contratos no inserción"),contratos_no_ins->text());
    str+=campoHtml("Indefinidos"," ");
    str+="<ul>\n";
    str+=campoCeroTagHtml (tr("Tiempo completo (100)"), "li", c_4_1->text());
    str+=campoCeroTagHtml (tr("Tiempo parcial (200)"), "li", c_4_2->text());
    str+=campoCeroTagHtml (tr("Fijo discontinuo (300)"), "li", c_4_3->text());
    str+="</ul>\n";
    str+=campoHtml(tr("Duración determinada")," ");
    str+="<ul>\n";
    str+=campoCeroTagHtml (tr("Obra o servicio determinado – TC (401)"),"li", c_5_1->text());
    str+=campoCeroTagHtml (tr("Obra o servicio determinado – TP (501)"),"li", c_5_2->text());
    str+=campoCeroTagHtml (tr("Eventual circunstancias de la producción – TC (402)"),"li", c_5_3->text());
    str+=campoCeroTagHtml (tr("Eventual circunstancias de la producción – TP (502)"),"li", c_5_4->text());
    str+=campoCeroTagHtml (tr("Interinidad – TC (410)"),"li", c_5_5->text());
    str+=campoCeroTagHtml (tr("Interinidad – TP (510)"),"li", c_5_6->text());
    str+="</ul>\n";

    str+=campoHtml(tr("Temporales")," ");
    str+="<ul>\n";
    str+=campoCeroTagHtml (tr("Prácticas – TC (420)"),"li", c_6_1->text());
    str+=campoCeroTagHtml (tr("Prácticas – TP (520)"),"li", c_6_2->text());
    str+=campoCeroTagHtml (tr("Discapacitados - TP (430)"),"li", c_6_3->text());
    str+=campoCeroTagHtml (tr("Discapacitados - TP (530)"),"li", c_6_4->text());
    str+="</ul>\n";

    if (o_5->text()!="0")
        str+=campoHtml(tr("Otros tipos de contrato"),o_5->text());
    str+="</td>";

    str+="</tr>\n</table>";
    return str;
}

QString DialogoDatosSocial::coma(QString str)
{
    double d=QLocale().toDouble(str);
    if (str.contains(",") && !str.endsWith(",00"))
        return QLocale().toString(d,'f',2);
    else
        return QLocale().toString(d,'f',0);
}
