/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatosecon.h"
#include "html.h"

QString DialogoDatosEcon::toHtml()
{
    QString str="";

    str+=claseHtml("h2","salto",tr("Información económica"));

    str+=tagHtml("h3",tr("Cuenta Pérdidas y Ganancias"));
    str+=arbolToHtml(arbol_pyg);

    QString arbol;
    arbol=arbolToHtml(arbol_activo);
    if (arbol=="<table></table>")
        str+=tagHtml("h3",tr("Activo"));
    else
        str+=claseHtml("h3","salto",tr("Activo"));
    str+=arbol;

    arbol=arbolToHtml(arbol_pasivo);
    if (arbol=="<table></table>")
        str+=tagHtml("h3",tr("Patrimonio neto y Pasivo"));
    else
        str+=claseHtml("h3","salto",tr("Patrimonio neto y Pasivo"));
    str+=arbol;

    str+=claseHtml("h3","salto",tr("Ayudas"));
    str+=tagHtml("p",tr("Ayudas a empresas de inserción:"));
    str+="<p>&nbsp;</p><table>";
    str+="<tr><th align=\"left\">"+tr("Empleo inserción")+"</th>"+tdRightHtml(euroHtml(ayudas_1->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Técn. acompañamiento")+"</th>"+tdRightHtml(euroHtml(ayudas_2->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Inversiones")+"</th>"+tdRightHtml(euroHtml(ayudas_3->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Asistencias técnicas")+"</th>"+tdRightHtml(euroHtml(ayudas_4->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Otros conceptos")+"</th>"+tdRightHtml(euroHtml(ayudas_5->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Total")+"</th>"+thRightHtml(euroHtml(total_ayudas_1->text()))+"</tr>\n";
    str+="</table>";

    str+=tagHtml("p",tr("Otras ayudas:"));
    str+="<p>&nbsp;</p><table>";
    str+="<tr><th align=\"left\">"+tr("Subvenciones públicas")+"</th>"+tdRightHtml(euroHtml(subv_1->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Subvenciones privadas")+"</th>"+tdRightHtml(euroHtml(subv_2->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Total")+"</th>"+thRightHtml(euroHtml(total_ayudas_2->text()))+"</tr>\n";
    str+="</table>";

    str+=tagHtml("h3",tr("Clientela"));
    str+="<ul>";
    str+=campoUnidTagHtml(tr("Facturación sector privado"),"li",clientes_1->text(),"%");
    str+=campoUnidTagHtml(tr("Facturación sector público"),"li",clientes_2->text(),"%");
    str+="<b>"+campoUnidTagHtml(tr("Total"),"li",clientes_total->text(),"%")+"</b>";
    str+="</ul>";
    return str;
}


QString DialogoDatosEcon::arbolToHtml(QTreeWidget *p)
{
    QString str;
    str="<table>";
    QList <QTreeWidgetItem *> l = p->findItems("*",Qt::MatchWildcard,1);
    for (int i=0; i<l.size(); i++)
        str+=nodoToHtml (l.at(i));
    str+="</table>";
    return str;
}


QString DialogoDatosEcon::nodoToHtml(QTreeWidgetItem *p)
{
    QString str;

    if (p->data(2,Qt::DisplayRole)!="0,00") {
        str="<tr>";
        QString partida=p->data(1,Qt::DisplayRole).toString();
        if (partida.startsWith("   "))
            partida="&nbsp;&nbsp;&nbsp;"+partida;
        else if (partida.startsWith("  "))
            partida="&nbsp;&nbsp;"+partida;
        else if (partida.startsWith(" "))
            partida="&nbsp;"+partida;
        if (p->font(1).bold()) {
            str+="<td><b>"+partida+"</b></td>";
            str+="<td align=\"right\"><b>"+p->data(2,Qt::DisplayRole).toString()+"</b></td>";
        } else {
            str+="<td>"+partida+"</td>";
            str+="<td align=\"right\">"+p->data(2,Qt::DisplayRole).toString()+"</td>";
        }
        str+="</tr>\n";
    }

    for (int i=0; i<p->childCount() ; i++)
        str+=nodoToHtml(p->child(i));
    return str;
}
