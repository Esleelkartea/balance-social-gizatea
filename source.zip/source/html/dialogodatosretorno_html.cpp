/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "../dialogodatosretorno.h"
#include "html.h"

QString DialogoDatosRetorno::toHtml()
{
    QString str="";

    str+=claseHtml("h2","salto",tr("Retorno social"));

    str+=tagHtml("h3",tr("Fiscalidad"));
    str+="<br><table>";
    str+="<tr><th align=\"left\">"+tr("IVA o situaciones especiales (IGIC)")+"</th>"+tdRightHtml(euroHtml(iva->text()))+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Impuesto de sociedades")+"</th>"+tdRightHtml(euroHtml(imp_socs->text()))+"</tr>";
    str+="<tr><th align=\"left\">"+tr("Otros tributos")+"</th>"+tdRightHtml(euroHtml(otros_tributos->text()))+"</tr>";
    str+="<tr><th align=\"left\">"+tr("IRPF")+"</th>"+tdRightHtml(euroHtml(irpf->text()))+"</tr>";
    str+="</table>";
    str+="<br>";

    str+=tagHtml("h3",tr("Gastos en personal"));
    str+="<br><table>";
    str+="<tr><td width=25%></td><th width=25%>"+tr("Trabajador/a de inserción")+"</th><th width=25%>"
            +tr("Técnico/a acompañamiento")+"</th><th width=25%>"+tr("Técnico/a producción")+"</th></tr>\n";
    str+="<tr><th align=\"left\">"+tr("Salario neto")+"</th>"
            +tdRightHtml(euroHtml(gastos_1_1->text()))
            +tdRightHtml(euroHtml(gastos_1_2->text()))
            +tdRightHtml(euroHtml(gastos_1_3->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("IRPF empleado/a")+"</th>"
            +tdRightHtml(euroHtml(gastos_2_1->text()))
            +tdRightHtml(euroHtml(gastos_2_2->text()))
            +tdRightHtml(euroHtml(gastos_2_3->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Seg. social empleado/a")+"</th>"
            +tdRightHtml(euroHtml(gastos_3_1->text()))
            +tdRightHtml(euroHtml(gastos_3_2->text()))
            +tdRightHtml(euroHtml(gastos_3_3->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Salario bruto")+"</th>"
            +tdRightHtml(euroHtml(gastos_1_4->text()))
            +tdRightHtml(euroHtml(gastos_1_5->text()))
            +tdRightHtml(euroHtml(gastos_1_6->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Seg. social empresa")+"</th>"
            +tdRightHtml(euroHtml(gastos_5_1->text()))
            +tdRightHtml(euroHtml(gastos_5_2->text()))
            +tdRightHtml(euroHtml(gastos_5_3->text()))+"</tr>\n";
    str+="<tr><th align=\"left\">"+tr("Total")+"</th>"
            +thRightHtml(euroHtml(gastos_2_4->text()))
            +thRightHtml(euroHtml(gastos_2_5->text()))
            +thRightHtml(euroHtml(gastos_2_6->text()))+"</tr>\n";
    str+="</table>";

    return str;

}

