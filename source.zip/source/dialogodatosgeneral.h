/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGO_DATOS_GENERAL_H
#define DIALOGO_DATOS_GENERAL_H

#include "dialogodatos.h"
#include "ui_dialogodatosgeneral.h"

class DialogoDatosGeneral : public DialogoDatos, public Ui::DialogoDatosGeneral
{
  Q_OBJECT

public:
    DialogoDatosGeneral(QWidget *parent=0);
    QString razonSocial() {return razon_social->text();};
    void actualizarForm();
    QString getAgrupacion() {return agrupacion->currentText();}

private:
    QMap <QString, QStringList> lista_com_prv;

    void setComunidades();
    int validarWidget(QLineEdit *ptr);
    int validarWidget(QDateEdit *ptr);
    void triggerOutWidget (QComboBox *object, int *cambia);
    int validarPromotoras (QLineEdit *e, bool flag_valor);
    QString toHtml();

signals:
  void coop(QString text);

private slots:
  void on_forma_juridica_currentIndexChanged(const QString &text) {emit coop(text);}
  void on_comunidad_autonoma_currentIndexChanged(const QString &text);

};

#endif // DIALOGO_DATOS_GENERAL_H
