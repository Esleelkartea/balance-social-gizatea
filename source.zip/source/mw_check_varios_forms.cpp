/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "mainwindow.h"
#include "dialogodatossocial.h"
#include "dialogodatosinsercion.h"
#include <QtGui>
#include "mensajes.h"

bool MainWindow::checkPersonasI()
{
    QString aviso;
    int personas, permanencia, proceso;

    personas=dialogoDatosSocial->total_personas_ins_anno->text().toInt();

    permanencia=dialogoDatosInsercion->p_total->text().toInt();
    if (personas != permanencia) {
        aviso = QObject::tr(MSG_D_VARIOS_ERR_1).arg(QString::number(personas)).arg(QString::number(permanencia));
        QMessageBox::warning(0,QObject::tr(MSG_VALIDACION),aviso);
        return false;
    }

    proceso=dialogoDatosInsercion->proceso_a0->text().toInt();
    if (personas != proceso) {
        aviso = QObject::tr(MSG_D_VARIOS_ERR_2).arg(QString::number(personas)).arg(QString::number(proceso));
        QMessageBox::warning(0,QObject::tr(MSG_VALIDACION),aviso);
        return false;
    }

    return true;
}
