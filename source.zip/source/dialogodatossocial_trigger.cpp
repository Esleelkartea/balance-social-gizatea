/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatossocial.h"

void DialogoDatosSocial::triggerOutWidget(QLineEdit *e)
{
    if (e==pers_a_1_1) sumaGrid((QGridLayout*)g_personas_1->layout(),1,1);
    if (e==pers_a_1_2) sumaGrid((QGridLayout*)g_personas_1->layout(),1,2);
    if (e==pers_a_2_1) sumaGrid((QGridLayout*)g_personas_1->layout(),2,1);
    if (e==pers_a_2_2) sumaGrid((QGridLayout*)g_personas_1->layout(),2,2);

    if (e==pers_b_1_1) sumaGrid((QGridLayout*)g_personas_2->layout(),1,1);
    if (e==pers_b_1_2) sumaGrid((QGridLayout*)g_personas_2->layout(),1,2);
    if (e==pers_b_2_1) sumaGrid((QGridLayout*)g_personas_2->layout(),2,1);
    if (e==pers_b_2_2) sumaGrid((QGridLayout*)g_personas_2->layout(),2,2);


    if (e==ei_1_1) sumaGrid(grid_ei,1,1);
    if (e==ei_1_2) sumaGrid(grid_ei,1,2);
    if (e==ei_1_3) sumaGrid(grid_ei,1,3);
    if (e==ei_1_4) sumaGrid(grid_ei,1,4);
    if (e==ei_2_1) sumaGrid(grid_ei,2,1);
    if (e==ei_2_2) sumaGrid(grid_ei,2,2);
    if (e==ei_2_3) sumaGrid(grid_ei,2,3);
    if (e==ei_2_4) sumaGrid(grid_ei,2,4);
    if (e==ei_3_1) sumaGrid(grid_ei,3,1);
    if (e==ei_3_2) sumaGrid(grid_ei,3,2);
    if (e==ei_3_3) sumaGrid(grid_ei,3,3);
    if (e==ei_3_4) sumaGrid(grid_ei,3,4);
    if (e==ei_4_1) sumaGrid(grid_ei,4,1);
    if (e==ei_4_2) sumaGrid(grid_ei,4,2);
    if (e==ei_4_3) sumaGrid(grid_ei,4,3);
    if (e==ei_4_4) sumaGrid(grid_ei,4,4);
    if (e==ei_5_1) sumaGrid(grid_ei,5,1);
    if (e==ei_5_2) sumaGrid(grid_ei,5,2);
    if (e==ei_5_3) sumaGrid(grid_ei,5,3);
    if (e==ei_5_4) sumaGrid(grid_ei,5,4);

    if (e==ep_1_1) sumaGrid(grid_ep,1,1);
    if (e==ep_1_2) sumaGrid(grid_ep,1,2);
    if (e==ep_2_1) sumaGrid(grid_ep,2,1);
    if (e==ep_2_2) sumaGrid(grid_ep,2,2);
    if (e==ep_3_1) sumaGrid(grid_ep,3,1);
    if (e==ep_3_2) sumaGrid(grid_ep,3,2);
    if (e==ep_4_1) sumaGrid(grid_ep,4,1);
    if (e==ep_4_2) sumaGrid(grid_ep,4,2);
    if (e==ep_5_1) sumaGrid(grid_ep,5,1);
    if (e==ep_5_2) sumaGrid(grid_ep,5,2);

    if (e==jornadas_1_1) sumaGrid(grid_jornadas,1,1);
    if (e==jornadas_1_2) sumaGrid(grid_jornadas,1,2);
    if (e==jornadas_2_1) sumaGrid(grid_jornadas,2,1);
    if (e==jornadas_2_2) sumaGrid(grid_jornadas,2,2);

    if (e==c_1_1) sumaContratos();
    if (e==c_1_2) sumaContratos();
    if (e==c_1_3) sumaContratos();
    if (e==c_2_1) sumaContratos();
    if (e==c_2_2) sumaContratos();
    if (e==c_3_1) sumaContratos();
    if (e==c_3_2) sumaContratos();
    if (e==c_4_1) sumaContratos();
    if (e==c_4_2) sumaContratos();
    if (e==c_4_3) sumaContratos();
    if (e==c_5_1) sumaContratos();
    if (e==c_5_2) sumaContratos();
    if (e==c_5_3) sumaContratos();
    if (e==c_5_4) sumaContratos();
    if (e==c_5_5) sumaContratos();
    if (e==c_5_6) sumaContratos();
    if (e==c_6_1) sumaContratos();
    if (e==c_6_2) sumaContratos();
    if (e==c_6_3) sumaContratos();
    if (e==c_6_4) sumaContratos();
}

void DialogoDatosSocial::sumaContratos()
{
    int suma1=0, suma2=0;
    QList <QLineEdit *> l1, l2;
    l1 << c_1_1 << c_1_2 << c_1_3 << c_2_1 << c_2_2 << c_3_1 << c_3_2;
    l2 << c_4_1 << c_4_2 << c_4_3 << c_5_1 << c_5_2 << c_5_3 << c_5_4 << c_5_5 << c_5_6
       << c_6_1 << c_6_2 << c_6_3 << c_6_4 << o_5;

    for (int i=0; i<l1.size(); i++)
        suma1 += l1.at(i)->text().toDouble();
    contratos_ins->setText(QLocale().toString(suma1));

    for (int i=0; i<l2.size(); i++)
        suma2 += l2.at(i)->text().toDouble();
    contratos_no_ins->setText(QLocale().toString(suma2));

    contratos_total->setText(QLocale().toString(suma1+suma2));
}
