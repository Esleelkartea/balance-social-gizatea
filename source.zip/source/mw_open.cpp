/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QtGui>
#include <QDomDocument>
#include "mainwindow.h"
#include "dialogodatosgeneral.h"
#include "dialogodatosecon.h"
#include "mensajes.h"

void MainWindow::openMenu()
{
    if (!saved) {
        int ret= QMessageBox::warning(this, QObject::tr(MSG_APP),QObject::tr(MSG_WARN_SAVE_OPEN),
                                   QMessageBox::Yes | QMessageBox::No, QMessageBox::Yes);
        if (ret==QMessageBox::Yes) {
            if (fichero=="") saveMenu();
            else saveAsMenu();
        }
    }

    QString fileName = QFileDialog::getOpenFileName(this, QObject::tr(MSG_ABRIR_FICH_BALANCE),
                                                    QDir::currentPath(),
                                                    tr("Ficheros XBSL (*.xbsl *.xml)"));
    if (fileName.isEmpty())
        return;

    QDomDocument xbsl;
    if (leeXbsl(fileName, &xbsl)==-1)
        return;
    QDomElement root = xbsl.documentElement();
    QDomElement info = root.firstChildElement();
    anno=info.attribute("anno").toInt();
    QString razon_social=info.attribute("razonsocial");

    createDialogosDatos();
    int anno_anterior = QDateTime::currentDateTime().addYears(-1).toString("yyyy").toInt();
    if (anno==anno_anterior)
        for (int i=0; i<dialogosDatos.size(); i++)
            dialogosDatos.at(i)->fromXbsl(xbsl);
    else
        dialogoDatosGeneral->fromXbsl(xbsl);

    setMenuRed(dialogoDatosGeneral->getAgrupacion());

    saved = true;
    fichero = fileName;
    actionGuardar->setEnabled(true);
    if (razon_social.length()>20)
            razon_social = razon_social.left(20)+"...";
    setWindowTitle(tr("Balance Social")+" - "+ razon_social+"/"+ QString::number(anno)  + " - "+ fichero);


    statusBar()->showMessage(QObject::tr(MSG_FICHERO_CARGADO), 2000);
}


int MainWindow::leeXbsl(QString fileName, QDomDocument *xbsl)
{
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly | QFile::Text)) {
        QMessageBox::critical(this, QObject::tr(MSG_FICH_BALANCE),
                              QObject::tr(MSG_ERR_OPEN).arg(fileName).arg(file.errorString()));
        return -1;
    }

    QString errorStr;
    int errorLine;
    int errorColumn;

    if (!xbsl->setContent(&file, true, &errorStr, &errorLine, &errorColumn)) {
        QMessageBox::critical(0, QObject::tr(MSG_FICH_BALANCE), QObject::tr(MSG_ERR_DOM).arg(errorLine).arg(errorColumn).arg(errorStr));
        file.close();
        return -1;
    }

    QDomElement root = xbsl->documentElement();
    if (root.tagName() != "xbsl") {
        QMessageBox::critical(0, QObject::tr(MSG_FICH_BALANCE), QObject::tr(MSG_ERR_FORMATO_FICH_BALANCE));
        file.close();
        return -1;
    }

    if (root.hasAttribute("version")
            && root.attribute("version") != "1.0") {
        QMessageBox::warning(0, QObject::tr(MSG_FICH_BALANCE), QObject::tr(MSG_ERR_VERSION_FICH_BALANCE));
        file.close();
        return -1;
    }

    QDomElement info = root.firstChildElement();
    if (!info.hasAttribute("anno")) {
        QMessageBox::critical(0, QObject::tr(MSG_FICH_BALANCE),QObject::tr(MSG_ERR_ANNO_FICH_BALANCE));
        file.close();
        return -1;
    }

    if (!info.hasAttribute("razonsocial")) {
        QMessageBox::critical(0, QObject::tr(MSG_FICH_BALANCE),QObject::tr(MSG_ERR_RAZON_SOCIAL_FICH_BALANCE));
        file.close();
        return -1;
    }

    file.close();
    return 1;
}

