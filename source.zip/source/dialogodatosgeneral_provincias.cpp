/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosgeneral.h"

void DialogoDatosGeneral::setComunidades()
{
    QStringList l;

    l << "";
    lista_com_prv[tr("")] << l;

    l.clear();
    l << "" << tr("Almería") << tr("Cádiz") << tr("Córdoba")
      << tr("Granada") << tr("Huelva") << tr("Jaén")
      << tr("Málaga") << tr("Sevilla");
    lista_com_prv[tr("Andalucia")] << l;

    l.clear();
    l << "" << tr("Huesca") << tr("Teruel") << tr("Zaragoza");
    lista_com_prv[tr("Aragón")] << l;

    l.clear();
    l << "" << tr("Las Palmas") << tr("Tenerife");
    lista_com_prv[tr("Canarias")] << l;

    l.clear();
    l << tr("Cantabria");
    lista_com_prv[tr("Cantabria")] << l;

    l.clear();
    l << "" << tr("Ávila") << tr("Burgos") << tr("León")
      << tr("Palencia") << tr("Salamanca") << tr("Segovia")
      << tr("Soria") << tr("Valladolid") << tr("Zamora");
    lista_com_prv[tr("Castilla y León")] << l;

    l.clear();
    l << "" << tr("Albacete") << tr("Ciudad Real")
      << tr("Cuenca") << tr("Guadalajara") << tr("Toledo");
    lista_com_prv[tr("Castilla-La Mancha")] << l;

    l.clear();
    l << "" << tr("Barcelona") << tr("Girona")
         << tr("Lleida") << tr("Tarragona");
    lista_com_prv[tr("Catalunya")] << l;

    l.clear();
    l << "" << tr("Ceuta") << tr("Melilla");
    lista_com_prv[tr("Ceuta y Melilla")] << l;

    l.clear();
    l << "" << tr("Alacant") << tr("Castelló") << tr("València");
    lista_com_prv[tr("Comunitat Valenciana")] << l;

    l.clear();
    l << "" << tr("Araba") << tr("Bizkaia") << tr("Gipuzkoa");
    lista_com_prv[tr("Euskadi")] << l;

    l.clear();
    l << "" << tr("Badajoz") << tr("Cáceres");
    lista_com_prv[tr("Extremadura")] << l;

    l.clear();
    l << "" << tr("A Coruña") << tr("Lugo")
      << tr("Ourense") << tr("Pontevedra");
    lista_com_prv[tr("Galicia")] << l;

    l.clear();
    l << tr("Illes Balears");
    lista_com_prv[tr("Illes Balears")] << l;

    l.clear();
    l << tr("La Rioja");
    lista_com_prv[tr("La Rioja")] << l;

    l.clear();
    l << tr("Madrid");
    lista_com_prv[tr("Madrid")] << l;

    l.clear();
    l << tr("Murcia");
    lista_com_prv[tr("Murcia")] << l;

    l.clear();
    l << tr("Navarra");
    lista_com_prv[tr("Navarra")] << l;

    l.clear();
    l << tr("Asturias");
    lista_com_prv[tr("Principado de Asturias")] << l;

    QMapIterator<QString, QStringList> i(lista_com_prv);
    while (i.hasNext()) {
        i.next();
        comunidad_autonoma->addItem(i.key());
    }
}

void DialogoDatosGeneral::on_comunidad_autonoma_currentIndexChanged(const QString &text)
{
    if (text!="") {
        provincia->clear();
        provincia->addItems(lista_com_prv.value(text));
        provincia->show();
    } else {
        provincia->clear();
        provincia->hide();
    }
}
