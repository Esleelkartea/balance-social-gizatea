/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef ARBOL_DELEGADO_H
#define ARBOL_DELEGADO_H

class QTreeWidget;
#include <QItemDelegate>

class ArbolDelegado : public QItemDelegate
{
  Q_OBJECT

public:
    ArbolDelegado(QObject *parent, QString str):QItemDelegate(parent){nombreArbol=str;};

  void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const;
  QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const;
  void setEditorData(QWidget *editor, const QModelIndex &index) const;
  void setModelData(QWidget *editor, QAbstractItemModel *model,
                      const QModelIndex &index) const;

private:
  QString nombreArbol;
  void recorre(QAbstractItemModel *model, const QModelIndex &index) const;

signals:
  void actualizaArbol(QString str);

};


#endif
