<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="eu_ES">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>DialogoAcercaDe</name>
    <message>
        <source>Acerca de</source>
        <translation>Ri buruz</translation>
    </message>
    <message>
        <source>Balance Social v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Este programa ha sido desarrollado gracias a Gizatea,
la Asociación de empresas de inserción del País Vasco</source>
        <translation>Programa hau Gizateari esker eginda dago,
Gizarteratzeko eta laneratzeko Euskadiko Enpresen Elkartea</translation>
    </message>
    <message>
        <source>Licencia de este software:</source>
        <translation>Software honen lizentzia</translation>
    </message>
    <message>
        <source>Este programa es software libre bajo los términos
de la licencia GPLv3</source>
        <translation>Programa hau software askea da
GPLv3 lizentziaren arabera</translation>
    </message>
    <message>
        <source>Autor:</source>
        <translation>Egilea:</translation>
    </message>
    <message>
        <source>Dani Gutiérrez Porset (a.k.a. danitxu)
jdanitxu@gmail.com</source>
        <translation></translation>
    </message>
    <message>
        <source>Software empleado:</source>
        <translation>Erabilitako software:</translation>
    </message>
    <message>
        <source>-Runtime: mingw, librerías qt
-Desarrollo: Qt Creator, gimp, emacs</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>DialogoAyuda</name>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Cerrar</source>
        <translation>Itxi</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoDatosClausulas</name>
    <message>
        <source>Cláusulas sociales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sí</source>
        <translation>Bai</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ez</translation>
    </message>
    <message>
        <source>¿Cómo lo han hecho?</source>
        <translation>Nola lortu dute?</translation>
    </message>
    <message>
        <source>¿Cuáles han sido los resultados?</source>
        <translation>Zein izan dira emaitzak?</translation>
    </message>
    <message>
        <source>Otros</source>
        <translation>Beste batzuk</translation>
    </message>
    <message>
        <source>Contratos</source>
        <translation>Kontratuak</translation>
    </message>
    <message>
        <source>Procedimientos</source>
        <translation>Prozedurak</translation>
    </message>
    <message>
        <source>Calidad en el empleo</source>
        <translation>Kalitatea enpleguan</translation>
    </message>
    <message>
        <source>Perspectiva de género</source>
        <translation>Genero ikuspuntua</translation>
    </message>
    <message>
        <source>Otras</source>
        <translation>Beste batzuk</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>Facturación Privados (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Facturación Admin. pública (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0,00</source>
        <translation></translation>
    </message>
    <message>
        <source>¿Existen cláusulas sociales en su territorio?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_clausulas_1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>En el año, la EI ¿ha realizado alguna
propuesta concreta de incorporación
de cláusulas sociales a
algún ayuntamiento u otra AAPP?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_clausulas_2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reunión con alcaldía</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reunión con concejalías</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reunión con partidos de la oposición</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reunión con personal técnico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Porcentaje que representan las cláusulas sobre el total
de facturación a la Administración pública</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>En el año, la EI ¿ha accedido a algún contrato reservado
a empresas de inserción?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_contratos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Importe de los contratos (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Administraciones públicas
y obras/servicios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contrato menor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Negociado sin publicidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Licitaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>En el año, la EI ¿ha ganado alguna licitación
que incluyese cláusulas sociales?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_licitaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fase del procedimiento
en que se incluyeron
las cláusulas sociales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fase de admisión de licitadores mediante solvencia técnica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fase de adjudicación mediante criterios de valoración</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Condiciones de ejecución</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cláusulas sociales
consideradas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contratación de personas con discapacidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contratación de personas en situación o riesgo de exclusión social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subcontratación de empresas de inserción sociolaboral o centros especiales de empleo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoDatosEcon</name>
    <message>
      <source>Porcentajes de facturación por sectores:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Información económica</source>
        <translation type="unfinished">Informazio ekonomikoa</translation>
    </message>
    <message>
        <source>Ayudas</source>
        <translation>Laguntzak</translation>
    </message>
    <message>
        <source>Total</source>
        <translation>Guztira</translation>
    </message>
    <message>
        <source>Otras ayudas</source>
        <translation>Beste laguntzak</translation>
    </message>
    <message>
        <source>Subvenciones públicas</source>
        <translation>Dirulaguntza publikoak</translation>
    </message>
    <message>
        <source>Subvenciones privadas</source>
        <translation>Dirulaguntza pribatuak</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>Sociedad cooperativa</source>
        <translation>Sozietate kooperatiboa</translation>
    </message>
    <message>
        <source>Cuenta PyG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>+</source>
        <translation></translation>
    </message>
    <message>
        <source>-</source>
        <translation></translation>
    </message>
    <message>
        <source>.</source>
        <translation></translation>
    </message>
    <message>
        <source>Epígrafe</source>
        <translation>Epigrafea</translation>
    </message>
    <message>
        <source>€</source>
        <translation></translation>
    </message>
    <message>
        <source>Activo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Patr. Neto y Pasivo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ayudas a empresas de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empleo inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cantidad (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Partida PyG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Técn. acompañamiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Inversiones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Asistencias técnicas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otros conceptos</source>
        <translation>Beste kontzeptu batzuk</translation>
    </message>
    <message>
        <source>0,00</source>
        <translation></translation>
    </message>
    <message>
        <source>5.Otros ingresos de explotación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9.Imputación de subvenciones de Inm. No Fro. y otras</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoDatosGeneral</name>
    <message>
        <source>Información general</source>
        <translation>Informazio orokorra</translation>
    </message>
    <message>
        <source>Razón social</source>
        <translation>Enpresa-izena</translation>
    </message>
    <message>
        <source>Forma jurídica</source>
        <translation>Gisa juridikoa</translation>
    </message>
    <message>
        <source>Sociedad cooperativa</source>
        <translation>Sozietate kooperatiboa</translation>
    </message>
    <message>
        <source>Sociedad limitada</source>
        <translation>Sozietate mugatua</translation>
    </message>
    <message>
        <source>Otras</source>
        <translation>Beste batzuk</translation>
    </message>
    <message>
        <source>Año de inicio</source>
        <translation>Hasierako urtea</translation>
    </message>
    <message>
        <source>Redes</source>
        <translation>Sareak</translation>
    </message>
    <message>
        <source>Promotoras</source>
        <translation>Sustatzaileak</translation>
    </message>
    <message>
        <source>Entidad promotora</source>
        <translation>Erakude sustatzailea</translation>
    </message>
    <message>
        <source>Participación (%)</source>
        <translation>Partaidetza (%)</translation>
    </message>
    <message>
        <source>Contacto</source>
        <translation>Kontaktua</translation>
    </message>
    <message>
        <source>Domicilio Social</source>
        <translation>Helbidea</translation>
    </message>
    <message>
        <source>Código Postal</source>
        <translation>Posta Kodea</translation>
    </message>
    <message>
        <source>Población</source>
        <translation>Herria/Hiria</translation>
    </message>
    <message>
        <source>Comunidad autónoma</source>
        <translation>Aautonomi Erkidegoa</translation>
    </message>
    <message>
        <source>Horario de atención</source>
        <translation>Arreta ordutegia</translation>
    </message>
    <message>
        <source>Provincia</source>
        <translation>Probintzia</translation>
    </message>
    <message>
        <source>Persona de contacto</source>
        <translation>Kontaktatzeko pertsona</translation>
    </message>
    <message>
        <source>Nombre y apellidos</source>
        <translation>Izen-abizenak</translation>
    </message>
    <message>
        <source>Teléfono 1</source>
        <translation>Telefono 1</translation>
    </message>
    <message>
        <source>Teléfono 2</source>
        <translation>Telefono 2</translation>
    </message>
    <message>
        <source>Registro</source>
        <translation>Erregistroa</translation>
    </message>
    <message>
        <source>Fecha de registro</source>
        <translation>Erregistro data</translation>
    </message>
    <message>
        <source>dd/MM/yyyy</source>
        <translation>ee/HH/uuuu</translation>
    </message>
    <message>
        <source>Actividad</source>
        <translation>Jarduera</translation>
    </message>
    <message>
        <source>Sector</source>
        <translation>Sektorea</translation>
    </message>
    <message>
        <source>Construcción</source>
        <translation>Eraikuntza</translation>
    </message>
    <message>
        <source>Servicios</source>
        <translation>Zerbitzuak</translation>
    </message>
    <message>
        <source>Actividad principal 1</source>
        <translation>Jarduera nagusia 1</translation>
    </message>
    <message>
        <source>CONSTRUCCIÓN</source>
        <translation>ERAIKUNTZA</translation>
    </message>
    <message>
        <source>SERVICIOS</source>
        <translation>ZERBITZUAK</translation>
    </message>
    <message>
        <source>Actividad principal 2</source>
        <translation>Jarduera nagusia 2</translation>
    </message>
    <message>
        <source>Ámbito</source>
        <translation>Arloa</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>Barcelona</source>
        <translation>Bartzelona</translation>
    </message>
    <message>
        <source>La Rioja</source>
        <translation>Errioxa</translation>
    </message>
    <message>
        <source>Navarra</source>
        <translation>Nafarroa</translation>
    </message>
    <message>
        <source>Identificación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sede principal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CIF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sociedad laboral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0,00</source>
        <translation></translation>
    </message>
    <message>
        <source>Web</source>
        <translation></translation>
    </message>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>EEII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sociedades Mercantiles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sociedades Economía Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Agricultura, ganadería y pesca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Industria</source>
        <translation></translation>
    </message>
    <message>
        <source>SECTOR PRIMARIO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>01 Agricultura, ganadería, caza y servicios relacionados con las mismas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>02 Selvicultura, explotación forestal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>03 Pesca y acuicultura</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EXTRACTIVAS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5 Extracción antracita, hulla y lignito</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>6 Extracción de crudo de petróleo y gas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>natural.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>7 Extracción de minerales metálicos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8 Otras industrias extractivas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>9 Actividades de apoyo a las industrias extractivas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>INDUSTRIA</source>
        <translation></translation>
    </message>
    <message>
        <source>10 Industria de alimentación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>11 Fabricación de bebidas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>13 Industria textil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>14 Confección de prendas de vestir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>15 Industria del cuero y del calzado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16 Industria de la madera y del corcho, excepto muebles; cestería y espartería</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>17 Industria del papel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>18 Edición, artes gráficas y reproducción de soportes grabados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>19 Coquerías y refino de petróleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>20 Industria química</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>21 Fabricación de productos farmacéuticos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>22 Fabricación de productos de caucho y plásticos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>23 Fabricación de otros productos minerales no metálicos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>24 Metalurgia: fabricación de productos de hierro, acero y ferroaleaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>25 Fabricación de productos metálicos, excepto maquinaria y equipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>26 Fabricación de productos informáticos, electrónicos y ópticos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>27 Fabricación de material y equipo eléctrico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>28 Fabricación de maquinaria y equipo n.c.o.p.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>29 Fabricación de vehículos de motor, remolques y semirremolques</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>30 Fabricación de otro material de transporte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>31 Fabricación de muebles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>32 Otras industrias manufactureras</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>33 Reparación e instalación de maquinaria y equipo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SUMINISTRO DE ENERGÍA Y AGUA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>35 Suministro de energía eléctrica, gas, vapor y aire acondicionado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>36 Captación, depuración y distribución de agua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GESTIÓN DE RESIDUOS Y DESCONTAMINACIÓN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>37 Recogida y tratamiento de aguas residuales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>38 Recogida, tratamiento y eliminación de residuos; valorización</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>39 Actividades de descontaminación y otros servicios de gestión de residuos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>41 Construcción de edificios</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>42 Ingeniería civil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>43 Actividades de construcción especializada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>45 Venta y Reparación de vehículos de motor y motocicletas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>46 Comercio al por mayor e intermediarios del comercio, excepto de vehículos de motor y motocicletas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>47 Comercio al por menor excepto vehículos de motor y motocicletas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reparación de efectos personales y enseres domésticos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>49 Transporte terrestre y por tuberías</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>50 Transporte marítimo y por vías navegables interiores</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>51Transporte aéreo y espacial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>52 Almacenamiento y actividades anexas al transporte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>53 Actividades postales y de correos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>55 Servicios de alojamientos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>56 Servicios de comidas y bebidas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>58 Edición</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>59 Actividades cinematográficas, de vídeo y de programas de televisión, grabación de sonido y edición musical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>60 Actividades de programación y emisión de radio y televisión</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>61 Telecomunicaciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>62 Programación, consultoría y otras actividades relacionadas con la informática</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>63 Servicios de información</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>64 Servicios financieros,excepto seguros y fondos de pensiones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>65 Seguros, reaseguros y fondos de pensiones, excepto seguridad social obligatoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>66 Actividades auxiliares a los servicios financieros y a los seguros</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>68 Actividades inmobiliarias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>69 Actividades jurídicas y de contabilidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>70 Actividades de las sedes centrales; actividades de consultoría de gestión empresarial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>71 Servicios técnicos de arquitectura e ingeniería; ensayos y análisis técnicos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>72 Investigación y desarrollo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>73 Publicidad y estudios de mercado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>74 Otras actividades profesionales, científicas y técnicas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>75 Actividades veterinarias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>77 Actividades de alquiler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>78 Actividades relacionadas con el empleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>79 Actividades de agencias de viajes, operadores turísticos, servicios de reservas y actividades relacionadas con los mismos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>80 Actividades de seguridad e investigación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>81 Servicios a edificios y actividades de jardinería</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>82 Actividades administrativas de oficina y otras actividades auxiliares a las empresas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>84 Administración Pública y defensa; Seguridad Social obligatoria</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>85 Educación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>86 Actividades sanitarias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>87 Asistencia a establecimientos residenciales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>88 Actividades de servicios sociales sin alojamiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>90 Actividades de creación, artísticas y espectáculos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>91 Actividades de bibliotecas, archivos, museos y otras actividades culturales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>92 Actividades de juegos de azar y apuestas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>93 Actividades deportivas, recreativas y de entretenimiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>94 Actividades asociativas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>95 Reparación de ordenadores, efectos personales y artículos de uso doméstico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>96 Otros servicios personales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>97 Actividades de los hogares como empleadores de personal doméstico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>98 Actividades de los hogares como productores de bienes y servicios para uso propio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>99 Actividades de organizaciones y organismos extraterritoriales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Provincial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Autonómico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Estatal</source>
        <translation>Estatu mailakoa</translation>
    </message>
    <message>
        <source>Internacional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Almería</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cádiz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Córdoba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Granada</source>
        <translation></translation>
    </message>
    <message>
        <source>Huelva</source>
        <translation></translation>
    </message>
    <message>
        <source>Jaén</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Málaga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sevilla</source>
        <translation></translation>
    </message>
    <message>
        <source>Huesca</source>
        <translation></translation>
    </message>
    <message>
        <source>Teruel</source>
        <translation></translation>
    </message>
    <message>
        <source>Zaragoza</source>
        <translation></translation>
    </message>
    <message>
        <source>Las Palmas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tenerife</source>
        <translation></translation>
    </message>
    <message>
        <source>Cantabria</source>
        <translation></translation>
    </message>
    <message>
        <source>Ávila</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Burgos</source>
        <translation></translation>
    </message>
    <message>
        <source>León</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Palencia</source>
        <translation></translation>
    </message>
    <message>
        <source>Salamanca</source>
        <translation></translation>
    </message>
    <message>
        <source>Segovia</source>
        <translation></translation>
    </message>
    <message>
        <source>Soria</source>
        <translation></translation>
    </message>
    <message>
        <source>Valladolid</source>
        <translation></translation>
    </message>
    <message>
        <source>Zamora</source>
        <translation></translation>
    </message>
    <message>
        <source>Albacete</source>
        <translation></translation>
    </message>
    <message>
        <source>Ciudad Real</source>
        <translation></translation>
    </message>
    <message>
        <source>Cuenca</source>
        <translation></translation>
    </message>
    <message>
        <source>Guadalajara</source>
        <translation></translation>
    </message>
    <message>
        <source>Toledo</source>
        <translation></translation>
    </message>
    <message>
        <source>Girona</source>
        <translation></translation>
    </message>
    <message>
        <source>Lleida</source>
        <translation></translation>
    </message>
    <message>
        <source>Tarragona</source>
        <translation></translation>
    </message>
    <message>
        <source>Ceuta</source>
        <translation></translation>
    </message>
    <message>
        <source>Melilla</source>
        <translation></translation>
    </message>
    <message>
        <source>Alacant</source>
        <translation></translation>
    </message>
    <message>
        <source>Castelló</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>València</source>
        <translation></translation>
    </message>
    <message>
        <source>Araba</source>
        <translation></translation>
    </message>
    <message>
        <source>Bizkaia</source>
        <translation></translation>
    </message>
    <message>
        <source>Gipuzkoa</source>
        <translation></translation>
    </message>
    <message>
        <source>Badajoz</source>
        <translation></translation>
    </message>
    <message>
        <source>Cáceres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A Coruña</source>
        <translation></translation>
    </message>
    <message>
        <source>Lugo</source>
        <translation></translation>
    </message>
    <message>
        <source>Ourense</source>
        <translation></translation>
    </message>
    <message>
        <source>Pontevedra</source>
        <translation></translation>
    </message>
    <message>
        <source>Illes Balears</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Madrid</source>
        <translation></translation>
    </message>
    <message>
        <source>Murcia</source>
        <translation></translation>
    </message>
    <message>
        <source>Asturias</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>DialogoDatosGestion</name>
    <message>
        <source>Información de gestión</source>
        <translation>Kudeaketako informazioa</translation>
    </message>
    <message>
        <source>Personas</source>
        <translation>Pertsonak</translation>
    </message>
    <message>
        <source>Sí</source>
        <translation>Bai</translation>
    </message>
    <message>
        <source>No</source>
        <translation>Ez</translation>
    </message>
    <message>
        <source>Observaciones</source>
        <translation>Oharrak</translation>
    </message>
    <message>
        <source>Calidad</source>
        <translation>Kalitatea</translation>
    </message>
    <message>
        <source>En proceso</source>
        <translation>Prozesuan</translation>
    </message>
    <message>
        <source>¿Cuál?</source>
        <translation>Zein?</translation>
    </message>
    <message>
        <source>Igualdad</source>
        <translation>Berdintasuna</translation>
    </message>
    <message>
        <source>¿Cuáles?</source>
        <translation>Zeintzuk?</translation>
    </message>
    <message>
        <source>Conciliación</source>
        <translation>Kontziliazioa</translation>
    </message>
    <message>
        <source>Medio ambiente</source>
        <translation>Ingurumena</translation>
    </message>
    <message>
        <source>Políticas</source>
        <translation>Politikak</translation>
    </message>
    <message>
        <source>Otras</source>
        <translation>Beste batzuk</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>La EI está acogida al Convenio Colectivo del sector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_personas_1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI tiene convenio propio de empresa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_personas_2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI tiene implantado algún sistema de calidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_calidad_1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI tiene alguna certificación de calidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_calidad_2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI cuenta con medidas de igualdad de oportunidades
para hombres y mujeres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_igualdad_1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI cuenta con medidas de discriminación positiva</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_igualdad_2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI cuenta con medidas de conciliación de vida familiar y laboral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_conciliacion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI cuenta con medidas de consumo responsable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_medio_1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI cuenta con medidas de ahorro energético</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_medio_2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI cuenta con medidas para el reciclaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_medio_3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>La EI tiene código de ética o similar </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_politicas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RSE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>¿Existe en la empresa alguna otra medida en pro de la RSE?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup_rse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Explicar otros posibles planes:
-Gestión de la diversidad
-Compromiso con el diseño
para todas las personas
-Etc.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoDatosGizatea</name>
    <message>
        <source>Representante</source>
        <translation>Ordezkaria</translation>
    </message>
    <message>
        <source>Nombre y apellidos</source>
        <translation>Izen-abizenak</translation>
    </message>
    <message>
        <source>DNI</source>
        <translation>NAN</translation>
    </message>
    <message>
        <source>Teléfono 1</source>
        <translation>Telefono 1</translation>
    </message>
    <message>
        <source>Teléfono 2</source>
        <translation>Telefono 2</translation>
    </message>
    <message>
        <source>Suplente</source>
        <translation>Ordezkoa</translation>
    </message>
    <message>
        <source>Voluntariado</source>
        <translation>Bolondresak</translation>
    </message>
    <message>
        <source>Hombres</source>
        <translation>Gizonak</translation>
    </message>
    <message>
        <source>Mujeres</source>
        <translation>Emakumeak</translation>
    </message>
    <message>
        <source>Total</source>
        <translation>Guztira</translation>
    </message>
    <message>
        <source>Cuota</source>
        <translation>Kuota</translation>
    </message>
    <message>
        <source>Nº cuenta corriente:</source>
        <translation>Kontu zenbakia:</translation>
    </message>
    <message>
        <source>Entidad</source>
        <translation>Erakundea</translation>
    </message>
    <message>
        <source>Oficina</source>
        <translation>Bulegoa</translation>
    </message>
    <message>
        <source>Nº cuenta</source>
        <translation>Kontu zenbakia</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <oldsource>validar</oldsource>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>Gizatea</source>
        <translation></translation>
    </message>
    <message>
        <source>Email</source>
        <translation></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>300 €</source>
        <translation></translation>
    </message>
    <message>
        <source>buttonGroup_cuota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>600 €</source>
        <translation></translation>
    </message>
    <message>
        <source>1000 €</source>
        <translation></translation>
    </message>
    <message>
        <source>D.C.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoDatosInsercion</name>
    <message>
        <source>Inserción laboral</source>
        <translation>Laneratzea</translation>
    </message>
    <message>
        <source>Total</source>
        <translation>Guztira</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>Permanencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Menos de 6 meses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De 6 a 12 meses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De 1 a 2 años</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>De 2 a 3 años</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>Proceso</source>
        <translation>Prozesua</translation>
    </message>
    <message>
        <source>Nº personas en inserción que durante el año...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continuaron el proceso de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abandonaron el proceso de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finalizaron su contrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Finalizaron el proceso de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nº personas que han finalizado el proceso durante el año y ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Han encontrado empleo en el mercado ordinario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Han encontrado empleo en la empresa de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Están en desempleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ocupación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ocupaciones de los hombres insertados</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nº</source>
        <translation>Zenbakia</translation>
    </message>
    <message>
        <source>Ocupaciones de las mujeres insertadas</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoDatosRetorno</name>
    <message>
        <source>Retorno social</source>
        <translation>Gizarte itzultzea</translation>
    </message>
    <message>
        <source>Otros tributos (€)</source>
        <translation>Beste zergak (€)</translation>
    </message>
    <message>
        <source>IRPF (€)</source>
        <translation>PFEZ (€)</translation>
    </message>
    <message>
        <source>Total</source>
        <translation>Guztira</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>Fiscalidad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IVA o situaciones especiales (IGIC) (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Impuesto de sociedades (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gastos personal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Trabajador/a
de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Técnico/a
acompañamiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Técnico/a
producción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seg. social empresa (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>Salario neto (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>IRPF empleado/a (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seg. social empleado/a (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Salario bruto (€)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoDatosSocial</name>
    <message>
        <source>Información social</source>
        <translation>Gizarte Informazioa</translation>
    </message>
    <message>
        <source>Personas</source>
        <translation>Pertsonak</translation>
    </message>
    <message>
        <source>Personas a lo largo del año</source>
        <translation>Urtean zeharko pertsonak</translation>
    </message>
    <message>
        <source>Mujeres</source>
        <translation>Emakumeak</translation>
    </message>
    <message>
        <source>Hombres</source>
        <translation>Gizonak</translation>
    </message>
    <message>
        <source>Total</source>
        <translation>Guztira</translation>
    </message>
    <message>
        <source>Personas a 31-dic</source>
        <translation>Abe-31an pertsonak</translation>
    </message>
    <message>
        <source>Administración</source>
        <translation>Administrazioa</translation>
    </message>
    <message>
        <source>Contratos</source>
        <translation>Kontratuak</translation>
    </message>
    <message>
        <source>Duración determinada</source>
        <translation>Iraupen finkatuta</translation>
    </message>
    <message>
        <source>¿Cuántos?</source>
        <translation>Zenbat?</translation>
    </message>
    <message>
        <source>¿Cuáles?</source>
        <translation>Zeintzuk?</translation>
    </message>
    <message>
        <source>Ayuda</source>
        <translation>Laguntza</translation>
    </message>
    <message>
        <source>Validar</source>
        <translation>Balioztatu</translation>
    </message>
    <message>
        <source>Salir</source>
        <translation>Irten</translation>
    </message>
    <message>
        <source>Personal
inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Personal
no inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <source>Personas en inserción y Perceptoras de RMI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puestos EI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dirección / Gerencia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Acompañamiento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mujeres
inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hombres
no inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mujeres
no inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Producción o Comercial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otras funciones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0,00</source>
        <translation></translation>
    </message>
    <message>
        <source>Hombres
inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Puestos EP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jornadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jornada completa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Jornada parcial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contratos Inserción (Ley 44/2007)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indefinidos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo completo (150)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fijo discontinuo (350)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo parcial (250)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temporales de duración determinada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo completo (450)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo parcial (550)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temporal de fomento del empleo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo completo (452)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo parcial (552)</source>
        <translation></translation>
    </message>
    <message>
        <source>Subtotal contratos Inserción: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contratos no Inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo completo (100)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tiempo parcial (200)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fijo discontinuo (300)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Obra o servicio determinado – TC (401)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Obra o servicio determinado – TP (501)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eventual circunstancias de la producción – TC (402)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eventual circunstancias de la producción – TP (502)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interinidad – TC (410)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interinidad – TP (510)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Temporales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prácticas – TC (420)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prácticas – TP (520)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discapacitados  - TC (430)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discapacitados  - TP (530)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Subtotal contratos No inserción: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Otros tipos de contrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Total contratos: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogoEnviar</name>
    <message>
        <source>Enviar</source>
        <translation>Bidali</translation>
    </message>
    <message>
        <source>Confirme la dirección de envío:</source>
        <translation>Baieztatu posta helbidea</translation>
    </message>
</context>
<context>
    <name>DialogoInicio</name>
    <message>
        <source>Organizaciones territoriales</source>
        <translation>Erakunde lokalak</translation>
    </message>
    <message>
        <source>Indique si pertenece a alguna de estas organizaciones:
(en caso contrario no elegir ninguna)
</source>
        <translation>Esan hurrengo erakunderen batean bazaude:
(bestela, ez hautatu ezer)</translation>
    </message>
    <message>
        <source>Adeican</source>
        <translation></translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Adeipa</source>
        <translation></translation>
    </message>
    <message>
        <source>Aeiga</source>
        <translation></translation>
    </message>
    <message>
        <source>Amei</source>
        <translation></translation>
    </message>
    <message>
        <source>Arei</source>
        <translation></translation>
    </message>
    <message>
        <source>Aseircam</source>
        <translation></translation>
    </message>
    <message>
        <source>Avei</source>
        <translation></translation>
    </message>
    <message>
        <source>Eida</source>
        <translation></translation>
    </message>
    <message>
        <source>Feclei</source>
        <translation></translation>
    </message>
    <message>
        <source>Feicat</source>
        <translation></translation>
    </message>
    <message>
        <source>Gizatea</source>
        <translation></translation>
    </message>
    <message>
        <source>Insercionex</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>DialogoNotas</name>
    <message>
        <source>Nota</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No mostrar esta nota la próxima vez</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Balance Social</source>
        <translation>Gizarte-balantzea</translation>
    </message>
    <message>
        <source>Info
general</source>
        <translation>Info
orokorra</translation>
    </message>
    <message>
        <source>Info
social</source>
        <translation>Gizarte
informazioa</translation>
    </message>
    <message>
        <source>Inserción
laboral</source>
        <translation>Laneratzea</translation>
    </message>
    <message>
        <source>Info
económica</source>
        <translation>Info
ekonomikoa</translation>
    </message>
    <message>
        <source>Retorno
social</source>
        <translation>Gizarte
itzultzea</translation>
    </message>
    <message>
        <source>Cláusulas sociales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gestión</source>
        <translation>Kudeaketa</translation>
    </message>
    <message>
        <source>&amp;Inicio</source>
        <oldsource>Inicio</oldsource>
        <translation>&amp;Hasiera</translation>
    </message>
    <message>
        <source>&amp;Datos</source>
        <oldsource>Datos</oldsource>
        <translation>&amp;Datuak</translation>
    </message>
    <message>
        <source>&amp;Ayuda</source>
        <oldsource>Ayuda</oldsource>
        <translation>&amp;Laguntza</translation>
    </message>
    <message>
        <source>&amp;Herramientas</source>
        <oldsource>Herramientas</oldsource>
        <translation>&amp;Tresnak</translation>
    </message>
    <message>
        <source>&amp;Validar</source>
        <oldsource>Validar</oldsource>
        <translation>&amp;Balioztatu</translation>
    </message>
    <message>
        <source>&amp;Idioma</source>
        <oldsource>Idioma</oldsource>
        <translation>&amp;Hizkuntza</translation>
    </message>
    <message>
        <source>&amp;Abrir</source>
        <translation>I&amp;reki</translation>
    </message>
    <message>
        <source>Guardar &amp;como</source>
        <oldsource>&amp;Guardar como</oldsource>
        <translation>Gorde &amp;honela</translation>
    </message>
    <message>
        <source>Exportar a &amp;PDF</source>
        <translation>&amp;PDFra esportatu</translation>
    </message>
    <message>
        <source>&amp;Salir</source>
        <translation>&amp;Irten</translation>
    </message>
    <message>
        <source>&amp;Configurar</source>
        <translation>&amp;Konfiguratu</translation>
    </message>
    <message>
        <source>&amp;Información general</source>
        <translation>Informazio &amp;orokorra</translation>
    </message>
    <message>
        <source>Inserción &amp;laboral</source>
        <oldsource>Inserción laboral</oldsource>
        <translation>&amp;Laneratzea</translation>
    </message>
    <message>
        <source>Información &amp;social</source>
        <translation>Gizarte i&amp;nformazioa</translation>
    </message>
    <message>
        <source>Información económica</source>
        <translation>Informazio ekonomikoa</translation>
    </message>
    <message>
        <source>&amp;Retorno social</source>
        <oldsource>Retorno social</oldsource>
        <translation>Gizarte &amp;itzultzea</translation>
    </message>
    <message>
        <source>&amp;Índice</source>
        <oldsource>Índice</oldsource>
        <translation>&amp;Indizea</translation>
    </message>
    <message>
        <source>Acerca &amp;de</source>
        <oldsource>Acerca de</oldsource>
        <translation>&amp;Ri buruz</translation>
    </message>
    <message>
        <source>&amp;Enviar</source>
        <translation>B&amp;idali</translation>
    </message>
    <message>
        <source>&amp;Nuevo</source>
        <oldsource>Nuevo</oldsource>
        <translation>&amp;Berria</translation>
    </message>
    <message>
        <source>Información no económica</source>
        <translation>Informazio ez ekonomikoa</translation>
    </message>
    <message>
        <source>Exportar a &amp;HTML</source>
        <oldsource>Exportar a HTML</oldsource>
        <translation>&amp;HTMLra esportatu</translation>
    </message>
    <message>
        <source>Castellano</source>
        <translation>Gaztelera</translation>
    </message>
    <message>
        <source>&amp;Guardar</source>
        <oldsource>Guardar</oldsource>
        <translation>&amp;Gorde</translation>
    </message>
    <message>
        <source>Balance social</source>
        <translation>Gizarte-balantzea</translation>
    </message>
    <message>
        <source>Ficheros XBSL (*.xbsl *.xml)</source>
        <translation>XBSL fitxeroak (*.xbsl *.xml)</translation>
    </message>
    <message>
        <source>Gizatea</source>
        <translation></translation>
    </message>
    <message>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Información &amp;económica</source>
        <translation>Informazio &amp;ekonomikoa</translation>
    </message>
    <message>
        <source>&amp;Cláusulas sociales</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Gestión</source>
        <translation>&amp;Kudeaketa</translation>
    </message>
    <message>
        <source>Gi&amp;zatea</source>
        <translation>&amp;Gizatea</translation>
    </message>
    <message>
        <source>&amp;Validar Social</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Euskera</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Balance social</source>
        <translation>Gizarte-balantzea</translation>
    </message>
    <message>
        <source>Para guardar, el campo Razón social no puede estar vacío</source>
        <translation>Gordetzeko, enpresaren izena ezin da hutsik izan</translation>
    </message>
    <message>
        <source>¿Quieres guardar los datos actuales antes de salir?</source>
        <translation>Gorde nahi al dituzu oraingo datuak, irten baino lehen?</translation>
    </message>
    <message>
        <source>¿Quieres guardar los datos actuales antes de abrir otro?</source>
        <translation>Gorde nahi al dituzu oraingo datuak, beste bat ireki baino lehen?</translation>
    </message>
    <message>
        <source>¿Quieres guardar los datos actuales antes de crear un nuevo fichero?</source>
        <translation>Gorde nahi al dituzu oraingo datuak, beste bat sortu baino lehen?</translation>
    </message>
    <message>
        <source>No es posible escribir el fichero %1:\n%2</source>
        <translation>Ezin da idatzi %1 fitxeroa:\n%2</translation>
    </message>
    <message>
        <source>No es posible leer el fichero %1:\n%2</source>
        <translation>Ezin da irakurri %1 fitxeroa:\n%2</translation>
    </message>
    <message>
        <source>Fichero guardado</source>
        <translation>Fitxero gordeta</translation>
    </message>
    <message>
        <source>Ficheros XBSL (*.xbsl *.xml)</source>
        <translation>XBSL fitxeroak (*.xbsl, *.xml)</translation>
    </message>
    <message>
        <source>El año ha de estar entre 1950 y 2050</source>
        <translation>Urtea 1950 eta 2050 artean egon behar da</translation>
    </message>
    <message>
        <source>Introducir costes ANUALES en todas las casillas</source>
        <translation>Sartu URTEKO kostuak gelaxka guztietan</translation>
    </message>
    <message>
        <source>Listo</source>
        <translation>Prest</translation>
    </message>
    <message>
        <source>Suma de porcentajes mayor que 100</source>
        <translation>Porzentaien batuketa 100 baino handiagoa da</translation>
    </message>
    <message>
        <source>La suma de porcentajes ha de ser 100</source>
        <translation>Porzentaien batuketa 100 izan behar da</translation>
    </message>
    <message>
        <source>Faltan campos obligatorios</source>
        <translation>Derrigorrezko eremuak falta dira</translation>
    </message>
    <message>
        <source>Información</source>
        <translation>Informazioa</translation>
    </message>
    <message>
        <source>Fichero de balance</source>
        <translation>Balantze fitxeroa</translation>
    </message>
    <message>
        <source>Falta el año en el fichero XBSL</source>
        <translation>XBSL fitxeroan ez dago urtea</translation>
    </message>
    <message>
        <source>Falta la razón social en el fichero XBSL</source>
        <translation>Enpresaren izena falta da XBSL fitxeroan</translation>
    </message>
    <message>
        <source>Fichero de árbol</source>
        <translation>Zuhaitzeko fitxeroa</translation>
    </message>
    <message>
        <source>Error de análisis en línea %1, columna %2:
%3</source>
        <translation>Analisi akatsa %1 lerroan, %2 zutabean: %3</translation>
    </message>
    <message>
        <source>Cargando</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error de análisis en línea %1, columna %2:\n%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirma el año:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exportar a PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fichero cargado</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error al guardar el fichero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicar los nombres de las redes en que se participa, no el número</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Introducir porcentajes sobre facturación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicar el total de personas que anteriormente percibían RMI\ny que han pasado por la EI durante el año</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hace referencia únicamente a los puestos de la Empresa de Inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hace referencia únicamente a los puestos (o parte de puestos)\nde la entidad promotora que trabajan directamente para la empresa de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Indicar únicamente los contratos de las personas trabajadoras de inserción</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El nº de personas de inserción a 31-dic (%1) no puede ser mayor que el total de personas de inserción a lo largo del año (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El nº de personas de no inserción a 31-dic (%1) no puede ser mayor que el total de personas de no inserción a lo largo del año (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El nº de personas con RMI (%1) no puede ser mayor que el total de personas de inserción a lo largo del año (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El nº de jornadas (%1) ha de ser mayor o igual que el total de personas de inserción (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El nº de contratos (%1) ha de ser mayor o igual que el total de personas de inserción (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El IRPF no puede ser cero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No coinciden las personas que han finalizado el proceso\ny están con empleo (%1) y los totales de ocupaciones (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No coinciden los totales de personas que han finalizado el proceso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Casos que no son ni finalización ni abandono del proceso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El nº de personas de inserción (%1) ha de coincidir con la suma de permanencias (%2) del formulario de inserción laboral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El nº de personas de inserción (%1) ha de coincidir con el total de personas en inserción por proceso (%2) del formulario de inserción laboral</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>En árboles de PyG, Activo y Pasivo introducir valores con signo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validación</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error en formato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error en formato de teléfono (formato: 9 cifras seguidas)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error en formato  de correo electrónico (formato ha de incluir @ y .)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error en formato  de C.P. (formato: 5 cifras)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error en formato de porcentaje</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error en formato de DNI (formatos: 8 cifras y letra, o letra, 7 cifras y letra)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error en formato  de CIF (formatos: 8 cifras y letra, o letra y 8 cifras)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Antes de enviar hay que validar al menos la información no económica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Validación correcta del formulario</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Información no económica validada correctamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Información económica validada correctamente</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enviando por mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El fichero no tiene formato XBSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>El fichero no es un XBSL versión 1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Guardar fichero de balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abrir fichero de balance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>19. Dotación fondo cooperativo COFIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E) EXCEDENTE DE LA COOPERATIVA</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>file:ayuda/ayuda_es.html#</source>
        <translation>file:ayuda/laguntza_eu.html#</translation>
    </message>
    <message>
        <source>Fichero CSV</source>
        <translation>CSV fitxeroa</translation>
    </message>
</context>
</TS>
