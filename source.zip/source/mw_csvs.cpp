/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/

#include "mainwindow.h"
#include "constantes.h"

QStringList MainWindow::listasCsv(QString csv)
{
    QStringList lista;
    if (csv==CSV_GENERAL) {
        lista
                << "razon_social" <<"forma_juridica" << "agrupacion"
                << "provincia" << "comunidad_autonoma" << "ambito"
                << "sector" << "actividad_1" << "actividad_2"
                << "anno_inicio" << "fecha_registro"
                << "ep_1" << "ep_2" << "ep_3" << "ep_4" << "ep_5" << "ep_6";
    } else if (csv==CSV_SOCIAL) {
        lista
                <<"pers_a_1_1"<<"pers_a_1_2"<<"pers_a_2_1"<<"pers_a_2_2"
               <<"pers_b_1_1"<<"pers_b_1_2"<<"pers_b_2_1"<<"pers_b_2_2" <<"pers_rmi"

              <<"ei_1_1"<<"ei_2_1"<<"ei_1_2"<<"ei_1_3"<<"ei_1_4"<<"ei_2_2"<<"ei_2_3"<<"ei_2_4"
             <<"ei_3_1"<<"ei_4_2"<<"ei_4_1"<<"ei_5_1"<<"ei_5_2"<<"ei_3_2"<<"ei_3_3"<<"ei_3_4"
            <<"ei_4_3"<<"ei_4_4"<<"ei_5_3"<<"ei_5_4"

           <<"ep_1_1"<<"ep_2_1"<<"ep_1_2"<<"ep_2_2"<<"ep_3_1"<<"ep_4_2"<<"ep_4_1"<<"ep_5_1"<<"ep_5_2"<<"ep_3_2"

          <<"jornadas_1_1"<<"jornadas_2_1"<<"jornadas_1_2"<<"jornadas_2_2"

         <<"c_1_1"<<"c_1_3"<<"c_1_2"<<"c_2_1"<<"c_2_2"<<"c_3_1"<<"c_3_2"
        <<"c_4_1"<<"c_4_2"<<"c_4_3"<<"c_5_1"<<"c_5_2"<<"c_5_3"<<"c_5_4"<<"c_5_5"<<"c_5_6"
        <<"c_6_1"<<"c_6_2"<<"c_6_3"<<"c_6_4"
        <<"o_5" <<"texto_otros";
    } else if (csv==CSV_INSERCION) {
        lista
                <<"p_1"<<"p_2"<<"p_3"<<"p_4"
               <<"proceso_a3"<<"proceso_a1"<<"proceso_a2"<<"proceso_a4"
              <<"proceso_b1"<<"proceso_b2"<<"proceso_b3"
             <<"okupa_a1"<<"ocupa_a1"<<"okupa_a2"<<"ocupa_a2";
    } else if (csv==CSV_ECON) {
        lista
                <<"ayudas_1"<<"ayudas_2"<<"ayudas_3"<<"ayudas_4"<<"ayudas_5"
               <<"pyg_1"<<"pyg_2"
              <<"pyg_4"<<"pyg_5"
             <<"subv_1"<<"subv_2"
            <<"pyg_6"<<"pyg_7";
    } else if (csv==CSV_RETORNO) {
        lista
                <<"iva"<<"imp_socs"<<"otros_tributos"<<"irpf"
               <<"gastos_1_1"<<"gastos_2_1"<<"gastos_3_1"<<"gastos_5_1"
              <<"gastos_1_2"<<"gastos_2_2"<<"gastos_3_2"<<"gastos_5_2"
             <<"gastos_1_3"<<"gastos_2_3"<<"gastos_3_3"<<"gastos_5_3";
    } else if (csv==CSV_CLAUSULAS) {
        lista
                <<"clientes_1"<<"clientes_2"
               <<"clausulas_territ_si"<<"prop_clausulas_si"
              <<"lista_prop"
             <<"contratos_1"
            <<"contrato_ins_si"
           <<"lista_procs"
          <<"licita_soc_si"
         <<"lista_fase"<<"lista_fase"<<"lista_fase"
        <<"lista_clausulas"<<"lista_clausulas";
    } else if (csv==CSV_GESTION) {
        lista
                <<"pers_sector" <<"pers_empresa"
               <<"rse_no"
              <<"politicas_no"
             <<"ma_1_no" <<"ma_2_no" <<"ma_3_no"
            <<"conciliacion_no"
           <<"calidad_1_si" <<"calidad_2_no"
          <<"igualdad_1_no" <<"igualdad_2_no";
    } else if (csv==CSV_GIZATEA) {
    }
    return lista;

}
