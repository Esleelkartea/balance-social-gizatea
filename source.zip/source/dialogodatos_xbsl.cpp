/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QDomDocument>
#include "dialogodatos.h"
#include "dialogodatosecon.h"
#include "mensajes.h"


void DialogoDatos::toXbsl(QDomDocument *xbsl)
{
    QString valor;
    QDomElement root, d;

    root = xbsl->documentElement();
    d = xbsl->createElement("dialogo");
    d.setAttribute("id",objectName());
    root.appendChild(d);

    QList<QWidget *> l = findChildren<QWidget *>();
    for (int i = 0; i < l.size(); ++i) {
        QWidget *w=l.at(i);

        QString clase = w->metaObject()->className();
        if (clase=="QLineEdit") {
            QLineEdit *p=(QLineEdit *)w;
            insertaNodoXbsl (xbsl, d, clase,p->objectName(),p->text());
        } else if (clase=="QLabel") {
            QLabel *p=(QLabel *)w;
            insertaNodoXbsl (xbsl, d, clase,p->objectName(),p->text());
        } else if (clase=="QDateEdit") {
            ; // No hace falta porque hay un widget asociado de tipo QLineEdit
        } else if (clase=="QTextEdit") {
            QTextEdit *p=(QTextEdit *)w;
            insertaNodoXbsl (xbsl, d, clase,p->objectName(),p->toPlainText());
        } else if (clase=="QRadioButton") {
            QRadioButton *p=(QRadioButton*)w;
            if (p->isChecked())
                insertaNodoXbsl (xbsl, d, clase,p->objectName(),p->text());
        } else if (clase=="QComboBox") {
            QComboBox *p=(QComboBox *)w;
            insertaNodoXbsl (xbsl, d, clase,p->objectName(),p->currentText());
        } else if (clase=="QListWidget") {
            QListWidget *p=(QListWidget*)w;
            QString str="";
            for (int i=0; i < p->count(); i++)
                if (p->item(i)->isSelected())
                    insertaNodoXbsl (xbsl, d, clase,p->objectName(),p->item(i)->text());
        } else if (clase=="QTreeWidget") {
            QTreeWidget *p=(QTreeWidget *)w;
            guardaArbolXbsl (xbsl, d, p);
        }
    }
}

void DialogoDatos::insertaNodoXbsl(QDomDocument *xbsl, QDomElement d, QString clase, QString id, QString valor)
{
    if (valor!="") {
        QDomElement nodo = xbsl->createElement(id);
        nodo.setAttribute("widget",clase);
        nodo.setAttribute("valor",valor);
        d.appendChild(nodo);
    }
}


void DialogoDatos::guardaArbolXbsl(QDomDocument *xbsl, QDomElement d, QTreeWidget *p)
{
    QDomElement nodo = xbsl->createElement(p->objectName());
    nodo.setAttribute("widget","QTreeWidget");
    d.appendChild(nodo);

    QList <QTreeWidgetItem *> l = p->findItems("*",Qt::MatchWildcard,1);
    for (int i=0; i<l.size(); i++)
        guardaNodoXbsl (xbsl, nodo, l.at(i));
}

void DialogoDatos::guardaNodoXbsl(QDomDocument *xbsl, QDomElement d, QTreeWidgetItem *p)
{
    QDomElement nodo = xbsl->createElement("nodo");
    nodo.setAttribute("string",p->data(1,Qt::DisplayRole).toString());
    nodo.setAttribute("valor",p->data(2,Qt::DisplayRole).toString());
    d.appendChild(nodo);

    for (int i=0; i<p->childCount() ; i++)
        guardaNodoXbsl (xbsl, nodo, p->child(i));
}


void DialogoDatos::fromXbsl(QDomDocument xbsl)
{
    QWidget *ptr;

    QDomElement root = xbsl.documentElement();
    QDomElement d = root.firstChildElement("dialogo");

    while ( !d.isNull() ) {
        if (d.attribute("id") == objectName()) {
            QDomElement w=d.firstChildElement();
            while ( !w.isNull() ) {
                ptr= findChild<QWidget *>(w.tagName());
                if (ptr!=0) {
                    if (ptr->styleSheet()==ESTILO_NO)
                        ptr->setStyleSheet(ESTILO_SI);
                    if (w.attribute("widget")=="QLineEdit")
                        ((QLineEdit*)ptr)->setText (w.attribute("valor"));
                    else if (w.attribute("widget")=="QTextEdit")
                        ((QTextEdit*)ptr)->setText (w.attribute("valor"));
                    else if (w.attribute("widget")=="QRadioButton") {
                        ((QRadioButton*)ptr)->setChecked(true);
                        QList <QAbstractButton *>lb=((QRadioButton*)ptr)->group()->buttons();
                        for (int i=0; i<lb.size(); i++)
                            lb.at(i)->setStyleSheet(ESTILO_SI);
                    } else if (w.attribute("widget")=="QComboBox") {
                        for (int i=0; i < ((QComboBox *)ptr)->count(); i++)
                            if (((QComboBox *)ptr)->itemText(i)==w.attribute("valor"))
                                ((QComboBox *)ptr)->setCurrentIndex(i);
                    } else if (w.attribute("widget")=="QListWidget") {
                        for (int i=0; i < ((QListWidget *)ptr)->count(); i++)
                            if (((QListWidget *)ptr)->item(i)->text()==w.attribute("valor"))
                                ((QListWidget *)ptr)->item(i)->setSelected(true);
                    } else if (w.attribute("widget")=="QTreeWidget") {
                        QTreeWidget *arbol = (QTreeWidget *)ptr;
                        arbol->clear();
                        ((DialogoDatosEcon*)this)->leeRama (arbol, (QTreeWidgetItem *)0, w);
                    }
                }
                if (w.tagName()=="qt_spinbox_lineedit") {
                    QString fecha=w.attribute("valor");
                    if (fecha.length()>4) {
                        ptr= findChild<QWidget *>("fecha_registro");
                        if (ptr!=0) {
                            QDate fecha_registro=QDate(fecha.right(4).toInt(),
                                                       fecha.mid(3,2).toInt(),
                                                       fecha.left(2).toInt());
                            ((QDateEdit *)ptr)->setDate (fecha_registro);
                            ptr->setStyleSheet(ESTILO_SI);
                        }
                    }
                }
                w = w.nextSiblingElement();
            }
        }
        d = d.nextSiblingElement();
    }
    actualizarForm();
}

