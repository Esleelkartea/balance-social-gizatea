/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/

#include <QtGui>
#include "mainwindow.h"
#include "constantes.h"
#include "mensajes.h"

void MainWindow::consolidarMenu()
{
    QFileDialog dialogo(this);
    dialogo.setFileMode(QFileDialog::Directory);
    if (!dialogo.exec()) return;

    QString path=dialogo.selectedFiles().at(0);
    if (path=="") return;

    QHash <QString,QStringList> csvs;

    csvs [CSV_GENERAL] << listasCsv(CSV_GENERAL);
    csvs [CSV_SOCIAL] << listasCsv(CSV_SOCIAL);
    csvs [CSV_INSERCION] << listasCsv(CSV_INSERCION);
    csvs [CSV_ECON] << listasCsv(CSV_ECON);
    csvs [CSV_RETORNO] << listasCsv(CSV_RETORNO);
    csvs [CSV_CLAUSULAS] << listasCsv(CSV_CLAUSULAS);
    csvs [CSV_GESTION] << listasCsv(CSV_GESTION);
    csvs [CSV_GIZATEA] << listasCsv(CSV_GIZATEA);

    QDir dir(path);
    QStringList filtro;
    filtro << "*.xbsl";
    dir.setNameFilters(filtro);
    QStringList ficherosXbsl = dir.entryList();

    QHash<QString, QStringList>::iterator i;
    for (i=csvs.begin(); i != csvs.end(); ++i) {
        QFile ficheroCsv((QString)path+i.key());
        if (!ficheroCsv.open(QFile::WriteOnly | QIODevice::Truncate | QFile::Text)) {
            QMessageBox::critical(this, QObject::tr(MSG_FICH_CSV),
                                  QObject::tr(MSG_ERR_SAVE).arg(path+i.key()).arg(ficheroCsv.errorString()));
            return;
        }
        QTextStream out(&ficheroCsv);

        // Cabecera
        for (int n=0; n<i.value().size() ; n++)
            out << i.value().at(n) << "|";
        out << "\n";

        for (int j=0; j<ficherosXbsl.size(); j++) {
            QDomDocument xbsl;
            if (leeXbsl(path+ficherosXbsl.at(j), &xbsl)==-1) return;
            QDomElement d = xbsl.documentElement().firstChildElement("dialogo");
            while ( !d.isNull() ) {
                if (d.attribute("id")+QString(".csv")==i.key()) {
                    exportDialogCsv(out, d, i.value());

                    if (ficheroCsv.error()!=QFile::NoError) {
                        QMessageBox::critical (this,QObject::tr(MSG_FICH_CSV), QObject::tr(MSG_ERR_WRITE));
                        ficheroCsv.close();
                        return;
                    }
                break; // Si lo ha encontrado, al siguiente CSV
                }
                d = d.nextSiblingElement();
            }
        }
        ficheroCsv.close();
    }
}


void MainWindow::exportDialogCsv(QTextStream &out, QDomElement d, QStringList l)
{
    if (!d.hasChildNodes())
        return;

    for (int i=0; i<l.size() ; i++) {
        QDomElement n=d.firstChildElement(l.at(i));
        if (!n.isNull()) {
            n.attribute("valor").replace("|","*"); // Que no aparezca el delimitador de campo
            out << n.attribute("valor") << "|";
        }
    }

    //hack para caso de qt_spinbox
    QDomElement n=d.firstChildElement("qt_spinbox_lineedit");
    if (!n.isNull())
        out << n.attribute("valor").right(4) << "|";

    out << "\n";
}

