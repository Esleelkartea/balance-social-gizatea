/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosgeneral.h"
#include "mainwindow.h"
#include "constantes.h"
#include "mensajes.h"
#include <QtGui>
#include <QList>
#include <QLineEdit>


DialogoDatosGeneral::DialogoDatosGeneral (QWidget *parent)
  :DialogoDatos (parent)
{
    setupUi(this);

    QList <QWidget *> opcionales;
    opcionales << redes << telefono_2 << direccion_web << horario
              << registro_eeii << registro_mercantil << registro_econ_social << actividad2;
    initUi(&opcionales);

    cif->setValidator(cifVal);
    codigo_postal->setValidator(codigoPostalVal);
    email->setValidator(emailVal);
    QValidator *q = new QIntValidator (1950,2050,this);
    anno_inicio->setValidator(q);
    telefono_1->setValidator(telefonoVal);
    telefono_2->setValidator(telefonoVal);

    QList <QLineEdit *>l;
    l<< ep_1 << ep_2 << ep_3 << ep_4 << ep_5 << ep_6 << p_1 << p_2 << p_3 << p_4 << p_5 << p_6;
    for (int i=0; i<l.size() ; i ++) {
        ((QWidget*)l.at(i))->setStyleSheet(ESTILO_0);
    }

    provincia->hide();

    notasWidget ["redes"]=QObject::QObject::tr(MSG_D_GENERAL_NOTA_REDES);

    setComunidades();

    DialogoDatos::setGrid(grid_promotoras, porcentajeVal);

    QFont fuente(qApp->font().family(), 9, QFont::PreferDefault);
    actividad1->setFont(fuente);
    actividad2->setFont(fuente);
}


int DialogoDatosGeneral::validarWidget(QLineEdit *ptr)
{
    QList <QLineEdit *>l1, l2;
    l1 << ep_1 << ep_2 << ep_3 << ep_4 << ep_5 << ep_6;
    l2 << p_1 << p_2 << p_3 << p_4 << p_5 << p_6;

    // Caso de nombre de 2ª, 3ª,... promotora
    if (l1.contains(ptr))
        return validarPromotoras(ptr, false);
    else if (l2.contains (ptr))
        return validarPromotoras(ptr, true);

    //QList <QLineEdit *> l;
    //l << cif << codigo_postal << anno_inicio << telefono_1 << telefono_2;

    if (ptr == anno_inicio)
        return DialogoDatos::validarWidget (anno_inicio, QObject::tr(MSG_D_GENERAL_ERR_ANNO));
    else
        return DialogoDatos::validarWidget(ptr);
}

int DialogoDatosGeneral::validarWidget(QDateEdit *ptr)
{
    if (ptr == fecha_registro ) {
        if (ptr->date()==QDate(1900,1,1)) return -1;
        else return 1;
    }
    return -1; // Nunca llega aquí, pero para que no dé warning
}

void DialogoDatosGeneral::triggerOutWidget (QComboBox *c, int *)
{
    if (c == agrupacion)
        ((MainWindow *)parent())->setMenuRed(c->currentText());
}



int DialogoDatosGeneral::validarPromotoras (QLineEdit *e, bool flag_valor)
{
    static bool semaforo_verde=true;
    QWidget *w1, *w2;
    QString nombre, valor;
    QList <QLineEdit *>l1, l2;
    int index;
    double p;

    l1<< ep_1 << ep_2 << ep_3 << ep_4 << ep_5 << ep_6;
    l2 << p_1 << p_2 << p_3 << p_4 << p_5 << p_6;

    if (flag_valor) {
        if (DialogoDatos::validarWidget(e)==-1)
            return -1;

        p=0;
        for (int i=0; i<l2.size();i++)
            p+=l2.at(i)->text().toDouble();

        if (p>100.0) {
            if (semaforo_verde) {
                semaforo_verde=false;
                QMessageBox::warning(this, QObject::tr(MSG_VALIDACION), QObject::tr(MSG_ERR_PORCENTAJES));
                e->setFocus(Qt::OtherFocusReason);
                semaforo_verde=true;
                return -1;
            }
        } else
            p_0->setText(QLocale().toString(p, 'f',2));

        index=l2.indexOf(e);
    } else
        index=l1.indexOf(e);

    // Colores
    w1=(QWidget *)l1.at(index);
    w2=(QWidget *)l2.at(index);
    nombre=l1.at(index)->text();
    valor=l2.at(index)->text();


    if (!nombre.isEmpty() && valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_SI);
        w2->setStyleSheet(ESTILO_NO);
    } else if (!nombre.isEmpty()  && !valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_SI);
        w2->setStyleSheet(ESTILO_SI);
    } else if (nombre.isEmpty() && valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_0);
        w2->setStyleSheet(ESTILO_0);
    } else if (nombre.isEmpty() && !valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_NO);
        w2->setStyleSheet(ESTILO_SI);
    }

    return 0;
}


void DialogoDatosGeneral::actualizarForm()
{
    QList <QLineEdit *>l;
    double p=0;

    l << p_1 << p_2 << p_3 << p_4 << p_5 << p_6;
    for (int i=0; i<l.size();i++)
        p+=l.at(i)->text().toDouble();

    p_0->setText(QLocale().toString(p, 'f',2));
}


