/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatos.h"
#include <QtGui>
#include "mensajes.h"
#include "mainwindow.h"
#include "dialogoayuda.h"

#include "dialogodatosgeneral.h"
#include "dialogodatossocial.h"
#include "dialogodatosinsercion.h"
#include "dialogodatosecon.h"
#include "dialogodatosretorno.h"
#include "dialogodatosclausulas.h"
#include "dialogodatosgestion.h"
#include "dialogodatosgizatea.h"


DialogoDatos::DialogoDatos(QWidget *parent) : QDialog (parent)
{
    connect (this, SIGNAL(notSaved()), parent, SLOT(setSavedFalse()));

    QRegExp intPositivoExp = QRegExp ("[0-9]{1,10}");
    intPositivoVal = new QRegExpValidator(intPositivoExp,this);
    QRegExp doublePositivoExp = QRegExp ("[0-9]+((\\,|\\.)[0-9][0-9]?)?");
    doublePositivoVal=new QRegExpValidator(doublePositivoExp,this);
    QRegExp eurosExp = QRegExp ("-?[0-9]+((\\,|\\.)[0-9][0-9]?)?");
    eurosVal = new QRegExpValidator(eurosExp,this);
    QRegExp porcentajeExp = QRegExp ("(100|[0-9]{1,2})((\\,|\\.)[0-9][0-9]?)?");
    porcentajeVal =  new QRegExpValidator(porcentajeExp,this);

    QRegExp cifExp = QRegExp ("([0-9]{8}([A-Z]|[a-z])|([A-Z]|[a-z])[0-9]{8})");
    cifVal = new QRegExpValidator(cifExp,this);
    QRegExp dniExp = QRegExp ("(([A-Z]|[a-z])[0-9]{7}([A-Z]|[a-z])|[0-9]{8}([A-Z]|[a-z]))");
    dniVal = new QRegExpValidator(dniExp,this);
    QRegExp telefonoExp = QRegExp ("[0-9]{9}");
    telefonoVal = new QRegExpValidator(telefonoExp,this);
    QRegExp emailExp = QRegExp ("[^ ]+@[^ ]+\\.[^ ]+");
    emailVal = new QRegExpValidator(emailExp,this);
    QRegExp codigoPostalExp = QRegExp ("[0-9]{5,5}");
    codigoPostalVal = new QRegExpValidator(codigoPostalExp,this);
}

void DialogoDatos::initUi (QList <QWidget *> *opcionales) {
    QString str;
    QStringList clases;

    clases << "QLineEdit" << "QTextEdit" << "QComboBox" << "QRadioButton" << "QListWidget" << "QDateEdit";

    // Cambio de colores e instalación de filtro
    QList<QWidget *> lst = findChildren<QWidget *>();
    for (int i = 0; i < lst.size(); ++i) {
        if (! clases.contains( lst.at(i)->metaObject()->className() ) ) continue;

        // Caso raro de widget QLineEdit creado en fecha_registro
        if ( lst.at(i)->objectName().startsWith("qt_spinbox_lineedit") )
            continue;
        //if ( lst.at(i)->objectName().startsWith("qt_spinbox_lineedit") ) continue;

        // siguiente línea antes de la siguiente condición porque
        // en el caso de redes, aunque no es obligatorio ha de sacar nota
        lst.at(i)->installEventFilter(this);
        if ( opcionales!=NULL && opcionales->contains( lst.at(i) ) ) continue;

        lst.at(i)->setStyleSheet(ESTILO_NO);
    }

    // Botones
    QPushButton *b;
    b=this->findChild<QPushButton *>("validarButton");
    connect(b,SIGNAL(clicked()),this,SLOT(validarForm()));
    b=this->findChild<QPushButton *>("ayudaButton");
    connect(b,SIGNAL(clicked()),this,SLOT(ayuda()));
}

bool DialogoDatos::eventFilter(QObject *object, QEvent *event)
{
    bool flag=false;
    QString str=object->metaObject()->className();
    QWidget *w=(QWidget *)object;
    int cambia=0;

    /* Para QRadioButton, QComboBox se han detectado los eventos mejores para el cambio de color*/
    if (str=="QRadioButton") {
        if (event->type() == QEvent::MouseButtonPress) flag=true;
        if (event->type() == QEvent::KeyPress) {
            QKeyEvent *ke = static_cast<QKeyEvent *>(event);
            if (ke->key() == Qt::Key_Space) flag=true;
        }

        if (flag) {
            emit notSaved();
            QRadioButton *ptr=(QRadioButton *)object;
            QList <QAbstractButton *> lista = ptr->group()->buttons ();
            for (int i=0; i<lista.size();i++)
                ((QWidget *)lista.at(i))->setStyleSheet(ESTILO_SI);
        }
    }  else if (str=="QComboBox") {
        // En Windows no parece producirse QEvent::LayoutRequest
        if (event->type()==QEvent::FocusOut || event->type()==QEvent::LayoutRequest) {
            if (((QComboBox *)object)->currentText()!="") cambia=1;
            else cambia=-1;
            triggerOutWidget ((QComboBox *)object, &cambia);
        }
    } else if (str=="QLineEdit")  {
        if (event->type()==QEvent::FocusIn) {
            notaInWidget(w);
        } else if (event->type()== QEvent::FocusOut) {
            cambia = this->validarWidget((QLineEdit *)object);
            notaOutWidget(w);
            triggerOutWidget ((QLineEdit *)object);
        }
    } else if (str=="QDateEdit")  {
        if (event->type()== QEvent::FocusOut) {
            cambia = validarWidget ((QDateEdit *)object);
        }
    } else if (str=="QTextEdit") {
        if (event->type()==QEvent::FocusIn) {
            notaInWidget(w);
        } else if (event->type()== QEvent::FocusOut) {
            notaOutWidget(w);
            if (((QTextEdit *)object)->toPlainText()!="") cambia=1;
            else cambia=-1;
        }
    } else if (str=="QListWidget") {
        if (event->type()== QEvent::Paint) {
            if (((QListWidget *)object)->selectedItems().size()!=0) cambia=1;
            else cambia=-1;
        }
    }

    if (cambia==1 || cambia==-1) emit notSaved();

    if (cambia==-1 && w->styleSheet()==ESTILO_SI) w->setStyleSheet(ESTILO_NO);
    else if (cambia==1 && w->styleSheet()==ESTILO_NO) w->setStyleSheet(ESTILO_SI);

    if (event->type() == QEvent::LanguageChange) {
        QString clase = metaObject()->className();
        if (clase=="DialogoDatosGeneral")
            ((DialogoDatosGeneral*)this)->Ui_DialogoDatosGeneral::retranslateUi((QDialog*)this);
       else if (clase=="DialogoDatosSocial")
            ((DialogoDatosSocial*)this)->Ui_DialogoDatosSocial::retranslateUi((QDialog*)this);
        else if (clase=="DialogoDatosInsercion")
            ((DialogoDatosInsercion*)this)->Ui_DialogoDatosInsercion::retranslateUi((QDialog*)this);
        else if (clase=="DialogoDatosEcon")
            ((DialogoDatosEcon*)this)->Ui_DialogoDatosEcon::retranslateUi((QDialog*)this);
        else if (clase=="DialogoDatosRetorno")
            ((DialogoDatosRetorno*)this)->Ui_DialogoDatosRetorno::retranslateUi((QDialog*)this);
        else if (clase=="DialogoDatosClausulas")
            ((DialogoDatosClausulas*)this)->Ui_DialogoDatosClausulas::retranslateUi((QDialog*)this);
        else if (clase=="DialogoDatosGestion")
            ((DialogoDatosGestion*)this)->Ui_DialogoDatosGestion::retranslateUi((QDialog*)this);
        else if (clase=="DialogoDatosGizatea")
            ((DialogoDatosGizatea*)this)->Ui_DialogoDatosGizatea::retranslateUi((QDialog*)this);
    }
    return QObject::eventFilter(object, event);
}


void DialogoDatos::notaInWidget (QWidget *w)
{
    QString nombre=w->objectName();
    if (notasWidget.contains(nombre)) {
        QWidget *l=findChild<QLabel *>("nota");
        ((QLabel *)l)->setText(notasWidget.value(nombre));
        l->setStyleSheet(ESTILO_NOTA);
    }
}


void DialogoDatos::notaOutWidget (QWidget *)
{
    QWidget *l=findChild<QLabel *>("nota");
    ((QLabel *)l)->setText("");
    l->setStyleSheet(ESTILO_SIN_NOTA);
}


void DialogoDatos::notaTab(int index)
{
    QWidget *l=findChild<QLabel *>("nota");
    if (notasTab.contains(index)) {
        ((QLabel *)l)->setText(notasTab.value(index));
        l->setStyleSheet(ESTILO_NOTA);
    }
    else {
        ((QLabel *)l)->setText("");
        l->setStyleSheet(ESTILO_SIN_NOTA);
    }
}


int DialogoDatos::validarWidget (QLineEdit *l)
{
    return validarWidget (l, "");
}

int DialogoDatos::validarWidget (QLineEdit *l, QString msg)
{
    if (msg=="")
        msg=QObject::tr(MSG_ERR_FORMATO);

    if (l->text() !="") {
        if (l->validator()!=0) {
            if (l->validator() == telefonoVal) msg=QObject::tr(MSG_ERR_TEL);
            else if (l->validator() == emailVal) msg=QObject::tr(MSG_ERR_MAIL);
            else if (l->validator() == dniVal) msg=QObject::tr(MSG_ERR_DNI);
            else if (l->validator() == cifVal) msg=QObject::tr(MSG_ERR_CIF);
            else if (l->validator() == codigoPostalVal) msg=QObject::tr(MSG_ERR_CP);
            else if (l->validator() == porcentajeVal) msg=QObject::tr(MSG_ERR_PORCENTAJE);
            return validarWidget (l, (QValidator*)l->validator(), QObject::tr(MSG_VALIDACION), msg);
        } else
            return 1;
    }
    else
        return -1;
}


int DialogoDatos::validarWidget (QLineEdit *&l, QValidator *v, QString title, QString body)
{
    int pos=0;
    QString str;

    str=l->text();
    if (str!="" && v->validate(str,pos) != QValidator::Acceptable ) {
        QMessageBox::warning(this,title,body);
        l->setFocus(Qt::OtherFocusReason);
        return -1;
    } else {
        bool b;
        str.toDouble(&b);
        if (b && str.contains(".")) {
            str.replace(".",",");
            l->setText(str);
        }
        return 1;
    }
}


bool DialogoDatos::validarForm (QList <QWidget *> *l, bool flagShowOk)
{
    QList <QString> lstr;
    QList<QWidget *> lw;
    QWidget *w;
    QString str;

    lw = findChildren<QWidget *>();
    lstr<< "QLineEdit" << "QTextEdit" << "QComboBox" << "QRadioButton" << "QListWidget" << "QDateEdit";
    for (int i = 0; i < lw.size(); ++i) {
        w=lw.at(i);
        str=w->metaObject()->className();
        if (lstr.contains(str)==false) continue;
        if (l!=0 && l->contains(w)) continue;
        if ( w->styleSheet() == ESTILO_NO ) {
            QList<QTabWidget *> tablist = findChildren<QTabWidget *>();
            QTabWidget *tab = tablist.at(0);
            for (int i=0; i<tab->count(); i++) {
                QWidget *tw=tab->widget(i);
                // Casos: hasta dentro de 2 QGroupBox
                if ( tw==w->parent() || tw==w->parent()->parent() || tw==w->parent()->parent()->parent())
                    tab->setCurrentIndex(i);
            }
            QMessageBox::warning (0, QObject::tr(MSG_VALIDACION), QObject::tr(MSG_ERR_CAMPOS_OBLIGATORIOS));
            return false;
        }
    }
    if (flagShowOk)
        QMessageBox::information( 0, QObject::tr(MSG_VALIDACION), QObject::tr(MSG_OK_VALIDACION));
    return true;
}




void DialogoDatos::ayuda()
{
    ((MainWindow *)(this->parent()))->dialogoAyuda->muestra(objectName());
}
