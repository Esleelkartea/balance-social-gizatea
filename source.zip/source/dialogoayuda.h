/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGOAYUDA_H
#define DIALOGOAYUDA_H

#include <QtGui>
#include "ui_dialogoayuda.h"
#include "constantes.h"

class DialogoAyuda : public QDialog, private Ui::DialogoAyuda
{
  Q_OBJECT

public:
    DialogoAyuda(QWidget *parent=0):QDialog (parent)
    {
        setupUi (this);
        setWindowModality (Qt::NonModal);
    }
      void changeEvent(QEvent *event)
    {
        if (event->type() == QEvent::LanguageChange) {
            retranslateUi((QDialog*)this);
        }
        QDialog::changeEvent(event);
    }

    void muestra (QString str)
    {
        QString ayuda;
        if (str=="DialogoDatosGizatea") {
            QFile file1(":/varios/files/ayuda_gizatea_es.html");
            if ( file1.open(QFile::ReadOnly) ) {
                QTextStream in (&file1);
                in.setCodec("UTF-8");
                ayuda = in.readAll();
                file1.close();
            }
            contenido->setHtml(ayuda);
        } else {
            contenido->setSource(QUrl(QObject::tr(HELP_URL)+str));
        }

        //    setWindowModality (Qt::NonModal);
        exec();
        //d->show();
        //d->raise();
        //d->activateWindow();
    }    
};


#endif // DIALOGOAYUDA_H
