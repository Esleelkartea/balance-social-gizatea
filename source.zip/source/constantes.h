/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef CONSTANTES_H
#define CONSTANTES_H

#define LIB_PATH "c:/balancesocial"
#define HELP_URL "file:ayuda/ayuda_es.html#"
#define CSV_GENERAL "DialogoDatosGeneral.csv"
#define CSV_SOCIAL "DialogoDatosSocial.csv"
#define CSV_INSERCION "DialogoDatosInsercion.csv"
#define CSV_ECON "DialogoDatosEcon.csv"
#define CSV_RETORNO "DialogoDatosRetorno.csv"
#define CSV_CLAUSULAS "DialogoDatosClausulas.csv"
#define CSV_GESTION "DialogoDatosGestion.csv"
#define CSV_GIZATEA "DialogoDatosGizatea.csv"

#define NEW_ICON ":/varios/iconos/document-new.png"
#define OPEN_ICON ":/varios/iconos/document-open.png"
#define SAVE_ICON ":/varios/iconos/document-save.png"
#define SAVEAS_ICON ":/varios/iconos/document-save-as.png"
#define EXPORTPDF_ICON ":/varios/iconos/application-pdf.png"
#define EXPORTHTML_ICON ":/varios/iconos/html-export.png"
#define SALIR_ICON ":/varios/iconos/dialog-close.png"
#define ENVIAR_ICON ":/varios/iconos/enviar.png"
#define CONSOLIDAR_ICON ":/varios/iconos/consolidar.png"
#define AYUDA_ICON ":/varios/iconos/help-contents.png"
#define ABOUT_ICON ":/varios/iconos/help-about.png"

#define ARBOL ":/varios/files/arbol.txt"
#define AYUDA_GIZATEA_ES ":/varios/files/ayuda_gizatea_es.txt"
#define CABECERA_CSS ":/varios/files/cabecera_css.html"

#define APP_EU ":/varios/translations/balancesocial_eu"
#define QT_EU ":/varios/translations/qt_eu_ES"
#define SPLASH "splash.png"
#define SPLASH_TXIKI "splash_txiki.png"



#define EMAIL_VAL 1
#define DNI_VAL 2
#define CIF_VAL 3
#define CP_VAL 4
#define TEL_VAL 5
#define PORCENTAJE_VAL 6

//#define ESTILO_NO "background: orange"
#define ESTILO_NO "background: #E9967A"
//#define ESTILO_SI "background: #00ee00"
#define ESTILO_SI "background: #3CB371"
#define ESTILO_0 "background: white"

#define ESTILO_NOTA "background: yellow"
#define ESTILO_SIN_NOTA "background: "

#endif // CONSTANTES_H
