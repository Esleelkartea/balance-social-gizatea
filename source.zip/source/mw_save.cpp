/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QtGui>
#include <QDomDocument>
#include "mainwindow.h"
#include "mensajes.h"
#include "dialogodatosgeneral.h"


void MainWindow::saveMenu()
{
    QString razon_social=dialogoDatosGeneral->razonSocial();
    while (razon_social=="") {
        QMessageBox::warning(this, QObject::tr(MSG_FICH_BALANCE), QObject::tr(MSG_ERR_RAZON_SOCIAL));
        dialogoDatosGeneral->findChild <QTabWidget *>("tabWidget")->setCurrentIndex(0);
        dialogoDatosGeneral->exec();
        razon_social=dialogoDatosGeneral->razonSocial();
    }

    if (guardarXbsl(fichero, razon_social)) {
        statusBar()->showMessage(QObject::tr(MSG_FICHERO_GUARDADO), 2000);
        saved = true;
    }
}

void MainWindow::saveAsMenu()
{
    setAnno();

    QString razon_social=dialogoDatosGeneral->razonSocial();
    while (razon_social=="") {
        QMessageBox::warning(this, QObject::tr(MSG_FICH_BALANCE), QObject::tr(MSG_ERR_RAZON_SOCIAL));
        dialogoDatosGeneral->findChild <QTabWidget *>("tabWidget")->setCurrentIndex(0);
        dialogoDatosGeneral->exec();
        razon_social=dialogoDatosGeneral->razonSocial();
    }
    QString fileName = QFileDialog::getSaveFileName(this, QObject::tr(MSG_GUARDAR_FICH_BALANCE),
                                                    QDir::currentPath(), QObject::tr(MSG_FICHEROS_XBSL));
    if (fileName.isEmpty()) return;

    if (guardarXbsl(fileName, razon_social)) {
        saved = true;
        fichero=fileName;
        actionGuardar->setEnabled(true);
        if (razon_social.length()>20)
                razon_social = razon_social.left(20)+"...";
        setWindowTitle(tr("Balance Social")+" - "+ razon_social+"/"+ QString::number(anno)  + " - "+ fichero);

        statusBar()->showMessage(QObject::tr(MSG_FICHERO_GUARDADO), 2000);
    }
}

bool MainWindow::guardarXbsl(QString fileName, QString razon_social)
{
    const int IndentSize = 7;

    QFile file(fileName);
    if (!file.open(QFile::WriteOnly | QFile::Text)) {
        QMessageBox::critical(this, QObject::tr(MSG_FICH_BALANCE), QObject::tr(MSG_ERR_SAVE).arg(fileName).arg(file.errorString()));
        return false;
    }

    QDomDocument xbsl;
    QDomElement root = xbsl.createElement("xbsl");
    root.setAttribute("version","1.0");
    root.setAttribute("encoding","utf-8");
    xbsl.appendChild(root);

    QDomElement info = xbsl.createElement("info");
    info.setAttribute("anno",anno);
    info.setAttribute("razonsocial",razon_social);
    root.appendChild(info);

    for (int i=0; i<dialogosDatos.size(); i++)
        dialogosDatos.at(i)->toXbsl(&xbsl);

    QTextStream out(&file);
    xbsl.save(out, IndentSize);
    out.flush();
    if (file.error()!=QFile::NoError) {
        QMessageBox::critical (this,QObject::tr(MSG_FICH_BALANCE), QObject::tr(MSG_ERR_WRITE));
        file.close();
        return false;
    }
    file.close();
    return true;
}
