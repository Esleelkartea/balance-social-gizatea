/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosecon.h"
#include <QtGui>
#include "mensajes.h"

void DialogoDatosEcon::creaArboles()
{
    QDomDocument dom;
    QString errorStr;
    int errorLine;
    int errorColumn;

    groupIcon.addPixmap(style()->standardPixmap(QStyle::SP_DirClosedIcon),
                        QIcon::Normal, QIcon::Off);
    groupIcon.addPixmap(style()->standardPixmap(QStyle::SP_DirOpenIcon),
                        QIcon::Normal, QIcon::On);
    keyIcon.addPixmap(style()->standardPixmap(QStyle::SP_DialogApplyButton));

    QFile file(ARBOL);
    if (!dom.setContent(&file, true, &errorStr, &errorLine,
                        &errorColumn)) {
        QMessageBox::critical(0, QObject::tr(MSG_FICH_ARBOL), QObject::tr(MSG_ERR_DOM)
                                 .arg(errorLine).arg(errorColumn).arg(errorStr));
        return;
    }

    QDomElement e;
    e = dom.firstChildElement(); //Hijos de primer nodo <xml>
    e = e.firstChildElement("arbol");
    creaArbol (arbol_pyg, "arbol_pyg", e);
    e = e.nextSiblingElement("arbol");
    creaArbol (arbol_activo, "arbol_activo",e);
    e = e.nextSiblingElement("arbol");
    creaArbol (arbol_pasivo, "arbol_pasivo",e);
}

void DialogoDatosEcon::creaArbol(QTreeWidget *arbol, QString str, QDomElement e)
{
    ArbolDelegado *a=new ArbolDelegado(arbol, str);
    connect (a, SIGNAL( actualizaArbol(QString) ), this, SLOT ( actualizaArbol(QString) ) );
    arbol->QAbstractItemView::setItemDelegate(a);
    arbol->setColumnWidth(1, 3.2 * arbol->columnWidth(1));
    // arbol->clear();
    leeRama (arbol, (QTreeWidgetItem *)0, e);
}


void DialogoDatosEcon::leeRama(QTreeWidget *arbol, QTreeWidgetItem *tn, QDomElement raiz) {
    QDomElement n;
    n=raiz.firstChildElement();
    QString id;
    while ( !n.isNull() ) {
        QTreeWidgetItem *x;
        if (tn==0)
            x= new QTreeWidgetItem(arbol, 0);
        else
            x= new QTreeWidgetItem(tn, 0);
        id=n.attribute("id");


        QString str=n.attribute("string");
        x->setText(1,str);

        QRegExp nodoExp = QRegExp ("([A-D]\\)|TOTAL).*");
        QRegExpValidator *v = new QRegExpValidator(nodoExp,this);
        int z=0;
        enum QValidator::State flag=v->validate(str,z);
        delete v;

        if (flag!=QValidator::Invalid) {
            QFont f=x->font(1);
            f.setBold(true);
            x->setFont(1,f);
        }

        if (!n.firstChild().isNull()) {
            x->setIcon(0,groupIcon);
            leeRama (arbol, x, n);
        } else {
            x->setIcon(0,keyIcon);
            x->setFlags(x->flags() | Qt::ItemIsEditable);
        }

        x->setText(2,n.attribute("valor"));
        x->setTextAlignment(2,Qt::AlignRight);
        x->setData (2,Qt::UserRole,0);

        n = n.nextSiblingElement();
    }
}

void DialogoDatosEcon::actualizaArbol (QString str)
{
    double a,b,c,d,e;

    if (str=="arbol_pyg") {
        a=QLocale().toDouble(arbol_pyg->topLevelItem(0)->text(2));
        b=QLocale().toDouble(arbol_pyg->topLevelItem(1)->text(2));
        c=a+b;
        arbol_pyg->topLevelItem(2)->setText(2,QLocale().toString(c,'f',2));
        d = c + QLocale().toDouble(arbol_pyg->topLevelItem(3)->text(2));
        arbol_pyg->topLevelItem(4)->setText(2,QLocale().toString(d,'f',2));
        if (coop) {
            e= d + QLocale().toDouble(arbol_pyg->topLevelItem(5)->text(2));
            arbol_pyg->topLevelItem(6)->setText(2,QLocale().toString(e,'f',2));
        }
    } else if (str=="arbol_activo") {
        a=QLocale().toDouble(arbol_activo->topLevelItem(0)->text(2));
        b=QLocale().toDouble(arbol_activo->topLevelItem(1)->text(2));
        c=a+b;
        arbol_activo->topLevelItem(2)->setText(2,QLocale().toString(c,'f',2));
    } else if (str=="arbol_pasivo") {
        a=QLocale().toDouble(arbol_pasivo->topLevelItem(0)->text(2));
        b=QLocale().toDouble(arbol_pasivo->topLevelItem(1)->text(2));
        c=QLocale().toDouble(arbol_pasivo->topLevelItem(2)->text(2));
        d=a+b+c;
        arbol_pasivo->topLevelItem(3)->setText(2,QLocale().toString(d,'f',2));
    }

    emit notSaved();
}

void DialogoDatosEcon::arbolCoop (QString text)
{
    QTreeWidgetItem *x;
    if (text==tr("Sociedad cooperativa")) {
        if (!coop) {
            x= new QTreeWidgetItem(arbol_pyg, 0);
            x->setIcon(0,keyIcon);
            x->setText(1,QObject::tr(MSG_PYG_19));
            x->setFlags(x->flags() | Qt::ItemIsEditable);
            x->setText(2,"0,00");
            x->setTextAlignment(2,Qt::AlignRight);
            x->setData (2,Qt::UserRole,0);
            arbol_pyg->insertTopLevelItem ( 5, x );

            x= new QTreeWidgetItem(arbol_pyg, 0);
            x->setIcon(0,groupIcon);
            x->setText(1,QObject::tr(MSG_PYG_E));
            QFont f=x->font(1);
            f.setBold(true);
            x->setFont(1,f);
            x->setText(2,"0,00");
            x->setTextAlignment(2,Qt::AlignRight);
            x->setData (2,Qt::UserRole,0);
            arbol_pyg->insertTopLevelItem ( 6, x );

            coop = true;
        }
    } else {
        if (coop==true) {
            arbol_pyg->takeTopLevelItem(5);
            arbol_pyg->takeTopLevelItem(5);

            coop=false;
        }
    }
}

