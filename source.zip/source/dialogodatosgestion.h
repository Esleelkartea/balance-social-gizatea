/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGO_DATOS_GESTION_H
#define DIALOGO_DATOS_GESTION_H

#include "dialogodatos.h"
#include "ui_dialogodatosgestion.h"

class DialogoDatosGestion : public DialogoDatos, public Ui::DialogoDatosGestion
{
  Q_OBJECT

public:
    DialogoDatosGestion(QWidget *parent=0);

private:
    void showWidgets();
    void actualizarForm();
    QString toHtml();

public slots:
    bool validarForm(bool flagShowOk);
};


#endif // DIALOGO_DATOS_GESTION_H
