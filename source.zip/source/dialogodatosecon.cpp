/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosecon.h"
#include <QtGui>
#include "constantes.h"

DialogoDatosEcon::DialogoDatosEcon (QWidget *parent)
  :DialogoDatos (parent)
{
    setupUi (this);
    initUi();

    coop=false;

    notasTab [0]=QObject::tr(MSG_D_ECON_NOTA);
    notasTab [1]=QObject::tr(MSG_D_ECON_NOTA);
    notasTab [2]=QObject::tr(MSG_D_ECON_NOTA);
    ((QWidget *)nota)->setStyleSheet(ESTILO_NOTA);

    creaArboles();
    arbol_pyg->expandAll();

    DialogoDatos::setGrid(grid_ayudas1, doublePositivoVal);
    DialogoDatos::setGrid(grid_ayudas2, doublePositivoVal);

    DialogoDatos::setGrid((QGridLayout *)facturaciones->layout(), porcentajeVal);
}


void DialogoDatosEcon::triggerOutWidget(QLineEdit *e)
{
    if (e==ayudas_1) sumaGrid(grid_ayudas1,0,1);
    if (e==ayudas_2) sumaGrid(grid_ayudas1,0,1);
    if (e==ayudas_3) sumaGrid(grid_ayudas1,0,1);
    if (e==ayudas_4) sumaGrid(grid_ayudas1,0,1);
    if (e==ayudas_5) sumaGrid(grid_ayudas1,0,1);

    if (e==subv_1) sumaGrid(grid_ayudas2,0,1);
    if (e==subv_2) sumaGrid(grid_ayudas2,0,1);

    QList <QLineEdit *> l1;
    QList <QComboBox *> l2;
    l1 << ayudas_1 << ayudas_2 << ayudas_3 << ayudas_4 << ayudas_5 << subv_1 << subv_2;
    l2 << pyg_1 << pyg_2 << pyg_3 << pyg_4 << pyg_5 << pyg_6 << pyg_7;

    int n=l1.indexOf(e);
    if (n!=-1) {
        QWidget *w=(QWidget *)l2.at(n);
        if (e->text()=="" && w->styleSheet()==ESTILO_SI  && l2.at(n)->currentText()=="")
            w->setStyleSheet(ESTILO_NO);
        else if (e->text()!="" && e->text().toDouble()==0) { //Si es 0
            if (w->styleSheet()==ESTILO_NO)  // Si la lista está en naranja se deja verde
                w->setStyleSheet(ESTILO_SI);
            else // Si está en verde se deja al primero
                l2.at(n)->setCurrentIndex(0);
        } else if (e->text().toInt()!=0 && w->styleSheet()==ESTILO_SI && l2.at(n)->currentText()=="")
            w->setStyleSheet(ESTILO_NO);
    }
}


void DialogoDatosEcon::triggerOutWidget(QComboBox *c, int *cambia)
{
    QList <QLineEdit *> l1;
    QList <QComboBox *> l2;
    l1 << ayudas_1 << ayudas_2 << ayudas_3 << ayudas_4 << ayudas_5 << subv_1 << subv_2;
    l2 << pyg_1 << pyg_2 << pyg_3 << pyg_4 << pyg_5 << pyg_6 << pyg_7;
    int n=l2.indexOf(c);
    if (n!=-1) {
        if (l1.at(n)->text().toInt()==0)
            *cambia=1;
    }
}

void DialogoDatosEcon::validarClientes (QLineEdit *e)
{
    double p;
    static bool semaforo_verde=true;

    if (DialogoDatos::validarWidget(e) == -1)
        return;

    p=(clientes_1->text()).toDouble() + (clientes_2->text()).toDouble();
    if (p > 100.0) {
        if (semaforo_verde) {
            semaforo_verde=false;
            QMessageBox::warning(this,QObject::tr(MSG_VALIDACION),QObject::tr(MSG_ERR_PORCENTAJES));
            e->setFocus(Qt::OtherFocusReason);
            semaforo_verde=true;
        }
    } else
        clientes_total->setText(QLocale().toString(p, 'f',2));
}

void DialogoDatosEcon::actualizarForm()
{
    double p=(clientes_1->text()).toDouble() + (clientes_2->text()).toDouble();
    clientes_total->setText(QLocale().toString(p, 'f',2));

    sumaGrid(grid_ayudas1,0,1);
    sumaGrid(grid_ayudas2,0,1);
}

bool DialogoDatosEcon::validarForm(bool flagShowOk)
{
    QString aviso;

    if (clientes_1->text().toDouble() + clientes_2->text().toDouble() != 100) {
        aviso=QObject::tr(MSG_D_ECON_ERR_PORCENTAJES);
        QMessageBox::warning(0,QObject::tr(MSG_VALIDACION),aviso);
        return false;
    }

    return DialogoDatos::validarForm(flagShowOk);
}
