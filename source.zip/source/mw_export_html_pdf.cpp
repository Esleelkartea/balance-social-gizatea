/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QtGui>
#include "mainwindow.h"
#include "mensajes.h"
#include "dialogodatos.h"


#include <QPrintDialog>
#include <QPrinter>
#include <QTextDocument>

void MainWindow::exportPdfMenu()
{
    QTextDocument *d = new QTextDocument();
    d->setHtml(strHtml());

    QString fileName = QFileDialog::getSaveFileName(this, QObject::tr(MSG_EXPORT_PDF), QString(), "*.pdf");
    if (!fileName.isEmpty()) {
        if (QFileInfo(fileName).suffix().isEmpty())
            fileName.append(".pdf");
        QPrinter printer(QPrinter::HighResolution);
        printer.setOutputFormat(QPrinter::PdfFormat);
        printer.setOutputFileName(fileName);
        d->print(&printer);
    }
    delete d;
}


void MainWindow::exportHtmlMenu()
{
    QString fileName = QFileDialog::getSaveFileName(this, QObject::tr(MSG_EXPORT_HTML), QString(), "*.html");
    if (fileName.isEmpty())
        return;
    if (QFileInfo(fileName).suffix().isEmpty())
        fileName.append(".html");

    QFile file2 (fileName);
    if (file2.open(QFile::WriteOnly | QFile::Truncate)) {
        QTextStream out(&file2);
        out.setCodec("UTF-8");
        out << strHtml();
        file2.close();
    }
}

QString MainWindow::strHtml()
{
    QString str_anno,str;
    QFile file1(CABECERA_CSS);
    if ( file1.open(QFile::ReadOnly) ) {
        QTextStream in (&file1);
        in.setCodec("UTF-8");
        str = in.readAll();
        file1.close();
    }
    setAnno();
    str.replace("BalanceSocial::anno", str_anno.setNum(anno));

    for (int i=0; i<dialogosDatos.size(); i++) {
        if (!(botonInfoGizatea->isVisible()) && dialogosDatos.at(i)==(DialogoDatos*) dialogoDatosGizatea)
            continue;
        str+=dialogosDatos.at(i)->toHtml();
    }
    str+="</body>";

    return str;
}
