/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDomDocument>
#include <QTranslator>
#include <QTextDocument>
#include "ui_mainwindow.h"
#define MIN 2010
#define MAX 2050

class DialogoDatos;
class DialogoDatosGeneral;
class DialogoDatosSocial;
class DialogoDatosInsercion;
class DialogoDatosEcon;
class DialogoDatosRetorno;
class DialogoDatosClausulas;
class DialogoDatosGestion;
class DialogoDatosGizatea;

class DialogoAyuda;
class DialogoAcercaDe;


class MainWindow : public QMainWindow,private Ui::MainWindow {
  Q_OBJECT

public:
    MainWindow();
    bool checkPersonasI();
    DialogoAyuda *dialogoAyuda;
    void setMenuRed(QString str);

private:
    QTranslator appTranslator;
    QTranslator qtTranslator;

    bool saved;
    int anno;
    QString fichero;

    QDialog *dialogoEnviar;
    DialogoAcercaDe *dialogoAcercaDe;

    DialogoDatosGeneral *dialogoDatosGeneral;
    DialogoDatosSocial *dialogoDatosSocial;
    DialogoDatosInsercion *dialogoDatosInsercion;
    DialogoDatosEcon *dialogoDatosEcon;
    DialogoDatosRetorno *dialogoDatosRetorno;
    DialogoDatosClausulas *dialogoDatosClausulas;
    DialogoDatosGestion *dialogoDatosGestion;
    DialogoDatosGizatea *dialogoDatosGizatea;

    QList <DialogoDatos *> dialogosDatos;

    void createDialogosDatos();
    void menus();
    void setAnno();
    void setOrganizacion();
    QString strHtml();
    bool validar (int caso);
    bool guardarXbsl(QString fileName, QString razon_social);
    void exportDialogCsv(QTextStream &out, QDomElement d, QStringList l);
    QStringList listasCsv(QString csv);

public slots:
    void setSavedFalse() {saved=false;}
    int leeXbsl(QString fileName, QDomDocument *xbsl);

private slots:
    void newMenu();
    void openMenu();
    void saveAsMenu();
    void saveMenu();
    void exportPdfMenu();
    void exportHtmlMenu();
    void salirMenu();
    void sendMenu();
    void consolidarMenu();
    void aboutMenu();
    void ayudaMenu();

    void datosGeneralMenu();
    void datosSocialMenu();
    void datosInsercionMenu();
    void datosEconMenu();
    void datosRetornoMenu();
    void datosClausulasMenu();
    void datosGestionMenu();
    void datosGizateaMenu();

    void setIdioma(QAction *);
};  

#endif

