/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosclausulas.h"
#include <QtGui>
#include "mensajes.h"


DialogoDatosClausulas::DialogoDatosClausulas (QWidget *parent)
  :DialogoDatos (parent)
{
    setupUi (this);
    initUi();

    showWidgets();

    contratos_1->setValidator(porcentajeVal);
    texto_contratos->setValidator(doublePositivoVal);
}

void DialogoDatosClausulas::showWidgets()
{
    if (prop_clausulas_si->isChecked()) {
        label_prop->show(); lista_prop->show();
        label_resultados->show(); texto_resultados->show();
    } else {
        label_prop->hide(); lista_prop->hide();
        label_resultados->hide(); texto_resultados->hide();
    }
    if (contrato_ins_si->isChecked()) {
        label_procs->show(); lista_procs->show();
        label_contratos->show(); texto_contratos->show();
        label_aapp->show(); texto_aapp->show();
    } else {
        label_procs->hide(); lista_procs->hide();
        label_contratos->hide(); texto_contratos->hide();
        label_aapp->hide(); texto_aapp->hide();
    }
    if (licita_soc_si->isChecked()) {
        label_fase->show(); lista_fase->show();
        label_clausulas->show(); lista_clausulas->show();
    } else {
        label_fase->hide(); lista_fase->hide();
        label_clausulas->hide(); lista_clausulas->hide();
    }
}


bool DialogoDatosClausulas::validarForm(bool flagShowOk)
{
    QList <QWidget *> l;

    if (prop_clausulas_no->isChecked())
        l << lista_prop << texto_resultados;
    if (contrato_ins_no->isChecked())
        l << lista_procs << texto_contratos << texto_aapp;
    if (licita_soc_no->isChecked())
        l << lista_fase << lista_clausulas;

    return DialogoDatos::validarForm(&l, flagShowOk);
}

void DialogoDatosClausulas::actualizarForm()
{
    showWidgets();
}
