/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef MENSAJES_H
#define MENSAJES_H

#define MSG_APP "Balance social"

#define MSG_CARGANDO "Cargando"

#define MSG_ERR_DOM  "Error de análisis en línea %1, columna %2:\n%3"

#define MSG_NEW_ANNO "Confirma el año:"
#define MSG_ERR_RAZON_SOCIAL "Para guardar, el campo Razón social no puede estar vacío"

#define MSG_EXPORT_PDF "Exportar a PDF"
#define MSG_EXPORT_HTML "Exportar a HTML"
#define MSG_WARN_SAVE_END "¿Quieres guardar los datos actuales antes de salir?"
#define MSG_WARN_SAVE_OPEN "¿Quieres guardar los datos actuales antes de abrir otro?"
#define MSG_WARN_SAVE_NEW "¿Quieres guardar los datos actuales antes de crear un nuevo fichero?"
#define MSG_ERR_SAVE "No es posible escribir el fichero %1:\n%2"
#define MSG_ERR_OPEN "No es posible leer el fichero %1:\n%2"
#define MSG_FICHERO_CARGADO "Fichero cargado"
#define MSG_FICHERO_GUARDADO "Fichero guardado"
#define MSG_FICHEROS_XBSL "Ficheros XBSL (*.xbsl *.xml)"
#define MSG_ERR_WRITE "Error al guardar el fichero"

#define MSG_LISTO "Listo"
#define MSG_VALIDACION "Validación"
#define MSG_ERR_PORCENTAJES "Suma de porcentajes mayor que 100"
#define MSG_ERR_FORMATO "Error en formato"
#define MSG_ERR_TEL "Error en formato de teléfono (formato: 9 cifras seguidas)"
#define MSG_ERR_MAIL "Error en formato  de correo electrónico (formato ha de incluir @ y .)"
#define MSG_ERR_CP "Error en formato  de C.P. (formato: 5 cifras)"
#define MSG_ERR_DNI "Error en formato de DNI (formatos: 8 cifras y letra, o letra, 7 cifras y letra)"
#define MSG_ERR_CIF "Error en formato  de CIF (formatos: 8 cifras y letra, o letra y 8 cifras)"
#define MSG_ERR_PORCENTAJE "Error en formato de porcentaje"

#define MSG_ERR_CAMPOS_OBLIGATORIOS "Faltan campos obligatorios"
#define MSG_OK_VALIDACION "Validación correcta del formulario"
#define MSG_INFO "Información"
#define MSG_MAIL "La validación no económica es correcta. Valide opcionalmente la parte ecónomica, guarde el fichero y envíelo por correo electrónico a %1"


#define MSG_FICH_BALANCE "Fichero de balance"
#define MSG_FICH_CSV "Fichero CSV"
#define MSG_ERR_FORMATO_FICH_BALANCE "El fichero no tiene formato XBSL"
#define MSG_ERR_VERSION_FICH_BALANCE "El fichero no es un XBSL versión 1.0"
#define MSG_ERR_ANNO_FICH_BALANCE "Falta el año en el fichero XBSL"
#define MSG_ERR_RAZON_SOCIAL_FICH_BALANCE "Falta la razón social en el fichero XBSL"
#define MSG_GUARDAR_FICH_BALANCE "Guardar fichero de balance"
#define MSG_ABRIR_FICH_BALANCE "Abrir fichero de balance"

#define MSG_FICH_ARBOL "Fichero de árbol"


/*************************************************/

#define MSG_D_GENERAL_NOTA_REDES "Indicar los nombres de las redes en que se participa, no el número"
#define MSG_D_GENERAL_ERR_ANNO "El año ha de estar entre 1950 y 2050"

#define MSG_D_SOCIAL_NOTA_RMI "Indicar el total de personas que anteriormente percibían RMI y que han pasado por la EI durante el año"
#define MSG_D_SOCIAL_NOTA_EI "Hace referencia únicamente a los puestos de la Empresa de Inserción"
#define MSG_D_SOCIAL_NOTA_EP "Hace referencia únicamente a los puestos (o parte de puestos) de la entidad promotora que trabajan directamente para la empresa de inserción"
#define MSG_D_SOCIAL_NOTA_CONTRATOS "Indicar únicamente los contratos de las personas trabajadoras de inserción"
#define MSG_D_SOCIAL_ERR_PERSONAS_INS_31DIC "El nº de personas de inserción a 31-dic (%1) no puede ser mayor que el total de personas de inserción a lo largo del año (%2)"
#define MSG_D_SOCIAL_ERR_PERSONAS_NO_INS_31DIC "El nº de personas de no inserción a 31-dic (%1) no puede ser mayor que el total de personas de no inserción a lo largo del año (%2)"
#define MSG_D_SOCIAL_ERR_RMI "El nº de personas con RMI (%1) no puede ser mayor que el total de personas de inserción a lo largo del año (%2)"
#define MSG_D_SOCIAL_ERR_JORNADAS "El nº de jornadas (%1) ha de ser mayor o igual que el total de personas de inserción (%2)"
#define MSG_D_SOCIAL_ERR_CONTRATOS "El nº de contratos (%1) ha de ser mayor o igual que el total de personas de inserción (%2)"

#define MSG_D_PERSONAL_1 "Introducir costes ANUALES en todas las casillas"

#define MSG_D_RETORNO_ERR_IRPF "El IRPF no puede ser cero"

#define MSG_D_INSERCION_ERR_OCUPACIONES "No coinciden las personas que han finalizado el proceso y están con empleo (%1) y los totales de ocupaciones (%2)"
#define MSG_D_INSERCION_ERR_PROCESO "No coinciden los totales de personas que han finalizado el proceso (%1 y %2)"
#define MSG_D_INSERCION_NOTA_PROCESO "Casos que no son ni finalización ni abandono del proceso"

#define MSG_D_ECON_NOTA "En árboles de PyG, Activo y Pasivo introducir valores con signo"
#define MSG_D_ECON_NOTA_PORCENTAJES "Introducir porcentajes sobre facturación"
#define MSG_D_ECON_ERR_PORCENTAJES "La suma de porcentajes de la pestaña Clientela ha de ser 100"

#define MSG_PYG_19 "19. Dotación fondo cooperativo COFIP"
#define MSG_PYG_E "E) EXCEDENTE DE LA COOPERATIVA"

#define MSG_D_VARIOS_ERR_1 "El nº de personas de inserción (%1) ha de coincidir con la suma de permanencias (%2) del formulario de inserción laboral"
#define MSG_D_VARIOS_ERR_2 "El nº de personas de inserción (%1) ha de coincidir con el total de personas en inserción por proceso (%2) del formulario de inserción laboral"


#endif // MENSAJES_H


