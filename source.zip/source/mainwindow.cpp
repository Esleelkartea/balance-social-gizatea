/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include <QtGui>
#include <QtGui/QDialogButtonBox>
#include <QDomDocument>

#include "mainwindow.h"
#include "dialogoayuda.h"
#include "dialogoacercade.h"
#include "dialogodatosgeneral.h"
#include "dialogodatossocial.h"
#include "dialogodatosinsercion.h"
#include "dialogodatosecon.h"
#include "dialogodatosretorno.h"
#include "dialogodatosclausulas.h"
#include "dialogodatosgestion.h"
#include "dialogodatosgizatea.h"

#include "ui_dialogoinicio.h"
#include "ui_dialogoenviar.h"

#include "mensajes.h"

MainWindow::MainWindow()
{
    qtTranslator.load("qt_es_ES", QLibraryInfo::location(QLibraryInfo::TranslationsPath));
    qApp->installTranslator(&qtTranslator);

    setupUi(this);

    QFont fuente(qApp->font().family(), 12, QFont::PreferDefault);
    qApp->setFont(fuente);

    QTextCodec::setCodecForTr(QTextCodec::codecForName("utf-8"));

    menus();
    dialogoAcercaDe=new DialogoAcercaDe(this);
    dialogoAyuda=new DialogoAyuda(this);
    createDialogosDatos();

    saved = true;
    fichero="";
    setWindowTitle(tr("Balance Social"));
    actionGuardar->setEnabled(false);

    //setOrganizacion();
    statusBar()->showMessage(QObject::tr(MSG_LISTO));
}



void MainWindow::createDialogosDatos()
{
    for (int i=0; i<dialogosDatos.size(); i++)
        delete dialogosDatos.at(i);
    dialogosDatos.clear();

    dialogoDatosGeneral = new DialogoDatosGeneral(this);
    dialogosDatos << dialogoDatosGeneral;
    dialogoDatosSocial = new DialogoDatosSocial(this);
    dialogosDatos << dialogoDatosSocial;
    dialogoDatosInsercion = new DialogoDatosInsercion(this);
    dialogosDatos << dialogoDatosInsercion;
    dialogoDatosEcon = new DialogoDatosEcon(this);
    dialogosDatos << dialogoDatosEcon;
    dialogoDatosRetorno = new DialogoDatosRetorno(this);
    dialogosDatos << dialogoDatosRetorno;
    dialogoDatosClausulas = new DialogoDatosClausulas(this);
    dialogosDatos << dialogoDatosClausulas;
    dialogoDatosGestion = new DialogoDatosGestion(this);
    dialogosDatos << dialogoDatosGestion;
    dialogoDatosGizatea = new DialogoDatosGizatea(this);
    dialogosDatos << dialogoDatosGizatea;


    //Cambiando a cooperativa cambia el árbol
    connect (dialogoDatosGeneral, SIGNAL(coop(QString)), dialogoDatosEcon, SLOT(arbolCoop(QString)));
}


void MainWindow::setAnno()
{
    QDialog *dialogoAnno = new QDialog(this);

    QLabel *l=new QLabel(dialogoAnno);
    l->setText(QObject::tr(MSG_NEW_ANNO));

    QSpinBox *e=new QSpinBox(dialogoAnno);
    e->setRange(MIN,MAX);
    //e->setMinimumWidth(55);
    anno=QDateTime::currentDateTime().addYears(-1).toString("yyyy").toInt();
    e->setValue(anno);
    e->setAlignment(Qt::AlignCenter);

    QDialogButtonBox *b = new QDialogButtonBox(dialogoAnno);
    b->setOrientation(Qt::Horizontal);
    b->setStandardButtons(QDialogButtonBox::Ok);
    b->setCenterButtons(true);

    QVBoxLayout *v = new QVBoxLayout(dialogoAnno);
    v->addWidget(l);
    v->addWidget(e);
    v->addWidget(b);
    dialogoAnno->setLayout(v);

    connect(b, SIGNAL(accepted()), dialogoAnno, SLOT(accept()));
    connect(b, SIGNAL(rejected()), dialogoAnno, SLOT(reject()));

    dialogoAnno->exec();

    anno=e->value();

    delete dialogoAnno;
}


