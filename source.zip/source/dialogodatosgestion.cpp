/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosgestion.h"
#include <QtGui>

DialogoDatosGestion::DialogoDatosGestion (QWidget *parent)
  :DialogoDatos (parent)
{
    setupUi (this);
    QList <QWidget *> opcionales;
    opcionales << observaciones_1 << observaciones_2 << observaciones_3 << observaciones_4
               << observaciones_5 << observaciones_6 << observaciones_7 << observaciones_8;
    initUi(&opcionales);

    showWidgets();
}

void DialogoDatosGestion::showWidgets()
{
    QList<QWidget *> l_hide, l_show;

    if (calidad_1_si->isChecked() || calidad_1_ep->isChecked() ) {
        calidad_label1->show(); calidad_texto1->show();
    } else {
        calidad_label1->hide(); calidad_texto1->hide();
    }
    if (calidad_2_si->isChecked() || calidad_2_ep->isChecked() ) {
        calidad_label2->show(); calidad_texto2->show();
    } else {
        calidad_label2->hide(); calidad_texto2->hide();
    }
    if (igualdad_1_si->isChecked()) {
        igualdad_label1->show(); igualdad_texto1->show();
    } else {
        igualdad_label1 ->hide(); igualdad_texto1->hide();
    }
    if (igualdad_2_si->isChecked()) {
        igualdad_label2->show(); igualdad_texto2->show();
    } else {
        igualdad_label2 ->hide(); igualdad_texto2->hide();
    }
    if (conciliacion_si->isChecked()) {
        conciliacion_label->show(); conciliacion_texto->show();
    } else {
        conciliacion_label->hide(); conciliacion_texto->hide();
    }
    if (ma_1_si->isChecked()) {
        ma_label->show(); ma_texto->show();
    } else {
        ma_label->hide(); ma_texto->hide();
    }
    if (rse_si->isChecked()) {
        rse_label->show(); rse_texto->show();
    } else {
        rse_label->hide(); rse_texto->hide();
    }
}

bool DialogoDatosGestion::validarForm(bool flagShowOk)
{
    QList <QWidget *> l;

    if (calidad_1_no->isChecked())
        l << calidad_texto1;
    if (calidad_2_no->isChecked())
        l << calidad_texto2;
    if (igualdad_1_no->isChecked())
        l << igualdad_texto1;
    if (igualdad_2_no->isChecked())
        l << igualdad_texto2;
    if (conciliacion_no->isChecked())
        l << conciliacion_texto;
    if (ma_1_no->isChecked())
        l << ma_texto;
    if (rse_no->isChecked())
        l << rse_texto;

    return DialogoDatos::validarForm(&l, flagShowOk);
}

void DialogoDatosGestion::actualizarForm()
{
    showWidgets();
}
