/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosretorno.h"
#include <QtGui>
#include "mensajes.h"

DialogoDatosRetorno::DialogoDatosRetorno (QWidget *parent)
  :DialogoDatos (parent)
{
    setupUi (this);

    QList <QWidget *> opcionales;
    opcionales << iva << imp_socs << otros_tributos
               << gastos_1_2 << gastos_2_2 << gastos_3_2 << gastos_5_2
               << gastos_1_3 << gastos_2_3 << gastos_3_3 << gastos_5_3;
    initUi(&opcionales);

    iva->setValidator(doublePositivoVal);
    imp_socs->setValidator(doublePositivoVal);
    otros_tributos->setValidator(doublePositivoVal);
    irpf->setValidator(doublePositivoVal);

    notasTab [1]=QObject::tr(MSG_D_PERSONAL_1);
    DialogoDatos::setGrid((QGridLayout*)tab_2->layout(), doublePositivoVal);
}


int DialogoDatosRetorno::validarWidget(QLineEdit *ptr)
{
    if (ptr==irpf)
        if (ptr->text()!="" && ptr->text().toDouble()==0 ) {
            QMessageBox::warning(this, QObject::tr(MSG_VALIDACION), QObject::tr(MSG_D_RETORNO_ERR_IRPF));
            ptr->setFocus(Qt::OtherFocusReason);
            return -1;
        } else if (ptr->text()=="")
            return -1;
        else
            return 1;
    else
        return DialogoDatos::validarWidget(ptr);
}

void DialogoDatosRetorno::triggerOutWidget(QLineEdit *e)
{
    if (e==gastos_1_1) sumaGrid((QGridLayout*)tab_2->layout(),0,1,4);
    if (e==gastos_2_1) sumaGrid((QGridLayout*)tab_2->layout(),0,1,4);
    if (e==gastos_3_1) sumaGrid((QGridLayout*)tab_2->layout(),0,1,4);
    if (e==gastos_5_1) sumaGrid((QGridLayout*)tab_2->layout(),0,1);

    if (e==gastos_1_2) sumaGrid((QGridLayout*)tab_2->layout(),0,2,4);
    if (e==gastos_2_2) sumaGrid((QGridLayout*)tab_2->layout(),0,2,4);
    if (e==gastos_3_2) sumaGrid((QGridLayout*)tab_2->layout(),0,2,4);
    if (e==gastos_5_2) sumaGrid((QGridLayout*)tab_2->layout(),0,2);

    if (e==gastos_1_3) sumaGrid((QGridLayout*)tab_2->layout(),0,3,4);
    if (e==gastos_2_3) sumaGrid((QGridLayout*)tab_2->layout(),0,3,4);
    if (e==gastos_3_3) sumaGrid((QGridLayout*)tab_2->layout(),0,3,4);
    if (e==gastos_5_3) sumaGrid((QGridLayout*)tab_2->layout(),0,3);
}

void DialogoDatosRetorno::actualizarForm()
{
    for (int i=1; i<=3; i++) {
        sumaGrid((QGridLayout*)tab_2->layout(),0,i,4);
        sumaGrid((QGridLayout*)tab_2->layout(),0,i);
    }
}
