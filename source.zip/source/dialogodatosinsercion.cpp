/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#include "dialogodatosinsercion.h"
#include <QtGui>
#include "mainwindow.h"
#include "mensajes.h"

DialogoDatosInsercion::DialogoDatosInsercion (QWidget *parent)
  :DialogoDatos (parent)
{
    setupUi (this);
    initUi();

    QList <QLineEdit *>l;
    l<< okupa_a1 << okupa_a2 << okupa_a3 << okupa_a4 << okupa_a5;
    l<< ocupa_a1 << ocupa_a2 << ocupa_a3 << ocupa_a4 << ocupa_a5;
    l<< okupa_b1 << okupa_b2 << okupa_b3 << okupa_b4 << okupa_b5;
    l<< ocupa_b1 << ocupa_b2 << ocupa_b3 << ocupa_b4 << ocupa_b5;
    for (int i=0; i<l.size() ; i ++) {
        ((QWidget*)l.at(i))->setStyleSheet(ESTILO_0);
    }

    DialogoDatos::setGrid(grid_permanencia, intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)proceso_a->layout(), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)proceso_b->layout(), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)ocupa_hombres->layout(), intPositivoVal);
    DialogoDatos::setGrid((QGridLayout *)ocupa_mujeres->layout(), intPositivoVal);

    notasWidget ["proceso_a4"]=QObject::tr(MSG_D_INSERCION_NOTA_PROCESO);
}

int DialogoDatosInsercion::validarWidget(QLineEdit *ptr)
{
    QList <QLineEdit *>l1, l2;
    l1 << okupa_a1 << okupa_a2 << okupa_a3 << okupa_a4 << okupa_a5;
    l2 << ocupa_a1 << ocupa_a2 << ocupa_a3 << ocupa_a4 << ocupa_a5;
    if (l1.contains(ptr))
        return validarOcupaciones(ptr, false, 1);
    else if (l2.contains (ptr))
        return validarOcupaciones(ptr, true, 1);

    l1.clear();
    l2.clear();
    l1 << okupa_b1 << okupa_b2 << okupa_b3 << okupa_b4 << okupa_b5;
    l2 << ocupa_b1 << ocupa_b2 << ocupa_b3 << ocupa_b4 << ocupa_b5;
    if (l1.contains(ptr))
        return validarOcupaciones(ptr, false, 2);
    else if (l2.contains (ptr))
        return validarOcupaciones(ptr, true, 2);

    return (DialogoDatos::validarWidget(ptr));
}


void DialogoDatosInsercion::triggerOutWidget(QLineEdit *e)
{
    if (e==p_1) sumaGrid(grid_permanencia,0,1);
    if (e==p_2) sumaGrid(grid_permanencia,0,1);
    if (e==p_3) sumaGrid(grid_permanencia,0,1);
    if (e==p_4) sumaGrid(grid_permanencia,0,1);

    if (e==proceso_a1) sumaGrid((QGridLayout*)proceso_a->layout(),0,1);
    if (e==proceso_a2) sumaGrid((QGridLayout*)proceso_a->layout(),0,1);
    if (e==proceso_a3) sumaGrid((QGridLayout*)proceso_a->layout(),0,1);
    if (e==proceso_a4) sumaGrid((QGridLayout*)proceso_a->layout(),0,1);

    if (e==proceso_b1) sumaGrid((QGridLayout*)proceso_b->layout(),0,1);
    if (e==proceso_b2) sumaGrid((QGridLayout*)proceso_b->layout(),0,1);
    if (e==proceso_b3) sumaGrid((QGridLayout*)proceso_b->layout(),0,1);
}


bool DialogoDatosInsercion::validarForm(bool flagShowOk)
{
    QString aviso;

    int n1;
    int n2;

    n1 = proceso_b1->text().toInt() + proceso_b2->text().toInt();
    n2 = ocupa_a0->text().toInt() + ocupa_b0->text().toInt();
    if ( n1 != n2 ) {
      aviso = QObject::tr(MSG_D_INSERCION_ERR_OCUPACIONES).arg(QString::number(n1)).arg(QString::number(n2));
        QMessageBox::warning(0,QObject::tr(MSG_VALIDACION),aviso);
        return false;
    }

    n1 = proceso_a1->text().toInt();
    n2 = proceso_b0->text().toInt();
    if ( n1 != n2 ) {
        aviso=QObject::tr(MSG_D_INSERCION_ERR_PROCESO).arg(QString::number(n1)).arg(QString::number(n2));
        QMessageBox::warning(0,QObject::tr(MSG_VALIDACION),aviso);
        return false;
    }

    if ( ! ((MainWindow*)(this->parentWidget()))->checkPersonasI() )
        return false;

    return DialogoDatos::validarForm(flagShowOk);
}

int DialogoDatosInsercion::validarOcupaciones (QLineEdit *e, bool flag_valor, int caso)
{
    QWidget *w1, *w2;
    QString nombre, valor, str;
    QList <QLineEdit *>l1, l2;
    int index;
    int p;

    if (caso==1) {
        l1 << okupa_a1 << okupa_a2 << okupa_a3 << okupa_a4 << okupa_a5;
        l2 << ocupa_a1 << ocupa_a2 << ocupa_a3 << ocupa_a4 << ocupa_a5;
    } else if (caso==2) {
        l1 << okupa_b1 << okupa_b2 << okupa_b3 << okupa_b4 << okupa_b5;
        l2 << ocupa_b1 << ocupa_b2 << ocupa_b3 << ocupa_b4 << ocupa_b5;
    }

    if (flag_valor) {
        p=0;
        for (int i=0; i<l2.size();i++)
            p+=l2.at(i)->text().toInt();
        if (caso==1)
            ocupa_a0->setText(str.setNum(p));
        else if (caso==2)
            ocupa_b0->setText(str.setNum(p));

        index=l2.indexOf(e);
    } else
        index=l1.indexOf(e);

    // Colores
    w1=(QWidget *)l1.at(index);
    w2=(QWidget *)l2.at(index);
    nombre=l1.at(index)->text();
    valor=l2.at(index)->text();


    if (!nombre.isEmpty() && valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_SI);
        w2->setStyleSheet(ESTILO_NO);
    } else if (!nombre.isEmpty()  && !valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_SI);
        w2->setStyleSheet(ESTILO_SI);
    } else if (nombre.isEmpty() && valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_0);
        w2->setStyleSheet(ESTILO_0);
    } else if (nombre.isEmpty() && !valor.isEmpty()) {
        w1->setStyleSheet(ESTILO_NO);
        w2->setStyleSheet(ESTILO_SI);
    }

    return 0;
}

void DialogoDatosInsercion::actualizarForm()
{
    QString str;

    sumaGrid(grid_permanencia,0,1);
    sumaGrid((QGridLayout*)proceso_a->layout(),0,1);
    sumaGrid((QGridLayout*)proceso_b->layout(),0,1);

    QList <QLineEdit *>l1, l2;
    int p1=0, p2=0;


    l1 << ocupa_a1 << ocupa_a2 << ocupa_a3 << ocupa_a4 << ocupa_a5;
    l2 << ocupa_b1 << ocupa_b2 << ocupa_b3 << ocupa_b4 << ocupa_b5;
    for (int i=0; i<l2.size();i++) {
        p1+=l1.at(i)->text().toInt();
        p2+=l2.at(i)->text().toInt();
    }
    ocupa_a0->setText(str.setNum(p1));
    ocupa_b0->setText(str.setNum(p2));
}
