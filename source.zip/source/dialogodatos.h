/*********************************************************************************
|     Copyright 2011 Dani Gutiérrez Porset (jdanitxu@gmail.com)                  |
|                                                                                |
|    This file is part of "Balance Social".                                      |
|                                                                                |
|    "Balance Social" is free software: you can redistribute it and/or modify    |
|    it under the terms of the GNU General Public License as published by        |
|    the Free Software Foundation, either version 3 of the License, or           |
|    (at your option) any later version.                                         |
|                                                                                |
|    "Balance Social" is distributed in the hope that it will be useful,         |
|    but WITHOUT ANY WARRANTY; without even the implied warranty of              |
|    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               |
|    GNU General Public License for more details.                                |
|                                                                                |
|    You should have received a copy of the GNU General Public License           |
|    along with "Balance Social".  If not, see <http://www.gnu.org/licenses/>.   |
*********************************************************************************/
#ifndef DIALOGO_DATOS_H
#define DIALOGO_DATOS_H

#include <QDialog>
#include <QDomDocument>
#include <QRegExp>
#include <QValidator>
#include <QGridLayout>
#include <QtGui>

#include "constantes.h"

class DialogoDatos : public QDialog
{
  Q_OBJECT

public:
    QRegExpValidator *intPositivoVal;
    QRegExpValidator *eurosVal;
    QRegExpValidator *doublePositivoVal;
    QRegExpValidator *porcentajeVal;
    QRegExpValidator *cifVal;
    QRegExpValidator *dniVal;
    QRegExpValidator *telefonoVal;
    QRegExpValidator *emailVal;
    QRegExpValidator *codigoPostalVal;


    DialogoDatos(QWidget *parent=0);
    void initUi (QList <QWidget *> *opcionales = NULL);

    bool eventFilter(QObject *object, QEvent *event);
    virtual int validarWidget (QLineEdit *ql);
    virtual int validarWidget (QDateEdit *){return 1;};
    int validarWidget (QLineEdit *ql, QString s);
    bool validarForm(QList <QWidget *> *l, bool flagShowOk);
    virtual void actualizarForm() {};
    virtual QString toHtml() {return "";};

    void toXbsl(QDomDocument *xbsl);
    void fromXbsl(QDomDocument xbsl);

    void notaInWidget (QWidget *w);
    void notaOutWidget (QWidget *w);
    void notaTab(int index);
    void setGrid(QGridLayout *g, QValidator *v);
    void sumaGrid(QGridLayout *g,int fil, int col, int x=0);

protected:
    QHash <QString,QString> notasWidget;
    QHash <int,QString> notasTab;

private:
    int validarWidget (QLineEdit * &l, QValidator *v, QString title, QString body);
    void sumaColumnaGrid(QGridLayout *g,int col, int x, bool ultima);
    void sumaFilaGrid(QGridLayout *g,int fil);
    virtual void triggerOutWidget(QLineEdit *) {};
    virtual void triggerOutWidget(QComboBox *, int *) {};


    void insertaNodoXbsl(QDomDocument *xbsl, QDomElement d, QString clase, QString id, QString valor);
    void guardaArbolXbsl(QDomDocument *xbsl, QDomElement d, QTreeWidget *p);
    void guardaNodoXbsl(QDomDocument *xbsl, QDomElement d, QTreeWidgetItem *p);

signals:
    void notSaved();

public slots:
    virtual bool validarForm(bool flagShowOk=true) {return validarForm(0, flagShowOk);};
    void on_tabWidget_currentChanged (int index){ notaTab(index); };
    void ayuda();

};

#endif // DIALOGO_DATOS_H
